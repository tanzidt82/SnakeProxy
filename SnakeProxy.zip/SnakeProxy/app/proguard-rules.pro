# Fleet Proxy — R8 rules

# Native proxy engine: JNI looks this class + its native methods up by name
-keep class com.snake.proxy.core.TProxyService { *; }
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }

# Scramble everything else into one short package, drop source file names
-repackageclasses 'x'
-allowaccessmodification
-renamesourcefileattribute ''
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*

# Libraries
-dontwarn com.caverock.androidsvg.**
-dontwarn javax.annotation.**
-dontwarn org.jetbrains.annotations.**
-dontwarn kotlin.**

# Remove Kotlin null-check helper strings (shrinks + hides parameter names)
-assumenosideeffects class kotlin.jvm.internal.Intrinsics {
    public static void checkNotNull(...);
    public static void checkExpressionValueIsNotNull(...);
    public static void checkNotNullExpressionValue(...);
    public static void checkParameterIsNotNull(...);
    public static void checkNotNullParameter(...);
    public static void checkReturnedValueIsNotNull(...);
    public static void checkFieldIsNotNull(...);
}
