package com.snake.proxy.core;

/**
 * Bridge to the hev-socks5-tunnel native engine.
 * Class name/package must match PKGNAME/CLSNAME in jni/Application.mk,
 * and every method below must exist with exactly this signature,
 * otherwise JNI RegisterNatives fails and the library refuses to load.
 */
public final class TProxyService {
    private static Throwable loadError = null;

    static {
        try {
            System.loadLibrary("hev-socks5-tunnel");
        } catch (Throwable t) {
            loadError = t;
        }
    }

    private TProxyService() {}

    /** null when the native engine loaded fine. */
    public static Throwable getLoadError() {
        return loadError;
    }

    public static native boolean TProxyStartService(String configPath, int fd);

    public static native boolean TProxyStopService();

    public static native boolean TProxyIsRunning();

    /** [tx packets, tx bytes, rx packets, rx bytes] */
    public static native long[] TProxyGetStats();
}
