package com.snake.proxy.core;

/**
 * hev-socks5-tunnel নেটিভ ইঞ্জিনের সাথে সংযোগ।
 * এই ক্লাসের নাম ও প্যাকেজ jni/Application.mk এর PKGNAME/CLSNAME এর সাথে মিলতে হবে।
 */
public final class TProxyService {
    static {
        System.loadLibrary("hev-socks5-tunnel");
    }

    private TProxyService() {}

    public static native void TProxyStartService(String configPath, int fd);

    public static native void TProxyStopService();

    /** [tx packets, tx bytes, rx packets, rx bytes] */
    public static native long[] TProxyGetStats();
}
