package com.snake.proxy

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat

/** Approximate country locations used for map pins (lat, lon). */
object MapPins {
    val all: Map<String, Pair<Double, Double>> = mapOf(
        "US" to (39.0 to -98.0), "CA" to (56.0 to -106.0), "MX" to (23.0 to -102.0), "BR" to (-10.0 to -52.0),
        "AR" to (-34.0 to -64.0), "CL" to (-33.0 to -71.0), "CO" to (4.0 to -73.0), "PE" to (-9.0 to -75.0),
        "VE" to (7.0 to -66.0), "EC" to (-1.8 to -78.0), "BO" to (-16.0 to -64.0), "PY" to (-23.0 to -58.0),
        "UY" to (-33.0 to -56.0), "CR" to (10.0 to -84.0), "PA" to (9.0 to -80.0), "CU" to (21.5 to -79.0),
        "DO" to (18.7 to -70.0), "PR" to (18.2 to -66.5), "JM" to (18.1 to -77.3), "GT" to (15.7 to -90.2),
        "GB" to (53.5 to -2.0), "IE" to (53.0 to -8.0), "FR" to (46.5 to 2.5), "DE" to (51.0 to 10.0),
        "NL" to (52.3 to 5.3), "BE" to (50.6 to 4.6), "LU" to (49.8 to 6.1), "ES" to (40.0 to -4.0),
        "PT" to (39.5 to -8.0), "IT" to (42.8 to 12.5), "CH" to (46.8 to 8.2), "AT" to (47.5 to 14.5),
        "SE" to (62.0 to 15.0), "NO" to (61.0 to 9.0), "FI" to (64.0 to 26.0), "DK" to (56.0 to 9.5),
        "IS" to (65.0 to -18.0), "PL" to (52.0 to 19.0), "CZ" to (49.8 to 15.5), "SK" to (48.7 to 19.5),
        "HU" to (47.2 to 19.5), "RO" to (46.0 to 25.0), "BG" to (42.7 to 25.3), "RS" to (44.0 to 21.0),
        "HR" to (45.2 to 15.5), "GR" to (39.0 to 22.0), "UA" to (49.0 to 32.0), "LT" to (55.2 to 23.9),
        "LV" to (56.9 to 24.6), "EE" to (58.6 to 25.0), "MD" to (47.2 to 28.5), "BY" to (53.7 to 28.0),
        "RU" to (58.0 to 60.0), "TR" to (39.0 to 35.0), "CY" to (35.0 to 33.0), "GE" to (42.3 to 43.4),
        "AM" to (40.0 to 45.0), "AZ" to (40.3 to 47.6), "IL" to (31.4 to 35.0), "JO" to (31.2 to 36.5),
        "LB" to (33.9 to 35.8), "SA" to (24.0 to 45.0), "AE" to (24.0 to 54.0), "QA" to (25.3 to 51.2),
        "KW" to (29.3 to 47.6), "BH" to (26.0 to 50.5), "OM" to (21.0 to 57.0), "IQ" to (33.0 to 44.0),
        "IR" to (32.0 to 53.0), "EG" to (26.8 to 30.0), "MA" to (32.0 to -6.0), "DZ" to (28.0 to 2.0),
        "TN" to (34.0 to 9.0), "NG" to (9.0 to 8.0), "GH" to (8.0 to -1.0), "KE" to (0.5 to 38.0),
        "ET" to (9.0 to 40.0), "ZA" to (-29.0 to 24.0), "TZ" to (-6.3 to 35.0), "AO" to (-12.0 to 17.5),
        "IN" to (21.0 to 78.0), "PK" to (30.0 to 70.0), "BD" to (23.7 to 90.3), "LK" to (7.8 to 80.7),
        "NP" to (28.0 to 84.0), "KZ" to (48.0 to 67.0), "UZ" to (41.4 to 64.6), "CN" to (35.0 to 103.0),
        "MN" to (46.8 to 103.0), "HK" to (22.3 to 114.2), "TW" to (23.7 to 121.0), "JP" to (36.5 to 138.5),
        "KR" to (36.5 to 127.8), "SG" to (1.35 to 103.8), "MY" to (4.0 to 102.0), "TH" to (15.0 to 101.0),
        "VN" to (16.0 to 107.0), "KH" to (12.6 to 105.0), "LA" to (19.8 to 102.5), "MM" to (21.0 to 96.0),
        "ID" to (-2.0 to 118.0), "PH" to (12.5 to 122.0), "AU" to (-25.0 to 134.0), "NZ" to (-41.0 to 174.0)
    )
}

/**
 * Dotted world map with country pins. Drag to pan, pinch to zoom, tap a pin to pick it.
 * The highlighted pin pulses while connected.
 */
class WorldMapView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    private val map: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.world_dots)
    private val mapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val m = Matrix()
    private val d = resources.displayMetrics.density

    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var baseScale = 1f
    private var pulse = 0f
    private var anim: ValueAnimator? = null

    /** Bottom area covered by the sheet; the map centres pins above it. */
    var bottomInset = 0f

    var selectedCc: String = ""
        set(v) { field = v.uppercase(); invalidate() }
    var connectedCc: String = ""
        set(v) { field = v.uppercase(); invalidate() }
    var connecting = false
        set(v) { field = v; invalidate() }

    var onPinTap: ((String) -> Unit)? = null

    private val pulser = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { pulse = it.animatedValue as Float; if (connectedCc.isNotEmpty() || connecting) invalidate() }
    }

    init {
        recolor()
    }

    fun recolor() {
        mapPaint.colorFilter = PorterDuffColorFilter(ContextCompat.getColor(context, R.color.map_dot), PorterDuff.Mode.SRC_IN)
        invalidate()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); pulser.start() }
    override fun onDetachedFromWindow() { pulser.cancel(); anim?.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        baseScale = maxOf(h / map.height.toFloat(), w / map.width.toFloat()) * 1.05f
        if (ow == 0) {
            scale = 1f
            // start centred on Europe / Asia
            val p = project(30.0, 40.0)
            tx = w / 2f - p.first * baseScale
            ty = (h - bottomInset) / 2f - p.second * baseScale
            clamp()
        }
    }

    private fun project(lat: Double, lon: Double): Pair<Float, Float> {
        var lo = lon
        if (lo < -170) lo += 360
        val x = ((lo + 170) / 360.0 * map.width).toFloat()
        val y = ((80 - lat) / 138.0 * map.height).toFloat()
        return x to y
    }

    private fun screen(cc: String): Pair<Float, Float>? {
        val ll = MapPins.all[cc] ?: return null
        val p = project(ll.first, ll.second)
        val s = baseScale * scale
        return (p.first * s + tx) to (p.second * s + ty)
    }

    private fun clamp() {
        val s = baseScale * scale
        val mw = map.width * s
        val mh = map.height * s
        tx = if (mw <= width) (width - mw) / 2f else tx.coerceIn(width - mw, 0f)
        ty = if (mh <= height) (height - mh) / 2f else ty.coerceIn(height - mh, 0f)
    }

    /** Smoothly flies the camera to a country. */
    fun focus(cc: String, zoom: Float = 2.2f) {
        val ll = MapPins.all[cc.uppercase()] ?: return
        val p = project(ll.first, ll.second)
        val s0 = scale; val tx0 = tx; val ty0 = ty
        val s1 = zoom
        val tx1 = width / 2f - p.first * baseScale * s1
        val ty1 = (height - bottomInset) / 2f - p.second * baseScale * s1
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener {
                val f = it.animatedValue as Float
                scale = s0 + (s1 - s0) * f
                tx = tx0 + (tx1 - tx0) * f
                ty = ty0 + (ty1 - ty0) * f
                clamp()
                invalidate()
            }
            start()
        }
    }

    fun zoomOut() {
        val s0 = scale; val tx0 = tx; val ty0 = ty
        val p = project(30.0, 40.0)
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 800
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener {
                val f = it.animatedValue as Float
                scale = s0 + (1f - s0) * f
                tx = tx0 + (width / 2f - p.first * baseScale - tx0) * f
                ty = ty0 + ((height - bottomInset) / 2f - p.second * baseScale - ty0) * f
                clamp()
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = baseScale * scale
        m.reset()
        m.postScale(s, s)
        m.postTranslate(tx, ty)
        c.drawBitmap(map, m, mapPaint)

        val accent = ContextCompat.getColor(context, R.color.mint_dark)
        val idle = ContextCompat.getColor(context, R.color.pin_idle)
        val green = ContextCompat.getColor(context, R.color.green)
        val pinR = (3.2f + scale * 0.9f) * d

        for (cc in MapPins.all.keys) {
            val p = screen(cc) ?: continue
            if (p.first < -20 || p.first > width + 20 || p.second < -20 || p.second > height + 20) continue
            val active = cc == connectedCc
            val sel = cc == selectedCc
            if (active || (sel && connecting)) {
                val col = if (active) green else accent
                ringPaint.color = col
                ringPaint.strokeWidth = 2f * d
                ringPaint.alpha = ((1f - pulse) * 200).toInt()
                c.drawCircle(p.first, p.second, pinR + pulse * 26f * d, ringPaint)
                pinPaint.color = col
                c.drawCircle(p.first, p.second, pinR * 1.9f, pinPaint)
                pinPaint.color = Color.WHITE
                c.drawCircle(p.first, p.second, pinR * 0.8f, pinPaint)
            } else if (sel) {
                pinPaint.color = accent
                pinPaint.alpha = 60
                c.drawCircle(p.first, p.second, pinR * 3f, pinPaint)
                pinPaint.alpha = 255
                c.drawCircle(p.first, p.second, pinR * 1.6f, pinPaint)
                pinPaint.color = Color.WHITE
                c.drawCircle(p.first, p.second, pinR * 0.65f, pinPaint)
            } else {
                pinPaint.color = Color.WHITE
                c.drawCircle(p.first, p.second, pinR + 1.5f * d, pinPaint)
                pinPaint.color = idle
                c.drawCircle(p.first, p.second, pinR, pinPaint)
            }
        }
    }

    // ---------------- gestures ----------------

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean { anim?.cancel(); return true }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            tx -= dx; ty -= dy
            clamp(); invalidate()
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            var best: String? = null
            var bestD = 30f * d
            for (cc in MapPins.all.keys) {
                val p = screen(cc) ?: continue
                val dd = Math.hypot((p.first - e.x).toDouble(), (p.second - e.y).toDouble()).toFloat()
                if (dd < bestD) { bestD = dd; best = cc }
            }
            best?.let { onPinTap?.invoke(it) }
            return best != null
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val target = (scale * 1.8f).coerceAtMost(5f)
            zoomAround(e.x, e.y, target / scale)
            return true
        }
    })

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(det: ScaleGestureDetector): Boolean {
            zoomAround(det.focusX, det.focusY, det.scaleFactor)
            return true
        }
    })

    private fun zoomAround(fx: Float, fy: Float, factor: Float) {
        val ns = (scale * factor).coerceIn(1f, 5f)
        val f = ns / scale
        tx = fx - (fx - tx) * f
        ty = fy - (fy - ty) * f
        scale = ns
        clamp()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        if (!scaler.isInProgress) gestures.onTouchEvent(e)
        if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        return true
    }
}
