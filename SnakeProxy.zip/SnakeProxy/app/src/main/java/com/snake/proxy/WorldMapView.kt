package com.snake.proxy

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.PI
import kotlin.math.ln
import kotlin.math.tan

/** Approximate country locations used for map pins (lat, lon). */
object MapPins {
    val all: Map<String, Pair<Double, Double>> = mapOf(
        "US" to (39.0 to -98.0), "CA" to (56.0 to -106.0), "MX" to (23.0 to -102.0), "BR" to (-10.0 to -52.0),
        "AR" to (-34.0 to -64.0), "CL" to (-33.0 to -71.0), "CO" to (4.0 to -73.0), "PE" to (-9.0 to -75.0),
        "VE" to (7.0 to -66.0), "EC" to (-1.8 to -78.0), "BO" to (-16.0 to -64.0), "PY" to (-23.0 to -58.0),
        "UY" to (-33.0 to -56.0), "CR" to (10.0 to -84.0), "PA" to (9.0 to -80.0), "CU" to (21.5 to -79.0),
        "DO" to (18.7 to -70.0), "PR" to (18.2 to -66.5), "JM" to (18.1 to -77.3), "GT" to (15.7 to -90.2),
        "GB" to (53.5 to -2.0), "IE" to (53.0 to -8.0), "FR" to (46.5 to 2.5), "DE" to (51.0 to 10.0),
        "NL" to (52.3 to 5.3), "BE" to (50.6 to 4.6), "LU" to (49.8 to 6.1), "ES" to (40.0 to -4.0),
        "PT" to (39.5 to -8.0), "IT" to (42.8 to 12.5), "CH" to (46.8 to 8.2), "AT" to (47.5 to 14.5),
        "SE" to (62.0 to 15.0), "NO" to (61.0 to 9.0), "FI" to (64.0 to 26.0), "DK" to (56.0 to 9.5),
        "IS" to (65.0 to -18.0), "PL" to (52.0 to 19.0), "CZ" to (49.8 to 15.5), "SK" to (48.7 to 19.5),
        "HU" to (47.2 to 19.5), "RO" to (46.0 to 25.0), "BG" to (42.7 to 25.3), "RS" to (44.0 to 21.0),
        "HR" to (45.2 to 15.5), "GR" to (39.0 to 22.0), "UA" to (49.0 to 32.0), "LT" to (55.2 to 23.9),
        "LV" to (56.9 to 24.6), "EE" to (58.6 to 25.0), "MD" to (47.2 to 28.5), "BY" to (53.7 to 28.0),
        "RU" to (58.0 to 60.0), "TR" to (39.0 to 35.0), "CY" to (35.0 to 33.0), "GE" to (42.3 to 43.4),
        "AM" to (40.0 to 45.0), "AZ" to (40.3 to 47.6), "IL" to (31.4 to 35.0), "JO" to (31.2 to 36.5),
        "LB" to (33.9 to 35.8), "SA" to (24.0 to 45.0), "AE" to (24.0 to 54.0), "QA" to (25.3 to 51.2),
        "KW" to (29.3 to 47.6), "BH" to (26.0 to 50.5), "OM" to (21.0 to 57.0), "IQ" to (33.0 to 44.0),
        "IR" to (32.0 to 53.0), "EG" to (26.8 to 30.0), "MA" to (32.0 to -6.0), "DZ" to (28.0 to 2.0),
        "TN" to (34.0 to 9.0), "NG" to (9.0 to 8.0), "GH" to (8.0 to -1.0), "KE" to (0.5 to 38.0),
        "ET" to (9.0 to 40.0), "ZA" to (-29.0 to 24.0), "TZ" to (-6.3 to 35.0), "AO" to (-12.0 to 17.5),
        "IN" to (21.0 to 78.0), "PK" to (30.0 to 70.0), "BD" to (23.7 to 90.3), "LK" to (7.8 to 80.7),
        "NP" to (28.0 to 84.0), "KZ" to (48.0 to 67.0), "UZ" to (41.4 to 64.6), "CN" to (35.0 to 103.0),
        "MN" to (46.8 to 103.0), "HK" to (22.3 to 114.2), "TW" to (23.7 to 121.0), "JP" to (36.5 to 138.5),
        "KR" to (36.5 to 127.8), "SG" to (1.35 to 103.8), "MY" to (4.0 to 102.0), "TH" to (15.0 to 101.0),
        "VN" to (16.0 to 107.0), "KH" to (12.6 to 105.0), "LA" to (19.8 to 102.5), "MM" to (21.0 to 96.0),
        "ID" to (-2.0 to 118.0), "PH" to (12.5 to 122.0), "AU" to (-25.0 to 134.0), "NZ" to (-41.0 to 174.0)
    )
}

/** Country outlines (Natural Earth 110m), parsed once and shared by every map view. */
object WorldShapes {
    private const val URL1 =
        "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson"
    private const val URL2 =
        "https://cdn.jsdelivr.net/gh/nvkelso/natural-earth-vector@master/geojson/ne_110m_admin_0_countries.geojson"

    /** Map units: 10 per degree of longitude, Mercator vertically, lon -170..190, lat 80..-58. */
    const val W = 3600f
    private const val RAD = W / (2 * PI)
    private val Y0 = merc(80.0)
    val H = ((Y0 - merc(-58.0)) * RAD).toFloat()

    @Volatile var land: Path? = null
    @Volatile var countries: Map<String, Path> = emptyMap()
    private var loading = false
    private val listeners = mutableListOf<() -> Unit>()

    private fun merc(lat: Double) = ln(tan(PI / 4 + Math.toRadians(lat.coerceIn(-85.0, 85.0)) / 2))

    fun x(lon: Double): Float { var l = lon; if (l < -170) l += 360; return ((l + 170) * 10).toFloat() }
    fun y(lat: Double): Float = ((Y0 - merc(lat)) * RAD).toFloat()

    fun load(ctx: Context, done: () -> Unit) {
        if (land != null) { done(); return }
        synchronized(this) {
            listeners += done
            if (loading) return
            loading = true
        }
        val app = ctx.applicationContext
        Thread {
            val text = readAsset(app) ?: readCache(app) ?: download(app)
            if (text != null) runCatching { parse(text) }
            val ls = synchronized(this) { loading = false; listeners.toList().also { listeners.clear() } }
            Handler(Looper.getMainLooper()).post { ls.forEach { it() } }
        }.start()
    }

    private fun readAsset(c: Context) = runCatching { c.assets.open("world.geojson").bufferedReader().readText() }.getOrNull()
    private fun cacheFile(c: Context) = File(c.filesDir, "world.geojson")
    private fun readCache(c: Context) = cacheFile(c).takeIf { it.length() > 1000 }?.readText()

    private fun download(c: Context): String? {
        for (u in listOf(URL1, URL2)) {
            try {
                val con = URL(u).openConnection() as HttpURLConnection
                con.connectTimeout = 10000; con.readTimeout = 20000
                val t = con.inputStream.bufferedReader().readText()
                con.disconnect()
                if (t.length > 1000) { cacheFile(c).writeText(t); return t }
            } catch (ignored: Exception) {}
        }
        return null
    }

    private fun parse(text: String) {
        val feats = JSONObject(text).getJSONArray("features")
        val all = Path()
        val map = HashMap<String, Path>()
        for (i in 0 until feats.length()) {
            val f = feats.getJSONObject(i)
            val pr = f.optJSONObject("properties") ?: JSONObject()
            var cc = pr.optString("ISO_A2_EH", "")
            if (cc.length != 2) cc = pr.optString("ISO_A2", "")
            if (cc == "AQ") continue
            val g = f.optJSONObject("geometry") ?: continue
            val p = Path()
            val coords = g.getJSONArray("coordinates")
            when (g.optString("type")) {
                "Polygon" -> addPolygon(p, coords)
                "MultiPolygon" -> for (k in 0 until coords.length()) addPolygon(p, coords.getJSONArray(k))
            }
            all.addPath(p)
            if (cc.length == 2) map[cc.uppercase()] = p
        }
        countries = map
        land = all
    }

    private fun addPolygon(p: Path, rings: JSONArray) {
        for (r in 0 until rings.length()) {
            val ring = rings.getJSONArray(r)
            val n = ring.length()
            if (n < 3) continue
            var sum = 0.0
            for (k in 0 until n) sum += ring.getJSONArray(k).getDouble(0)
            val shift = if (sum / n < -170) 360.0 else 0.0
            for (k in 0 until n) {
                val pt = ring.getJSONArray(k)
                val lon = pt.getDouble(0) + shift
                val px = ((lon + 170) * 10).toFloat()
                val py = y(pt.getDouble(1))
                if (k == 0) p.moveTo(px, py) else p.lineTo(px, py)
            }
            p.close()
        }
    }
}

/**
 * World map with real country shapes and pins. In card mode only pin taps are handled;
 * in interactive mode it can also be dragged and pinch-zoomed.
 */
class WorldMapView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    private val landPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val hiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val m = Matrix()
    private val d = resources.displayMetrics.density

    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var baseScale = 1f
    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private var placed = false

    /** Allows drag and pinch zoom (full-screen map). */
    var interactive = true

    /** Bottom area covered by overlays; focused pins are centred above it. */
    var bottomInset = 0f

    /** Zoom used when flying to a country. */
    var focusZoom = 3.2f

    var selectedCc: String = ""
        set(v) { val n = v.uppercase(); if (n != field) { field = n; invalidate() } }
    var connectedCc: String = ""
        set(v) { val n = v.uppercase(); if (n != field) { field = n; invalidate() } }
    var connecting = false
        set(v) { if (v != field) { field = v; invalidate() } }

    var onPinTap: ((String) -> Unit)? = null

    private val pulser = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { pulse = it.animatedValue as Float; if (connectedCc.isNotEmpty() || connecting) invalidate() }
    }

    init {
        recolor()
        WorldShapes.load(ctx) { invalidate() }
    }

    fun recolor() {
        setBackgroundColor(ContextCompat.getColor(context, R.color.map_water))
        landPaint.color = ContextCompat.getColor(context, R.color.map_land)
        borderPaint.color = ContextCompat.getColor(context, R.color.map_border)
        hiPaint.color = ContextCompat.getColor(context, R.color.map_highlight)
        invalidate()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); pulser.start() }
    override fun onDetachedFromWindow() { pulser.cancel(); anim?.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        baseScale = maxOf(h / WorldShapes.H, w / WorldShapes.W)
        if (!placed) {
            placed = true
            scale = 1f
            centerOn(WorldShapes.x(60.0), WorldShapes.y(25.0), 1f)
        }
        clamp()
    }

    private fun centerOn(mx: Float, my: Float, s: Float) {
        scale = s
        tx = width / 2f - mx * baseScale * s
        ty = (height - bottomInset) / 2f - my * baseScale * s
        clamp()
    }

    private fun screen(cc: String): Pair<Float, Float>? {
        val ll = MapPins.all[cc] ?: return null
        val s = baseScale * scale
        return (WorldShapes.x(ll.second) * s + tx) to (WorldShapes.y(ll.first) * s + ty)
    }

    private fun clamp() {
        val s = baseScale * scale
        val mw = WorldShapes.W * s
        val mh = WorldShapes.H * s
        tx = if (mw <= width) (width - mw) / 2f else tx.coerceIn(width - mw, 0f)
        ty = if (mh <= height) (height - mh) / 2f else ty.coerceIn(height - mh, 0f)
    }

    private fun animateTo(mx: Float, my: Float, s1: Float, ms: Long) {
        if (width == 0) { post { animateTo(mx, my, s1, ms) }; return }
        val s0 = scale; val tx0 = tx; val ty0 = ty
        val tx1 = width / 2f - mx * baseScale * s1
        val ty1 = (height - bottomInset) / 2f - my * baseScale * s1
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener {
                val f = it.animatedValue as Float
                scale = s0 + (s1 - s0) * f
                tx = tx0 + (tx1 - tx0) * f
                ty = ty0 + (ty1 - ty0) * f
                clamp()
                invalidate()
            }
            start()
        }
    }

    /** Smoothly flies the camera to a country. */
    fun focus(cc: String, zoom: Float = focusZoom) {
        val ll = MapPins.all[cc.uppercase()] ?: return
        animateTo(WorldShapes.x(ll.second), WorldShapes.y(ll.first), zoom, 950)
    }

    fun zoomOut() = animateTo(WorldShapes.x(60.0), WorldShapes.y(25.0), 1f, 800)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = baseScale * scale
        val land = WorldShapes.land
        if (land != null) {
            c.save()
            m.reset(); m.postScale(s, s); m.postTranslate(tx, ty)
            c.concat(m)
            c.drawPath(land, landPaint)
            val hi = connectedCc.ifEmpty { selectedCc }
            WorldShapes.countries[hi]?.let { c.drawPath(it, hiPaint) }
            borderPaint.strokeWidth = (0.9f * d) / s
            c.drawPath(land, borderPaint)
            c.restore()
        }

        val accent = ContextCompat.getColor(context, R.color.mint)
        val idle = ContextCompat.getColor(context, R.color.pin_idle)
        val pinR = (2.6f + scale * 0.35f).coerceAtMost(4.2f) * d

        for (cc in MapPins.all.keys) {
            val p = screen(cc) ?: continue
            if (p.first < -30 || p.first > width + 30 || p.second < -30 || p.second > height + 30) continue
            val active = cc == connectedCc
            val sel = cc == selectedCc
            if (active || (sel && connecting)) {
                ringPaint.color = accent
                ringPaint.strokeWidth = 2f * d
                ringPaint.alpha = ((1f - pulse) * 210).toInt()
                c.drawCircle(p.first, p.second, pinR * 1.6f + pulse * 24f * d, ringPaint)
                pinPaint.color = Color.WHITE
                c.drawCircle(p.first, p.second, pinR * 2.3f, pinPaint)
                pinPaint.color = accent
                c.drawCircle(p.first, p.second, pinR * 1.6f, pinPaint)
            } else if (sel) {
                pinPaint.color = Color.WHITE
                c.drawCircle(p.first, p.second, pinR * 2f, pinPaint)
                pinPaint.color = accent
                c.drawCircle(p.first, p.second, pinR * 1.4f, pinPaint)
            } else {
                pinPaint.color = accent
                pinPaint.alpha = 235
                c.drawCircle(p.first, p.second, pinR, pinPaint)
                pinPaint.alpha = 255
            }
        }
        if (land == null) {
            // shapes still loading: soft hint so the card never looks empty
            pinPaint.color = idle; pinPaint.alpha = 40
            c.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 0f, 0f, pinPaint)
            pinPaint.alpha = 255
        }
    }

    // ---------------- gestures ----------------

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean { if (interactive) anim?.cancel(); return true }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (!interactive) return false
            tx -= dx; ty -= dy
            clamp(); invalidate()
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            var best: String? = null
            var bestD = 28f * d
            for (cc in MapPins.all.keys) {
                val p = screen(cc) ?: continue
                val dd = Math.hypot((p.first - e.x).toDouble(), (p.second - e.y).toDouble()).toFloat()
                if (dd < bestD) { bestD = dd; best = cc }
            }
            best?.let { onPinTap?.invoke(it) }
            return best != null
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (!interactive) return false
            zoomAround(e.x, e.y, (scale * 1.8f).coerceAtMost(8f) / scale)
            return true
        }
    })

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(det: ScaleGestureDetector): Boolean {
            if (!interactive) return false
            zoomAround(det.focusX, det.focusY, det.scaleFactor)
            return true
        }
    })

    private fun zoomAround(fx: Float, fy: Float, factor: Float) {
        val ns = (scale * factor).coerceIn(1f, 8f)
        val f = ns / scale
        tx = fx - (fx - tx) * f
        ty = fy - (fy - ty) * f
        scale = ns
        clamp()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (interactive) {
            scaler.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        }
        if (!scaler.isInProgress) gestures.onTouchEvent(e)
        return true
    }
}
