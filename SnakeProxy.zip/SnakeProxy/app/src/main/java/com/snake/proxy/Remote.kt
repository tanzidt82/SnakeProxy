package com.snake.proxy

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Settings that come from the admin panel (ads, update, maintenance, notice, links).
 * The last good copy is cached so the app still behaves the same when offline.
 */
object Remote {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var sp: SharedPreferences
    private var lastFetch = 0L
    @Volatile var cfg: JSONObject = JSONObject()
        private set

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.getSharedPreferences("remote", Context.MODE_PRIVATE)
        cfg = try { JSONObject(sp.getString("cfg", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    }

    fun base(ctx: Context) = ctx.getString(R.string.admin_url).trim().trimEnd('/')
    fun enabled(ctx: Context) = base(ctx).startsWith("http") && !base(ctx).contains("YOUR_VPS_IP")

    val deviceId: String
        get() = sp.getString("device", null) ?: UUID.randomUUID().toString().replace("-", "").take(16).also {
            sp.edit().putString("device", it).apply()
        }

    fun versionCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (e: Exception) { 0L }

    fun versionName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (e: Exception) { "" }

    /** Fetches fresh settings (at most once per [minGapMs]); [done] runs on the main thread. */
    fun fetch(ctx: Context, minGapMs: Long = 60_000, done: (JSONObject) -> Unit) {
        val app = ctx.applicationContext
        if (!enabled(app) || System.currentTimeMillis() - lastFetch < minGapMs) { done(cfg); return }
        lastFetch = System.currentTimeMillis()
        thread {
            val body = JSONObject()
                .put("id", deviceId).put("v", versionCode(app)).put("vn", versionName(app))
                .put("cc", Locale.getDefault().country).put("model", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                .put("sdk", Build.VERSION.SDK_INT)
            val res = try { post("${base(app)}/api/config", body) } catch (e: Exception) { null }
            if (res != null && res.optBoolean("ok")) {
                cfg = res
                sp.edit().putString("cfg", res.toString()).apply()
            }
            main.post { done(cfg) }
        }
    }

    fun event(ctx: Context, kind: String, src: String, ad: String) {
        val app = ctx.applicationContext
        if (!enabled(app)) return
        thread {
            try { post("${base(app)}/api/ad_event", JSONObject().put("id", deviceId).put("kind", kind).put("src", src).put("ad", ad)) }
            catch (ignored: Exception) {}
        }
    }

    private fun post(url: String, body: JSONObject): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 9000
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val text = c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
        return JSONObject(text)
    }

    fun link(key: String) = cfg.optJSONObject("links")?.optString(key, "") ?: ""

    fun open(a: Activity, url: String) {
        if (url.isBlank()) return
        try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url.trim())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ignored: Exception) {}
    }

    // ───────────── what the app does with the settings ─────────────

    private var updateShownThisSession = false
    private var updateDialog: Dialog? = null
    private var noticeDialog: Dialog? = null

    /** Applies maintenance / block / update / notice. Returns false when the app must stay closed. */
    fun gate(a: Activity, c: JSONObject = cfg): Boolean {
        if (c.optBoolean("blocked")) { MaintenanceActivity.open(a, blocked = true); return false }
        if (c.optJSONObject("maintenance")?.optBoolean("on") == true) { MaintenanceActivity.open(a, blocked = false); return false }
        val u = c.optJSONObject("update")
        val mine = versionCode(a)
        if (u != null && u.optLong("latest_code") > mine) {
            val force = u.optBoolean("force") || mine < u.optLong("min_code")
            val once = u.optString("show") == "once"
            val seenKey = "upd_seen_${u.optLong("latest_code")}"
            val skip = !force && (updateShownThisSession || (once && sp.getBoolean(seenKey, false)))
            if (!skip && updateDialog?.isShowing != true) {
                updateShownThisSession = true
                sp.edit().putBoolean(seenKey, true).apply()
                updateDialog = showUpdate(a, u, force)
            }
            if (force) return false
        }
        val n = c.optJSONObject("notice")
        if (n != null && n.optBoolean("on") && n.optString("id").isNotEmpty() &&
            sp.getString("notice_seen", "") != n.optString("id") && noticeDialog?.isShowing != true && updateDialog?.isShowing != true
        ) {
            sp.edit().putString("notice_seen", n.optString("id")).apply()
            noticeDialog = showNotice(a, n)
        }
        return true
    }

    private fun showUpdate(a: Activity, u: JSONObject, force: Boolean): Dialog {
        val v = LayoutInflater.from(a).inflate(R.layout.sheet_update, null)
        val d = BottomSheetDialog(a)
        d.setContentView(v)
        d.setCancelable(!force)
        d.setCanceledOnTouchOutside(!force)
        (v.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        d.behavior.isDraggable = !force
        v.findViewById<TextView>(R.id.updVersion).text =
            "Version ${u.optString("latest_name").ifBlank { u.optLong("latest_code").toString() }} · you have ${versionName(a)}"
        val notes = u.optString("notes").trim()
        v.findViewById<TextView>(R.id.updNotes).apply { text = notes; visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE }
        v.findViewById<TextView>(R.id.updTitle).text = if (force) "Update required" else "Update available"
        v.findViewById<View>(R.id.updNow).setOnClickListener {
            val link = u.optString("link").ifBlank { "https://play.google.com/store/apps/details?id=${a.packageName}" }
            open(a, link)
            if (!force) d.dismiss()
        }
        v.findViewById<View>(R.id.updLater).apply {
            visibility = if (force) View.GONE else View.VISIBLE
            setOnClickListener { d.dismiss() }
        }
        if (force) d.setOnKeyListener { _, code, _ -> if (code == android.view.KeyEvent.KEYCODE_BACK) { a.finishAffinity(); true } else false }
        d.show()
        return d
    }

    private fun showNotice(a: Activity, n: JSONObject): Dialog {
        val v = LayoutInflater.from(a).inflate(R.layout.dialog_notice, null)
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(v)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        d.window?.setDimAmount(0.65f)
        val img = v.findViewById<ImageView>(R.id.ntImage)
        val url = n.optString("image")
        if (url.isNotBlank()) { img.visibility = View.VISIBLE; Img.load(img, url) } else img.visibility = View.GONE
        v.findViewById<TextView>(R.id.ntTitle).apply { text = n.optString("title"); visibility = if (text.isBlank()) View.GONE else View.VISIBLE }
        v.findViewById<TextView>(R.id.ntText).apply { text = n.optString("text"); visibility = if (text.isBlank()) View.GONE else View.VISIBLE }
        val btn = n.optString("button"); val link = n.optString("link")
        v.findViewById<View>(R.id.ntButton).apply {
            visibility = if (btn.isNotBlank() && link.isNotBlank()) View.VISIBLE else View.GONE
            setOnClickListener { open(a, link); d.dismiss() }
        }
        v.findViewById<TextView>(R.id.ntButtonText).text = btn
        v.findViewById<View>(R.id.ntClose).setOnClickListener { d.dismiss() }
        d.show()
        return d
    }
}

/**
 * Decides when an ad may be shown (admin-panel rules) and shows own ads or AdMob.
 */
object Ads {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var sp: SharedPreferences
    private var launchAt = System.currentTimeMillis()
    private var initDone = false
    private var showing = false

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.getSharedPreferences("ads", Context.MODE_PRIVATE)
        launchAt = System.currentTimeMillis()
        try { MobileAds.initialize(ctx) { initDone = true } } catch (ignored: Throwable) {}
    }

    private val a get() = Remote.cfg.optJSONObject("ads") ?: JSONObject()
    private fun admob(k: String) = a.optJSONObject("admob")?.optString(k, "")?.trim() ?: ""
    private fun own(): List<JSONObject> {
        val arr = a.optJSONArray("own") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
    }

    private fun today() = java.text.SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date())

    private fun allowed(): Boolean {
        if (!a.optBoolean("enabled") || showing) return false
        val now = System.currentTimeMillis()
        if (now - launchAt < a.optLong("first_delay_sec", 0) * 1000) return false
        if (now - sp.getLong("last", 0) < a.optLong("interval_min", 0) * 60_000) return false
        val count = if (sp.getString("day", "") == today()) sp.getInt("count", 0) else 0
        val max = a.optInt("daily_max", 0)
        return max <= 0 || count < max
    }

    private fun mark(ctx: Context, src: String, id: String) {
        val count = if (sp.getString("day", "") == today()) sp.getInt("count", 0) else 0
        sp.edit().putString("day", today()).putInt("count", count + 1).putLong("last", System.currentTimeMillis()).apply()
        Remote.event(ctx, "impression", src, id)
    }

    /** Which network to use for this slot: alternates when the panel says "both". */
    private fun pickOwn(): Boolean {
        val hasOwn = own().isNotEmpty()
        return when (a.optString("mode", "both")) {
            "own" -> hasOwn
            "admob" -> false
            else -> {
                val turn = sp.getBoolean("turn_own", true)
                sp.edit().putBoolean("turn_own", !turn).apply()
                if (turn) hasOwn else false
            }
        }
    }

    /** Called once the app has opened (respects "first ad after X sec"). */
    fun onAppOpen(act: Activity) {
        if (a.optJSONObject("place")?.optBoolean("app_open") != true) return
        val wait = (a.optLong("first_delay_sec", 0) * 1000 - (System.currentTimeMillis() - launchAt)).coerceAtLeast(600)
        main.postDelayed({ if (!act.isFinishing) showFull(act, "app_open") }, wait)
    }

    /** Called each time the VPN connects. */
    fun onConnected(act: Activity) {
        val p = a.optJSONObject("place") ?: return
        if (!p.optBoolean("after_connect")) return
        val n = sp.getInt("connects", 0) + 1
        sp.edit().putInt("connects", n).apply()
        val every = p.optInt("connect_every", 1).coerceAtLeast(1)
        if (n % every == 0) main.postDelayed({ if (!act.isFinishing) showFull(act, "connect") }, 900)
    }

    private fun showFull(act: Activity, slot: String) {
        if (!allowed()) return
        val ownList = own()
        val useOwn = pickOwn()
        if (useOwn && ownList.isNotEmpty()) {
            val i = sp.getInt("own_idx", 0) % ownList.size
            sp.edit().putInt("own_idx", i + 1).apply()
            val ad = ownList[i]
            mark(act, "own", ad.optString("id"))
            showing = true
            act.startActivity(AdActivity.intent(act, ad))
            main.postDelayed({ showing = false }, 4000)
            return
        }
        val unit = if (slot == "app_open") admob("app_open").ifEmpty { admob("interstitial") } else admob("interstitial")
        if (unit.isEmpty()) {
            if (ownList.isNotEmpty() && a.optString("mode") == "both") {      // fall back to own ads
                val ad = ownList[sp.getInt("own_idx", 0) % ownList.size]
                sp.edit().putInt("own_idx", sp.getInt("own_idx", 0) + 1).apply()
                mark(act, "own", ad.optString("id"))
                act.startActivity(AdActivity.intent(act, ad))
            }
            return
        }
        showing = true
        val req = AdRequest.Builder().build()
        val cb = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() { mark(act, "admob", slot) }
            override fun onAdDismissedFullScreenContent() { showing = false }
            override fun onAdFailedToShowFullScreenContent(e: com.google.android.gms.ads.AdError) { showing = false }
            override fun onAdClicked() { Remote.event(act, "click", "admob", slot) }
        }
        try {
            if (slot == "app_open" && admob("app_open").isNotEmpty()) {
                AppOpenAd.load(act, unit, req, object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        if (act.isFinishing) { showing = false; return }
                        ad.fullScreenContentCallback = cb; ad.show(act)
                    }
                    override fun onAdFailedToLoad(e: LoadAdError) { showing = false }
                })
            } else {
                InterstitialAd.load(act, unit, req, object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        if (act.isFinishing) { showing = false; return }
                        ad.fullScreenContentCallback = cb; ad.show(act)
                    }
                    override fun onAdFailedToLoad(e: LoadAdError) { showing = false }
                })
            }
        } catch (t: Throwable) { showing = false }
    }

    private var bannerKey = ""

    /** Fills the home banner slot (AdMob banner or an own photo ad marked as banner). */
    fun bindBanner(act: Activity, box: FrameLayout) {
        val p = a.optJSONObject("place")
        val on = a.optBoolean("enabled") && p?.optBoolean("home_banner") == true
        val mode = a.optString("mode", "both")
        val ownBanner = own().firstOrNull { it.optBoolean("banner") && it.optString("type") == "image" }
        val unit = admob("banner")
        val useAdmob = on && unit.isNotEmpty() && (mode == "admob" || (mode == "both" && (ownBanner == null || sp.getBoolean("turn_own", true))))
        val useOwn = on && !useAdmob && ownBanner != null && mode != "admob"
        val key = "$on|$useAdmob|$useOwn|$unit|${ownBanner?.optString("id")}"
        if (key == bannerKey && box.childCount > 0 == (useAdmob || useOwn)) return
        bannerKey = key
        box.removeAllViews()
        box.visibility = if (useAdmob || useOwn) View.VISIBLE else View.GONE
        if (useAdmob) {
            try {
                val av = AdView(act)
                av.adUnitId = unit
                av.setAdSize(AdSize.BANNER)
                av.adListener = object : AdListener() {
                    override fun onAdImpression() { Remote.event(act, "impression", "admob", "banner") }
                    override fun onAdClicked() { Remote.event(act, "click", "admob", "banner") }
                    override fun onAdFailedToLoad(e: LoadAdError) { box.visibility = View.GONE }
                }
                box.addView(av, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER))
                av.loadAd(AdRequest.Builder().build())
            } catch (t: Throwable) { box.visibility = View.GONE }
        } else if (useOwn && ownBanner != null) {
            val v = LayoutInflater.from(act).inflate(R.layout.item_own_banner, box, false)
            Img.load(v.findViewById(R.id.bnImage), ownBanner.optString("url"))
            val link = ownBanner.optString("link")
            v.setOnClickListener {
                if (link.isNotBlank()) { Remote.event(act, "click", "own", ownBanner.optString("id")); Remote.open(act, link) }
            }
            box.addView(v)
            Remote.event(act, "impression", "own", ownBanner.optString("id"))
        }
    }
}
