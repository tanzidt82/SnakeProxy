package com.snake.proxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat
import com.snake.proxy.core.TProxyService
import java.io.File
import java.io.RandomAccessFile
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class SnakeVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.snake.proxy.START"
        const val ACTION_STOP = "com.snake.proxy.STOP"
        const val ACTION_RELOAD = "com.snake.proxy.RELOAD"
        const val EXTRA_ID = "id"
        private const val NOTIF_ID = 7
        private const val CHANNEL = "vpn"

        // Read by the UI once per second
        @Volatile var running = false
        @Volatile var connecting = false
        @Volatile var profileId: String? = null
        @Volatile var profileName = ""
        @Volatile var startedAt = 0L
        @Volatile var upSpeed = 0L
        @Volatile var downSpeed = 0L
        @Volatile var totalUp = 0L
        @Volatile var totalDown = 0L
        @Volatile var exitIp = ""
        @Volatile var health = ""
        @Volatile var lastError = ""

        fun send(ctx: Context, action: String, id: String? = null) {
            val i = Intent(ctx, SnakeVpnService::class.java).setAction(action)
            if (id != null) i.putExtra(EXTRA_ID, id)
            if (action == ACTION_STOP) ctx.startService(i)
            else ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val worker = Executors.newSingleThreadScheduledExecutor()
    private val net = Executors.newCachedThreadPool()
    private var tun: ParcelFileDescriptor? = null
    private var bridge: HttpBridge? = null
    private var engineOn = false
    private var current: ProxyProfile? = null
    private var monitor: ScheduledFuture<*>? = null
    private var tick = 0
    private var fails = 0
    @Volatile private var checking = false
    private var lastUp = 0L
    private var lastDown = 0L
    private var baseUp = 0L
    private var baseDown = 0L
    private val logFile by lazy { File(filesDir, "hev.log") }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> worker.execute { shutdown("Disconnected") }
            else -> {
                // ACTION_START, ACTION_RELOAD, or started by system Always-on VPN
                startForeground(NOTIF_ID, notification("Connecting…"))
                val id = intent?.getStringExtra(EXTRA_ID) ?: Store.selectedId
                connecting = true
                lastError = ""
                worker.execute { apply(id) }
            }
        }
        return START_STICKY
    }

    override fun onRevoke() {
        AppLog.add("VPN permission revoked or another VPN started")
        worker.execute { shutdown(null) }
    }

    override fun onDestroy() {
        if (running || engineOn) {
            try { stopEngine() } catch (ignored: Throwable) {}
            try { tun?.close() } catch (ignored: Throwable) {}
            tun = null
            resetState()
        }
        worker.shutdownNow()
        net.shutdownNow()
        super.onDestroy()
    }

    // ---------------- connect / switch proxy ----------------

    private fun apply(id: String?) {
        val p = Store.get(id)
        if (p == null) {
            fail("No proxy selected")
            return
        }
        connecting = true
        var newBridge: HttpBridge? = null
        var newTun: ParcelFileDescriptor? = null
        try {
            TProxyService.getLoadError()?.let {
                throw Exception("Proxy engine failed to load: ${it.message}")
            }
            AppLog.add("Connecting: ${p.name} (${p.type} ${p.host}:${p.port})")

            // 1. SOCKS5 endpoint for the engine
            val socksHost: String
            val socksPort: Int
            val user: String
            val pass: String
            if (p.type == "HTTP") {
                val nb = HttpBridge(p).start()
                newBridge = nb
                socksHost = "127.0.0.1"; socksPort = nb.port; user = ""; pass = ""
            } else {
                socksHost = InetAddress.getByName(p.host).hostAddress
                    ?: throw Exception("Cannot resolve proxy host")
                socksPort = p.port; user = p.user; pass = p.pass
            }
            val cfg = writeConfig(socksHost, socksPort, user, pass)

            // 2. New tunnel first (before closing the old one) so nothing leaks in between
            val t = buildTun(p) ?: throw Exception("VPN permission missing, tap Connect again")
            newTun = t

            // 3. Restart engine on the new tunnel
            stopEngine()
            bridge = newBridge
            newBridge = null
            if (!TProxyService.TProxyStartService(cfg.absolutePath, t.fd)) {
                throw Exception("Proxy engine did not start")
            }
            engineOn = true
            val old = tun
            tun = t
            newTun = null
            try { old?.close() } catch (ignored: Throwable) {}

            current = p
            profileId = p.id
            profileName = p.name
            if (!running) startedAt = System.currentTimeMillis()
            running = true
            fails = 0
            exitIp = ""
            health = "Checking proxy…"
            AppLog.add("Connected: ${p.name}")
            updateNotification("Connected")
            startMonitor()
            net.execute { checkExitIp(p) }
        } catch (e: Throwable) {
            try { newBridge?.stop() } catch (ignored: Throwable) {}
            try { newTun?.close() } catch (ignored: Throwable) {}
            fail(e.message ?: e.javaClass.simpleName)
        } finally {
            connecting = false
        }
    }

    private fun fail(msg: String) {
        AppLog.add("Connect failed: $msg")
        lastError = msg
        if (running) {
            health = "$msg"
        } else {
            shutdown(null)
            lastError = msg
        }
    }

    private fun buildTun(p: ProxyProfile): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("Fleet Proxy: ${p.name}")
            .setMtu(8500)
            .addAddress("198.18.0.1", 32)
            .addRoute("0.0.0.0", 0)          // all IPv4 traffic
            .addDnsServer("198.18.0.2")      // DNS goes through the proxy
        try {
            b.addAddress("fc00::1", 128)
            b.addRoute("::", 0)               // all IPv6 traffic (no IPv6 leak)
        } catch (e: Throwable) {
            AppLog.add("IPv6 not added: ${e.message}")
        }
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)

        val apps = Store.apps
        when (Store.appMode) {
            Store.MODE_ONLY -> {
                var n = 0
                apps.filter { it != packageName }.forEach {
                    try { b.addAllowedApplication(it); n++ } catch (ignored: Throwable) {}
                }
                if (n == 0) {
                    AppLog.add("No apps selected, routing all apps")
                    b.addDisallowedApplication(packageName)
                }
            }
            Store.MODE_EXCLUDE -> {
                b.addDisallowedApplication(packageName)
                apps.forEach { try { b.addDisallowedApplication(it) } catch (ignored: Throwable) {} }
            }
            else -> b.addDisallowedApplication(packageName) // this app stays outside (avoids loops)
        }

        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        b.setConfigureIntent(pi)
        return b.establish()
    }

    private fun q(s: String) = "'" + s.replace("'", "''") + "'"

    private fun writeConfig(host: String, port: Int, user: String, pass: String): File {
        try { logFile.writeText("") } catch (ignored: Throwable) {}
        val text = buildString {
            appendLine("tunnel:")
            appendLine("  mtu: 8500")
            appendLine("  ipv4: 198.18.0.1")
            appendLine("  ipv6: 'fc00::1'")
            appendLine("socks5:")
            appendLine("  port: $port")
            appendLine("  address: ${q(host)}")
            appendLine("  udp: 'udp'")
            if (user.isNotEmpty()) {
                appendLine("  username: ${q(user)}")
                appendLine("  password: ${q(pass)}")
            }
            appendLine("mapdns:")
            appendLine("  address: 198.18.0.2")
            appendLine("  port: 53")
            appendLine("  network: 100.64.0.0")
            appendLine("  netmask: 255.192.0.0")
            appendLine("  cache-size: 10000")
            appendLine("misc:")
            appendLine("  task-stack-size: 81920")
            appendLine("  log-file: ${q(logFile.absolutePath)}")
            appendLine("  log-level: ${if (Store.debugLog) "debug" else "warn"}")
        }
        val f = File(filesDir, "tunnel.yml")
        f.writeText(text)
        return f
    }

    private fun stopEngine() {
        if (engineOn) {
            try {
                TProxyService.TProxyGetStats()?.let { s ->
                    if (s.size >= 4) { baseUp += s[1]; baseDown += s[3] }
                }
            } catch (ignored: Throwable) {}
            try { TProxyService.TProxyStopService() } catch (ignored: Throwable) {}
            engineOn = false
            lastUp = 0; lastDown = 0
        }
        try { bridge?.stop() } catch (ignored: Throwable) {}
        bridge = null
    }

    // ---------------- live monitor ----------------

    private fun startMonitor() {
        if (monitor != null) return
        monitor = worker.scheduleAtFixedRate({
            try { onTick() } catch (ignored: Throwable) {}
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun onTick() {
        tick++
        if (engineOn) {
            TProxyService.TProxyGetStats()?.let { s ->
                if (s.size >= 4) {
                    val up = s[1]; val down = s[3]
                    upSpeed = (up - lastUp).coerceAtLeast(0)
                    downSpeed = (down - lastDown).coerceAtLeast(0)
                    lastUp = up; lastDown = down
                    totalUp = baseUp + up; totalDown = baseDown + down
                }
            }
        }
        if (tick % 2 == 0) updateNotification("↑ ${Fmt.speed(upSpeed)}   ↓ ${Fmt.speed(downSpeed)}")
        if (tick % 10 == 0 && !checking) {
            current?.let { p -> checking = true; net.execute { healthCheck(p) } }
        }
        if (tick % 60 == 0) {
            try {
                if (logFile.length() > 2_000_000) RandomAccessFile(logFile, "rw").use { it.setLength(0) }
            } catch (ignored: Throwable) {}
        }
        if (tick % 300 == 0 && Store.autoSync && Store.subUrl.isNotBlank()) {
            net.execute { SubSync.sync() }
        }
    }

    private fun healthCheck(p: ProxyProfile) {
        try {
            val t0 = System.currentTimeMillis()
            ProxyDialer.open(p, "1.1.1.1", 443, 7000).close()
            val ms = System.currentTimeMillis() - t0
            if (fails > 0) AppLog.add("Proxy is back online")
            fails = 0
            health = "Proxy OK · ${ms} ms"
            if (exitIp.isEmpty()) checkExitIp(p)
        } catch (e: Throwable) {
            fails++
            health = "Proxy not responding ($fails)"
            AppLog.add("Health check failed ($fails): ${e.message} — traffic blocked, real IP stays hidden")
            if (fails >= 3 && Store.autoFailover) {
                val list = Store.profiles()
                if (list.size > 1) {
                    val i = list.indexOfFirst { it.id == p.id }
                    val next = list[(i + 1).coerceAtLeast(0) % list.size]
                    if (next.id != p.id) {
                        AppLog.add("Auto failover → ${next.name}")
                        Store.selectedId = next.id
                        fails = 0
                        worker.execute { apply(next.id) }
                    }
                }
            }
        } finally {
            checking = false
        }
    }

    private fun checkExitIp(p: ProxyProfile) {
        val r = ProxyTester.test(p)
        if (r.ok && current?.id == p.id) {
            exitIp = r.ip
            AppLog.add("Proxy IP: ${r.ip}")
        }
    }

    // ---------------- stop ----------------

    private fun resetState() {
        running = false; connecting = false
        profileId = null; profileName = ""; startedAt = 0
        upSpeed = 0; downSpeed = 0; totalUp = 0; totalDown = 0
        exitIp = ""; health = ""
        baseUp = 0; baseDown = 0; lastUp = 0; lastDown = 0
        current = null
    }

    private fun shutdown(msg: String?) {
        monitor?.cancel(false); monitor = null
        stopEngine()
        try { tun?.close() } catch (ignored: Throwable) {}
        tun = null
        resetState()
        if (msg != null) AppLog.add(msg)
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (ignored: Throwable) {}
        stopSelf()
    }

    // ---------------- notification ----------------

    private fun updateNotification(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
        } catch (ignored: Throwable) {}
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Proxy connection", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SnakeVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (profileName.isNotEmpty()) "Fleet Proxy · $profileName" else "Fleet Proxy"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_notify), "Disconnect", stop
                ).build()
            )
            .build()
    }
}
