package com.snake.proxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat
import com.snake.proxy.core.TProxyService
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class SnakeVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.snake.proxy.START"
        const val ACTION_STOP = "com.snake.proxy.STOP"
        const val ACTION_RELOAD = "com.snake.proxy.RELOAD"
        const val EXTRA_ID = "id"
        private const val NOTIF_ID = 7
        private const val CHANNEL = "vpn"

        const val ERR_GENERIC = 0
        const val ERR_COUNTRY_UNSUPPORTED = 1
        const val ERR_COUNTRY_UNAVAILABLE = 2
        const val ERR_PROXY_DOWN = 3

        // Read by the UI once per second
        @Volatile var running = false
        @Volatile var connecting = false
        @Volatile var profileId: String? = null
        @Volatile var profileName = ""
        @Volatile var startedAt = 0L
        @Volatile var exitIp = ""
        @Volatile var exitCc = ""
        @Volatile var exitCountry = ""
        @Volatile var exitCity = ""
        @Volatile var exitIsp = ""
        @Volatile var targetCc = ""
        @Volatile var health = ""
        @Volatile var lastError = ""
        @Volatile var lastErrorKind = ERR_GENERIC
        @Volatile var lastErrorCc = ""
        @Volatile var errorSeq = 0

        fun send(ctx: Context, action: String, id: String? = null) {
            val i = Intent(ctx, SnakeVpnService::class.java).setAction(action)
            if (id != null) i.putExtra(EXTRA_ID, id)
            if (action == ACTION_STOP) ctx.startService(i)
            else ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val worker = Executors.newSingleThreadScheduledExecutor()
    private val net = Executors.newCachedThreadPool()
    private var tun: ParcelFileDescriptor? = null
    private var relay: LocalRelay? = null
    private var engineOn = false
    private var current: ProxyProfile? = null      // with the country applied
    private var currentBaseId: String? = null
    private var monitor: ScheduledFuture<*>? = null
    private var tick = 0
    private var fails = 0
    @Volatile private var checking = false
    @Volatile private var reqSeq = 0              // newest connect/switch request wins
    private var appliedCc = ""

    /** Never lets a late task crash the app after the service has been destroyed. */
    private fun safeExec(r: () -> Unit) {
        try { worker.execute(r) } catch (ignored: Throwable) {}
    }
    private val logFile by lazy { File(filesDir, "hev.log") }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { reqSeq++; safeExec { shutdown("Disconnected") } }
            else -> {
                try { startForeground(NOTIF_ID, notification(if (running) "Switching…" else "Connecting…")) } catch (ignored: Throwable) {}
                val id = intent?.getStringExtra(EXTRA_ID) ?: Store.selectedId
                val seq = ++reqSeq
                connecting = true
                safeExec { apply(id, seq) }
            }
        }
        return START_STICKY
    }

    override fun onRevoke() {
        AppLog.add("VPN permission revoked or another VPN started")
        safeExec { shutdown(null) }
    }

    override fun onDestroy() {
        if (running || engineOn) {
            try { stopEngine() } catch (ignored: Throwable) {}
            try { tun?.close() } catch (ignored: Throwable) {}
            tun = null
            resetState()
        }
        worker.shutdownNow()
        net.shutdownNow()
        super.onDestroy()
    }

    // ---------------- connect / switch ----------------

    private fun apply(id: String?, seq: Int) {
        if (seq != reqSeq) return                 // a newer request is already queued
        val base = Store.get(id)
        if (base == null) {
            fail(ERR_GENERIC, "No proxy selected", "")
            return
        }
        val cc = Store.country
        connecting = true
        targetCc = cc
        var newRelay: LocalRelay? = null
        var newTun: ParcelFileDescriptor? = null
        try {
            TProxyService.getLoadError()?.let {
                throw Exception("Proxy engine failed to load: ${it.message}")
            }
            val ccLabel = if (cc.isEmpty()) "default location" else Countries.name(cc)
            AppLog.add("Connecting: ${base.name} → $ccLabel")

            // 1. Apply the chosen country to the proxy login
            val p = CountryRouting.apply(base, cc)
            if (p == null) {
                fail(ERR_COUNTRY_UNSUPPORTED, "${base.name} has a fixed location and can't switch to ${Countries.name(cc)}.", cc)
                return
            }

            // 2. Check the proxy works. With a country we must confirm the exit IP's country first;
            //    without one a quick login check is enough and the IP details load right after.
            val geo = if (cc.isNotEmpty()) GeoCheck.through(p) else quickCheck(p)
            if (seq != reqSeq) return             // user picked something else meanwhile
            if (!geo.ok) {
                if (cc.isNotEmpty()) {
                    fail(ERR_COUNTRY_UNAVAILABLE, "${Countries.name(cc)} is not available on this proxy. (${geo.error})", cc)
                } else {
                    fail(ERR_PROXY_DOWN, geo.error, "")
                }
                return
            }
            if (cc.isNotEmpty() && geo.cc.isNotEmpty() && !geo.cc.equals(cc, true)) {
                fail(
                    ERR_COUNTRY_UNAVAILABLE,
                    "${Countries.name(cc)} is not available on this proxy. It returned an IP in ${geo.country.ifEmpty { geo.cc }} instead.",
                    cc
                )
                return
            }

            if (seq != reqSeq) return

            // 3. Local relay (logs every connection) + new tunnel
            val r = LocalRelay(p) { host, port, ok, ms, err ->
                ConnLog.add(ConnEvent(System.currentTimeMillis(), Foreground.current(), host, port, ok, ms, err))
            }.start()
            newRelay = r
            val cfg = writeConfig(r.port)
            val t = buildTun(base) ?: throw Exception("VPN permission missing, tap Connect again")
            newTun = t

            // 4. Restart engine on the new tunnel
            stopEngine()
            relay = newRelay
            newRelay = null
            if (!TProxyService.TProxyStartService(cfg.absolutePath, t.fd)) {
                throw Exception("Proxy engine did not start")
            }
            engineOn = true
            val old = tun
            tun = t
            newTun = null
            try { old?.close() } catch (ignored: Throwable) {}

            current = p
            currentBaseId = base.id
            appliedCc = cc
            profileId = base.id
            profileName = base.name
            if (!running) startedAt = System.currentTimeMillis()
            running = true
            fails = 0
            exitIp = geo.ip
            exitCc = geo.cc
            exitCountry = geo.country
            exitCity = geo.city
            exitIsp = geo.isp
            health = "Proxy OK · ${geo.ms} ms"
            lastError = ""
            AppLog.add("Connected: ${geo.ip} ${geo.country}")
            updateNotification(if (geo.ip.isEmpty()) "Connected" else "${geo.country.ifEmpty { "Connected" }} · ${geo.ip}")
            startMonitor()
            if (geo.ip.isEmpty() || geo.cc.isEmpty()) {
                // fill in exit IP / country in the background (does not delay the connection)
                val mine = seq
                try {
                    net.execute {
                        val g = try { GeoCheck.through(p) } catch (e: Throwable) { null }
                        if (g != null && g.ok && mine == reqSeq && running) {
                            exitIp = g.ip; exitCc = g.cc; exitCountry = g.country; exitCity = g.city; exitIsp = g.isp
                            updateNotification("${g.country.ifEmpty { "Connected" }} · ${g.ip}")
                        }
                    }
                } catch (ignored: Throwable) {}
            }
        } catch (e: Throwable) {
            try { newRelay?.stop() } catch (ignored: Throwable) {}
            try { newTun?.close() } catch (ignored: Throwable) {}
            if (seq == reqSeq) fail(ERR_GENERIC, e.message ?: e.javaClass.simpleName, cc)
        } finally {
            if (seq == reqSeq) connecting = false
        }
    }

    /** Fast check: login through the proxy and open a connection (no IP lookup). */
    private fun quickCheck(p: ProxyProfile): GeoInfo {
        val t0 = android.os.SystemClock.elapsedRealtime()
        return try {
            ProxyDialer.open(p, "1.1.1.1", 443, 8000).close()
            GeoInfo(true, "", ms = android.os.SystemClock.elapsedRealtime() - t0)
        } catch (e: Throwable) {
            GeoInfo(false, error = e.message ?: "Proxy unreachable")
        }
    }

    private fun fail(kind: Int, msg: String, cc: String) {
        AppLog.add("Connect failed: $msg")
        lastError = msg
        lastErrorKind = kind
        lastErrorCc = cc
        errorSeq++
        connecting = false
        if (!running) shutdown(null)
        else {
            // switch failed: keep the working connection and put the selection back so the UI matches it
            currentBaseId?.let { Store.selectedId = it }
            Store.country = appliedCc
            updateNotification("Kept previous connection")
        }
    }

    private fun buildTun(p: ProxyProfile): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("Fleet Proxy: ${p.name}")
            .setMtu(8500)
            .addAddress("198.18.0.1", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("198.18.0.2")
        try {
            b.addAddress("fc00::1", 128)
            b.addRoute("::", 0)
        } catch (e: Throwable) {
            AppLog.add("IPv6 not added: ${e.message}")
        }
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)

        val apps = Store.apps
        when (Store.appMode) {
            Store.MODE_ONLY -> {
                var n = 0
                apps.filter { it != packageName }.forEach {
                    try { b.addAllowedApplication(it); n++ } catch (ignored: Throwable) {}
                }
                if (n == 0) {
                    AppLog.add("No apps selected, routing all apps")
                    b.addDisallowedApplication(packageName)
                }
            }
            Store.MODE_EXCLUDE -> {
                b.addDisallowedApplication(packageName)
                apps.forEach { try { b.addDisallowedApplication(it) } catch (ignored: Throwable) {} }
            }
            else -> b.addDisallowedApplication(packageName)
        }

        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        b.setConfigureIntent(pi)
        return b.establish()
    }

    private fun writeConfig(relayPort: Int): File {
        try { logFile.writeText("") } catch (ignored: Throwable) {}
        val text = buildString {
            appendLine("tunnel:")
            appendLine("  mtu: 8500")
            appendLine("  ipv4: 198.18.0.1")
            appendLine("  ipv6: 'fc00::1'")
            appendLine("socks5:")
            appendLine("  port: $relayPort")
            appendLine("  address: '127.0.0.1'")
            appendLine("  udp: 'udp'")
            appendLine("mapdns:")
            appendLine("  address: 198.18.0.2")
            appendLine("  port: 53")
            appendLine("  network: 100.64.0.0")
            appendLine("  netmask: 255.192.0.0")
            appendLine("  cache-size: 10000")
            appendLine("misc:")
            appendLine("  task-stack-size: 81920")
            appendLine("  log-file: '${logFile.absolutePath}'")
            appendLine("  log-level: ${if (Store.debugLog) "debug" else "warn"}")
        }
        val f = File(filesDir, "tunnel.yml")
        f.writeText(text)
        return f
    }

    private fun stopEngine() {
        if (engineOn) {
            try { TProxyService.TProxyStopService() } catch (ignored: Throwable) {}
            engineOn = false
        }
        try { relay?.stop() } catch (ignored: Throwable) {}
        relay = null
    }

    // ---------------- monitor ----------------

    private fun startMonitor() {
        if (monitor != null) return
        monitor = worker.scheduleAtFixedRate({
            try { onTick() } catch (ignored: Throwable) {}
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun onTick() {
        tick++
        if (tick % 2 == 0) Foreground.refresh(this)
        if (tick % 15 == 0 && !checking) {
            current?.let { p -> checking = true; net.execute { healthCheck(p) } }
        }
        if (tick % 60 == 0) {
            try {
                if (logFile.length() > 2_000_000) RandomAccessFile(logFile, "rw").use { it.setLength(0) }
            } catch (ignored: Throwable) {}
        }
        if (tick % 300 == 0 && Store.autoSync && Store.subUrl.isNotBlank()) {
            net.execute { SubSync.sync() }
        }
    }

    private fun healthCheck(p: ProxyProfile) {
        try {
            val t0 = System.currentTimeMillis()
            ProxyDialer.open(p, "1.1.1.1", 443, 7000).close()
            val ms = System.currentTimeMillis() - t0
            if (fails > 0) AppLog.add("Proxy is back online")
            fails = 0
            health = "Proxy OK · $ms ms"
        } catch (e: Throwable) {
            fails++
            health = "Proxy not responding ($fails)"
            AppLog.add("Health check failed ($fails): ${e.message} — traffic blocked, real IP stays hidden")
            if (fails >= 3 && Store.autoFailover) {
                val list = Store.profiles()
                if (list.size > 1) {
                    val i = list.indexOfFirst { it.id == currentBaseId }
                    val next = list[(i + 1).coerceAtLeast(0) % list.size]
                    if (next.id != currentBaseId) {
                        AppLog.add("Auto failover → ${next.name}")
                        Store.selectedId = next.id
                        fails = 0
                        val seq = ++reqSeq
                        connecting = true
                        safeExec { apply(next.id, seq) }
                    }
                }
            }
        } finally {
            checking = false
        }
    }

    // ---------------- stop ----------------

    private fun resetState() {
        running = false; connecting = false
        profileId = null; profileName = ""; startedAt = 0
        exitIp = ""; exitCc = ""; exitCountry = ""; exitCity = ""; exitIsp = ""
        health = ""
        current = null; currentBaseId = null; appliedCc = ""
    }

    private fun shutdown(msg: String?) {
        monitor?.cancel(false); monitor = null
        stopEngine()
        try { tun?.close() } catch (ignored: Throwable) {}
        tun = null
        resetState()
        ConnLog.clear()                       // activity log starts fresh on every new connection
        if (msg != null) AppLog.add(msg)
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (ignored: Throwable) {}
        stopSelf()
    }

    // ---------------- notification ----------------

    private fun updateNotification(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
        } catch (ignored: Throwable) {}
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Proxy connection", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SnakeVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (profileName.isNotEmpty()) "Fleet Proxy · $profileName" else "Fleet Proxy"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_notify), "Disconnect", stop
                ).build()
            )
            .build()
    }
}
