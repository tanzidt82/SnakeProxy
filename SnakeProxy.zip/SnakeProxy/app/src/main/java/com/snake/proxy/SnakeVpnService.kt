package com.snake.proxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.snake.proxy.core.TProxyService
import java.io.File
import java.io.RandomAccessFile
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class SnakeVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.snake.proxy.START"
        const val ACTION_STOP = "com.snake.proxy.STOP"
        const val ACTION_RELOAD = "com.snake.proxy.RELOAD"
        const val EXTRA_ID = "id"
        private const val NOTIF_ID = 7
        private const val CHANNEL = "vpn"

        // UI এগুলো প্রতি সেকেন্ডে পড়ে
        @Volatile var running = false
        @Volatile var connecting = false
        @Volatile var profileId: String? = null
        @Volatile var profileName = ""
        @Volatile var startedAt = 0L
        @Volatile var upSpeed = 0L
        @Volatile var downSpeed = 0L
        @Volatile var totalUp = 0L
        @Volatile var totalDown = 0L
        @Volatile var exitIp = ""
        @Volatile var health = ""

        fun send(ctx: Context, action: String, id: String? = null) {
            val i = Intent(ctx, SnakeVpnService::class.java).setAction(action)
            if (id != null) i.putExtra(EXTRA_ID, id)
            if (action == ACTION_STOP) ctx.startService(i)
            else androidx.core.content.ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val worker = Executors.newSingleThreadScheduledExecutor()
    private val net = Executors.newCachedThreadPool()
    private var tun: ParcelFileDescriptor? = null
    private var bridge: HttpBridge? = null
    private var engineOn = false
    private var current: ProxyProfile? = null
    private var monitor: ScheduledFuture<*>? = null
    private var tick = 0
    private var fails = 0
    @Volatile private var checking = false
    private var lastUp = 0L
    private var lastDown = 0L
    private var baseUp = 0L
    private var baseDown = 0L
    private val logFile by lazy { File(filesDir, "hev.log") }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> worker.execute { shutdown("ডিসকানেক্ট করা হয়েছে") }
            else -> {
                // ACTION_START, ACTION_RELOAD, বা সিস্টেমের Always-on চালু
                startForeground(NOTIF_ID, notification("কানেক্ট হচ্ছে..."))
                val id = intent?.getStringExtra(EXTRA_ID) ?: Store.selectedId
                worker.execute { apply(id) }
            }
        }
        return START_STICKY
    }

    override fun onRevoke() {
        AppLog.add("⚠ অন্য VPN চালু হওয়ায় বা অনুমতি বাতিল হওয়ায় বন্ধ হয়েছে")
        worker.execute { shutdown(null) }
    }

    override fun onDestroy() {
        if (running || engineOn) {
            try { stopEngine() } catch (_: Exception) {}
            try { tun?.close() } catch (_: Exception) {}
            tun = null
            resetState()
        }
        worker.shutdownNow()
        net.shutdownNow()
        super.onDestroy()
    }

    // ---------------- কানেক্ট / প্রক্সি বদল ----------------

    private fun apply(id: String?) {
        val p = Store.get(id)
        if (p == null) {
            AppLog.add("❌ কোনো প্রক্সি বাছাই করা নেই")
            if (!running) shutdown(null)
            return
        }
        connecting = true
        var newBridge: HttpBridge? = null
        try {
            AppLog.add("কানেক্ট হচ্ছে: ${p.name} (${p.type} ${p.host}:${p.port})")

            // ১. ইঞ্জিনের জন্য SOCKS5 ঠিকানা তৈরি
            val socksHost: String
            val socksPort: Int
            val user: String
            val pass: String
            if (p.type == "HTTP") {
                newBridge = HttpBridge(p).start()
                socksHost = "127.0.0.1"; socksPort = newBridge.port; user = ""; pass = ""
            } else {
                socksHost = InetAddress.getByName(p.host).hostAddress
                    ?: throw Exception("প্রক্সির ঠিকানা খুঁজে পাওয়া যায়নি")
                socksPort = p.port; user = p.user; pass = p.pass
            }
            val cfg = writeConfig(socksHost, socksPort, user, pass)

            // ২. নতুন VPN ইন্টারফেস (পুরনোটা বন্ধের আগেই, যাতে ফাঁকে লিক না হয়)
            val newTun = buildTun(p) ?: throw Exception("VPN অনুমতি নেই, অ্যাপ থেকে আবার কানেক্ট চাপুন")

            // ৩. ইঞ্জিন রিস্টার্ট
            stopEngine()
            bridge = newBridge
            newBridge = null
            TProxyService.TProxyStartService(cfg.absolutePath, newTun.fd)
            engineOn = true
            val old = tun
            tun = newTun
            try { old?.close() } catch (_: Exception) {}

            current = p
            profileId = p.id
            profileName = p.name
            if (!running) startedAt = System.currentTimeMillis()
            running = true
            fails = 0
            exitIp = ""
            health = "চেক হচ্ছে..."
            AppLog.add("✅ সংযুক্ত: ${p.name}")
            startMonitor()
            net.execute { checkExitIp(p) }
        } catch (e: Exception) {
            newBridge?.stop()
            AppLog.add("❌ কানেক্ট ব্যর্থ: ${e.message}")
            health = "❌ ${e.message}"
            if (!running) shutdown(null)
        } finally {
            connecting = false
        }
    }

    private fun buildTun(p: ProxyProfile): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("SnakeProxy: ${p.name}")
            .setMtu(8500)
            .addAddress("198.18.0.1", 32)
            .addRoute("0.0.0.0", 0)          // সব IPv4 ট্রাফিক
            .addDnsServer("198.18.0.2")      // DNS প্রক্সির ভেতর দিয়ে যাবে
        try {
            b.addAddress("fc00::1", 128)
            b.addRoute("::", 0)               // সব IPv6 ট্রাফিক (IPv6 লিক বন্ধ)
        } catch (e: Exception) {
            AppLog.add("⚠ IPv6 যোগ করা যায়নি: ${e.message}")
        }
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)

        val apps = Store.apps
        when (Store.appMode) {
            Store.MODE_ONLY -> {
                var n = 0
                apps.filter { it != packageName }.forEach {
                    try { b.addAllowedApplication(it); n++ } catch (_: Exception) {}
                }
                if (n == 0) {
                    AppLog.add("⚠ কোনো অ্যাপ বাছাই করা নেই, তাই সব অ্যাপ প্রক্সিতে যাবে")
                    b.addDisallowedApplication(packageName)
                }
            }
            Store.MODE_EXCLUDE -> {
                b.addDisallowedApplication(packageName)
                apps.forEach { try { b.addDisallowedApplication(it) } catch (_: Exception) {} }
            }
            else -> b.addDisallowedApplication(packageName) // এই অ্যাপ নিজে বাইরে থাকে (লুপ এড়াতে)
        }

        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        b.setConfigureIntent(pi)
        return b.establish()
    }

    private fun q(s: String) = "'" + s.replace("'", "''") + "'"

    private fun writeConfig(host: String, port: Int, user: String, pass: String): File {
        try { logFile.writeText("") } catch (_: Exception) {}
        val text = buildString {
            appendLine("tunnel:")
            appendLine("  mtu: 8500")
            appendLine("  ipv4: 198.18.0.1")
            appendLine("  ipv6: 'fc00::1'")
            appendLine("socks5:")
            appendLine("  port: $port")
            appendLine("  address: ${q(host)}")
            appendLine("  udp: 'udp'")
            if (user.isNotEmpty()) {
                appendLine("  username: ${q(user)}")
                appendLine("  password: ${q(pass)}")
            }
            appendLine("mapdns:")
            appendLine("  address: 198.18.0.2")
            appendLine("  port: 53")
            appendLine("  network: 100.64.0.0")
            appendLine("  netmask: 255.192.0.0")
            appendLine("  cache-size: 10000")
            appendLine("misc:")
            appendLine("  task-stack-size: 81920")
            appendLine("  log-file: ${q(logFile.absolutePath)}")
            appendLine("  log-level: ${if (Store.debugLog) "debug" else "warn"}")
        }
        val f = File(filesDir, "tunnel.yml")
        f.writeText(text)
        return f
    }

    private fun stopEngine() {
        if (engineOn) {
            try {
                TProxyService.TProxyGetStats()?.let { s ->
                    if (s.size >= 4) { baseUp += s[1]; baseDown += s[3] }
                }
            } catch (_: Exception) {}
            try { TProxyService.TProxyStopService() } catch (_: Exception) {}
            engineOn = false
            lastUp = 0; lastDown = 0
        }
        bridge?.stop()
        bridge = null
    }

    // ---------------- লাইভ মনিটর ----------------

    private fun startMonitor() {
        if (monitor != null) return
        monitor = worker.scheduleAtFixedRate({
            try { onTick() } catch (_: Exception) {}
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun onTick() {
        tick++
        if (engineOn) {
            TProxyService.TProxyGetStats()?.let { s ->
                if (s.size >= 4) {
                    val up = s[1]; val down = s[3]
                    upSpeed = (up - lastUp).coerceAtLeast(0)
                    downSpeed = (down - lastDown).coerceAtLeast(0)
                    lastUp = up; lastDown = down
                    totalUp = baseUp + up; totalDown = baseDown + down
                }
            }
        }
        if (tick % 2 == 0) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIF_ID, notification("↑ ${Fmt.speed(upSpeed)}   ↓ ${Fmt.speed(downSpeed)}"))
        }
        if (tick % 10 == 0 && !checking) {
            current?.let { p -> checking = true; net.execute { healthCheck(p) } }
        }
        if (tick % 60 == 0) {
            try { if (logFile.length() > 2_000_000) RandomAccessFile(logFile, "rw").use { it.setLength(0) } } catch (_: Exception) {}
        }
        if (tick % 300 == 0 && Store.autoSync && Store.subUrl.isNotBlank()) {
            net.execute { SubSync.sync() }
        }
    }

    private fun healthCheck(p: ProxyProfile) {
        try {
            val t0 = System.currentTimeMillis()
            ProxyDialer.open(p, "1.1.1.1", 443, 7000).close()
            val ms = System.currentTimeMillis() - t0
            if (fails > 0) AppLog.add("✅ প্রক্সি আবার কাজ করছে")
            fails = 0
            health = "✅ প্রক্সি ঠিক আছে (${ms}ms)"
            if (exitIp.isEmpty()) checkExitIp(p)
        } catch (e: Exception) {
            fails++
            health = "⚠ প্রক্সি সাড়া দিচ্ছে না ($fails): ${e.message}"
            AppLog.add("⚠ হেলথ চেক ব্যর্থ ($fails): ${e.message}  — নেট বন্ধ থাকবে, আসল IP দেখাবে না")
            if (fails >= 3 && Store.autoFailover) {
                val list = Store.profiles()
                if (list.size > 1) {
                    val i = list.indexOfFirst { it.id == p.id }
                    val next = list[(i + 1).coerceAtLeast(0) % list.size]
                    if (next.id != p.id) {
                        AppLog.add("🔁 অটো-ফেইলওভার: ${next.name} এ যাচ্ছি")
                        Store.selectedId = next.id
                        fails = 0
                        worker.execute { apply(next.id) }
                    }
                }
            }
        } finally {
            checking = false
        }
    }

    private fun checkExitIp(p: ProxyProfile) {
        val r = ProxyTester.test(p)
        if (r.ok && current?.id == p.id) {
            exitIp = r.ip
            AppLog.add("🌐 প্রক্সি IP: ${r.ip}")
        }
    }

    // ---------------- বন্ধ ----------------

    private fun resetState() {
        running = false; connecting = false
        profileId = null; profileName = ""; startedAt = 0
        upSpeed = 0; downSpeed = 0; totalUp = 0; totalDown = 0
        exitIp = ""; health = ""
        baseUp = 0; baseDown = 0; lastUp = 0; lastDown = 0
        current = null
    }

    private fun shutdown(msg: String?) {
        monitor?.cancel(false); monitor = null
        stopEngine()
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        resetState()
        if (msg != null) AppLog.add(msg)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------- নোটিফিকেশন ----------------

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "প্রক্সি সংযোগ", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SnakeVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (profileName.isNotEmpty()) "SnakeProxy • $profileName" else "SnakeProxy"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "ডিসকানেক্ট", stop).build())
            .build()
    }
}
