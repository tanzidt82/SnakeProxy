package com.snake.proxy

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Shared header (back button + title) used by every inner screen. */
fun Activity.setupHeader(title: String) {
    findViewById<TextView>(R.id.tvTitle).text = title
    findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
}

/** Pill segmented control: highlights the selected option. */
fun styleSegments(selected: Int, vararg segs: TextView) {
    segs.forEachIndexed { i, tv ->
        if (i == selected) {
            tv.setBackgroundResource(R.drawable.bg_segment_on)
            tv.setTextColor(ContextCompat.getColor(tv.context, R.color.btn_text))
        } else {
            tv.background = null
            tv.setTextColor(ContextCompat.getColor(tv.context, R.color.text))
        }
    }
}

object Palette {
    fun ok(v: View) = ContextCompat.getColor(v.context, R.color.mint_dark)
    fun bad(v: View) = ContextCompat.getColor(v.context, R.color.red)
    fun warn(v: View) = ContextCompat.getColor(v.context, R.color.amber)
    fun muted(v: View) = ContextCompat.getColor(v.context, R.color.text2)
}

/** Round country flag: code text underneath, flag image on top once loaded. */
fun bindFlag(code: TextView?, flag: ImageView, cc: String) {
    code?.text = cc.uppercase()
    code?.visibility = View.VISIBLE
    Img.load(flag, if (cc.length == 2) Img.flagUrl(cc) else null) { ok ->
        code?.visibility = if (ok) View.INVISIBLE else View.VISIBLE
    }
}

/** Provider tile: first letter underneath, provider icon on top once loaded. */
fun bindProvider(letter: TextView, icon: ImageView, host: String, name: String) {
    letter.text = name.trim().firstOrNull()?.uppercase() ?: "P"
    letter.visibility = View.VISIBLE
    Img.load(icon, Providers.iconUrl(host)) { ok ->
        letter.visibility = if (ok) View.INVISIBLE else View.VISIBLE
    }
}

/** Premium animated popup used for errors, confirmations and results. */
object Glass {
    const val INFO = 0
    const val OK = 1
    const val WARN = 2
    const val ERROR = 3

    fun show(
        a: Activity,
        kind: Int,
        title: String,
        message: String,
        primary: String = "OK",
        onPrimary: (() -> Unit)? = null,
        secondary: String? = null,
        onSecondary: (() -> Unit)? = null,
        flagCc: String? = null
    ): Dialog {
        val v = LayoutInflater.from(a).inflate(R.layout.dialog_glass, null)
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(v)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        d.window?.setDimAmount(0.45f)

        val icon = v.findViewById<ImageView>(R.id.dlgIcon)
        val halo = v.findViewById<View>(R.id.dlgHalo)
        when (kind) {
            OK -> {
                icon.setImageResource(R.drawable.ic_check_circle)
                icon.setColorFilter(ContextCompat.getColor(a, R.color.mint_dark))
                halo.setBackgroundResource(R.drawable.bg_pill_ok)
            }
            WARN -> {
                icon.setImageResource(R.drawable.ic_location)
                icon.setColorFilter(ContextCompat.getColor(a, R.color.amber))
                halo.setBackgroundResource(R.drawable.bg_pill_warn)
            }
            ERROR -> {
                icon.setImageResource(R.drawable.ic_error)
                icon.setColorFilter(ContextCompat.getColor(a, R.color.red))
                halo.setBackgroundResource(R.drawable.bg_pill_bad)
            }
            else -> {
                icon.setImageResource(R.drawable.ic_shield)
                icon.setColorFilter(ContextCompat.getColor(a, R.color.mint_dark))
                halo.setBackgroundResource(R.drawable.bg_icon_circle)
            }
        }
        if (!flagCc.isNullOrEmpty()) {
            v.findViewById<View>(R.id.dlgFlagBox).visibility = View.VISIBLE
            bindFlag(v.findViewById(R.id.dlgFlagCc), v.findViewById(R.id.dlgFlag), flagCc)
        }
        v.findViewById<TextView>(R.id.dlgTitle).text = title
        v.findViewById<TextView>(R.id.dlgMsg).text = message
        v.findViewById<TextView>(R.id.dlgPrimary).apply {
            text = primary
            setOnClickListener { d.dismiss(); onPrimary?.invoke() }
        }
        if (secondary != null) {
            v.findViewById<TextView>(R.id.dlgSecondary).apply {
                visibility = View.VISIBLE
                text = secondary
                setOnClickListener { d.dismiss(); onSecondary?.invoke() }
            }
        }

        val card = v.findViewById<View>(R.id.dlgCard)
        card.alpha = 0f
        card.scaleX = 0.86f
        card.scaleY = 0.86f
        d.show()
        card.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(320).setInterpolator(OvershootInterpolator(1.4f)).start()
        icon.rotation = -25f
        icon.animate().rotation(0f).setDuration(420).setInterpolator(OvershootInterpolator(2f)).start()
        return d
    }
}
