package com.snake.proxy

import android.app.Activity
import android.graphics.Color
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Shared header (back button + title) used by every inner screen. */
fun Activity.setupHeader(title: String) {
    findViewById<TextView>(R.id.tvTitle).text = title
    findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
}

/** Pill segmented control: highlights the selected option. */
fun styleSegments(selected: Int, vararg segs: TextView) {
    segs.forEachIndexed { i, tv ->
        if (i == selected) {
            tv.setBackgroundResource(R.drawable.bg_segment_on)
            tv.setTextColor(Color.WHITE)
        } else {
            tv.background = null
            tv.setTextColor(ContextCompat.getColor(tv.context, R.color.ink))
        }
    }
}

object Palette {
    fun ok(v: View) = ContextCompat.getColor(v.context, R.color.mint_dark)
    fun bad(v: View) = ContextCompat.getColor(v.context, R.color.red)
    fun warn(v: View) = ContextCompat.getColor(v.context, R.color.amber)
    fun muted(v: View) = ContextCompat.getColor(v.context, R.color.muted)
}
