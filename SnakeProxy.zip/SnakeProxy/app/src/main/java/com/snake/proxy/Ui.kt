package com.snake.proxy

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Shared header (back button + title) used by every inner screen. */
fun Activity.setupHeader(title: String) {
    findViewById<TextView>(R.id.tvTitle).text = title
    findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
}

/** Segmented control: the selected option glows blue. */
fun styleSegments(selected: Int, vararg segs: TextView) {
    segs.forEachIndexed { i, tv ->
        if (i == selected) {
            if (tv.background !is GlowDrawable) {
                tv.background = GlowDrawable(tv.context, GlowColors.BLUE, false, 12 * tv.resources.displayMetrics.density)
            }
            tv.setTextColor(android.graphics.Color.WHITE)
        } else {
            tv.background = null
            tv.setTextColor(ContextCompat.getColor(tv.context, R.color.text2))
        }
    }
}

object Palette {
    fun ok(v: View) = ContextCompat.getColor(v.context, R.color.mint_dark)
    fun bad(v: View) = ContextCompat.getColor(v.context, R.color.red)
    fun warn(v: View) = ContextCompat.getColor(v.context, R.color.amber)
    fun muted(v: View) = ContextCompat.getColor(v.context, R.color.text2)
}

/** Round country flag: code text underneath, flag image on top once loaded. */
fun bindFlag(code: TextView?, flag: ImageView, cc: String) {
    code?.text = cc.uppercase()
    code?.visibility = View.VISIBLE
    Img.load(flag, if (cc.length == 2) Img.flagUrl(cc) else null) { ok ->
        code?.visibility = if (ok) View.INVISIBLE else View.VISIBLE
    }
}

/** Provider tile: first letter underneath, provider icon on top once loaded. */
fun bindProvider(letter: TextView, icon: ImageView, host: String, name: String) {
    letter.text = name.trim().firstOrNull()?.uppercase() ?: "P"
    letter.visibility = View.VISIBLE
    Img.load(icon, Providers.iconUrl(host)) { ok ->
        letter.visibility = if (ok) View.INVISIBLE else View.VISIBLE
    }
}

/** Glowing popup used for errors, confirmations and results. */
object Glass {
    const val INFO = 0
    const val OK = 1
    const val WARN = 2
    const val ERROR = 3

    fun show(
        a: Activity,
        kind: Int,
        title: String,
        message: String,
        primary: String = "OK",
        onPrimary: (() -> Unit)? = null,
        secondary: String? = null,
        onSecondary: (() -> Unit)? = null,
        flagCc: String? = null
    ): Dialog {
        val v = LayoutInflater.from(a).inflate(R.layout.dialog_glass, null)
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(v)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        d.window?.setDimAmount(0.6f)

        val card = v.findViewById<GlowLayout>(R.id.dlgCard)
        val icon = v.findViewById<ImageView>(R.id.dlgIcon)
        val (col, ic) = when (kind) {
            OK -> GlowColors.GREEN to R.drawable.ic_check_circle
            WARN -> GlowColors.PURPLE to R.drawable.ic_location
            ERROR -> GlowColors.RED to R.drawable.ic_error
            else -> GlowColors.BLUE to R.drawable.ic_shield
        }
        card.setGlow(col)
        icon.setImageResource(ic)
        icon.setColorFilter(col)
        if (!flagCc.isNullOrEmpty()) {
            v.findViewById<View>(R.id.dlgFlagBox).visibility = View.VISIBLE
            bindFlag(null, v.findViewById(R.id.dlgFlag), flagCc)
        }
        v.findViewById<TextView>(R.id.dlgTitle).text = title
        v.findViewById<TextView>(R.id.dlgMsg).text = message
        v.findViewById<TextView>(R.id.dlgPrimary).apply {
            text = "$primary  →"
            setOnClickListener { d.dismiss(); onPrimary?.invoke() }
        }
        if (secondary != null) {
            v.findViewById<TextView>(R.id.dlgSecondary).apply {
                visibility = View.VISIBLE
                text = secondary
                setOnClickListener { d.dismiss(); onSecondary?.invoke() }
            }
        }
        card.alpha = 0f
        card.scaleX = 0.88f
        card.scaleY = 0.88f
        card.translationY = 40f
        d.show()
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(360).setInterpolator(OvershootInterpolator(1.2f)).start()
        return d
    }
}

/** Tactile 3D press feedback + entrance animations. */
object Motion {
    private val press = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.96f).scaleY(0.96f).translationZ(-4f).setDuration(110).start()
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(240)
                    .setInterpolator(OvershootInterpolator(2.2f)).start()
        }
        false
    }

    /** Adds press feedback to every clickable view with a background under [root]. */
    fun pressable(root: View) {
        if (root.isClickable && root.tag != "noPress" && root !is android.widget.EditText &&
            (root.background != null || root is ImageView)
        ) {
            root.setOnTouchListener(press)
        }
        if (root is ViewGroup && root !is androidx.recyclerview.widget.RecyclerView) {
            for (i in 0 until root.childCount) pressable(root.getChildAt(i))
        }
    }

    /** Fades and lifts children in one after another. */
    fun stagger(vararg views: View, start: Long = 0) {
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 40f
            v.animate().alpha(1f).translationY(0f).setStartDelay(start + i * 70L).setDuration(420)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        }
    }
}
