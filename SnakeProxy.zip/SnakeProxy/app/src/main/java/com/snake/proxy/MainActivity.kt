package com.snake.proxy

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.transition.ChangeBounds
import android.transition.TransitionManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** An installed app shown in the Apps tab. */
data class AppItem(val pkg: String, val label: String, val info: ApplicationInfo)

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAB_HOME = 0
        const val TAB_PROXY = 1
        const val TAB_APPS = 2
        const val TAB_LOGS = 3
        const val TAB_LOC = 4
        val POPULAR = listOf("US", "GB", "DE", "SG", "JP")
    }

    private val ui = Handler(Looper.getMainLooper())
    private val bg = Executors.newCachedThreadPool()
    private var tab = 0
    private lateinit var pages: List<View>
    private lateinit var navItems: List<LinearLayout>
    private lateinit var navIcons: List<ImageView>
    private lateinit var navLabels: List<TextView>
    private lateinit var navBar: GlowLayout
    private lateinit var navPower: View
    private lateinit var ivPower: ImageView

    // home
    private lateinit var hero: GlowLayout
    private lateinit var ring: RingView
    private lateinit var tvState: TextView
    private lateinit var tvStatusPill: TextView
    private lateinit var shieldBox: View
    private lateinit var ivShield: ImageView
    private lateinit var tvTimer: TextView
    private lateinit var tvRingSub: TextView
    private lateinit var tvIp: TextView
    private lateinit var tvLoc: TextView
    private lateinit var ivLocFlag: ImageView
    private lateinit var chipRow: LinearLayout
    private lateinit var proxyCard: GlowLayout
    private lateinit var tvProvLetter: TextView
    private lateinit var ivProv: ImageView
    private lateinit var ivProvAuto: ImageView
    private lateinit var tvProxyName: TextView
    private lateinit var tvProxyHost: TextView
    private lateinit var tvProxyPing: TextView

    // lists
    private lateinit var countryAdapter: CountryAdapter
    private lateinit var proxyAdapter: ProxyAdapter
    private lateinit var appAdapter: AppAdapter
    private lateinit var logAdapter: LogAdapter
    private lateinit var rvLogs: RecyclerView
    private var logFilter = 0
    private var lastLogVersion = -1
    private var region = "All"
    private var autoTested = false

    // apps tab
    private var appsLoaded = false
    private var appsDirty = false

    private var state = -1
    private var lastErrSeq = 0
    private var lastIpBound = "?"
    private var lastChipBound = "?"
    private var lastProxyBound = "?"

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpn()
        else toast("VPN permission is required")
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateHome()
            if (tab == TAB_LOGS) refreshLogs(false)
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lastErrSeq = SnakeVpnService.errorSeq

        pages = listOf(
            findViewById(R.id.pageHome), findViewById(R.id.pageProxies),
            findViewById(R.id.pageApps), findViewById(R.id.pageLogs), findViewById(R.id.pageLocations)
        )
        navBar = findViewById(R.id.navBar)
        navPower = findViewById(R.id.navPower)
        ivPower = findViewById(R.id.ivPower)
        navItems = listOf(findViewById(R.id.navHome), findViewById(R.id.navProxy), findViewById(R.id.navApps), findViewById(R.id.navLogs))
        navIcons = listOf(findViewById(R.id.ivNavHome), findViewById(R.id.ivNavProxy), findViewById(R.id.ivNavApps), findViewById(R.id.ivNavLogs))
        navLabels = listOf(findViewById(R.id.tvNavHome), findViewById(R.id.tvNavProxy), findViewById(R.id.tvNavApps), findViewById(R.id.tvNavLogs))
        navItems.forEachIndexed { i, v -> v.setOnClickListener { showTab(i) } }
        navPower.setOnClickListener {
            it.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).withEndAction {
                it.animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(2.6f)).start()
            }.start()
            onConnectClick()
        }

        setupHome()
        setupLocations()
        setupProxies()
        setupApps()
        setupLogs()
        val start = savedInstanceState?.getInt("tab") ?: TAB_HOME
        showTab(if (start > TAB_LOGS) TAB_HOME else start, animate = false)
        Motion.pressable(findViewById(android.R.id.content))

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (tab != TAB_HOME) showTab(TAB_HOME)
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        refreshProxies()
        refreshCountries()
        lastChipBound = "?"; lastProxyBound = "?"; lastIpBound = "?"
        findViewById<View>(R.id.usageBanner).visibility =
            if (Foreground.hasPermission(this)) View.GONE else View.VISIBLE
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
        applyAppChanges()
    }

    // ======================= tabs & nav =======================

    private fun showTab(i: Int, animate: Boolean = true) {
        if (tab == TAB_APPS && i != TAB_APPS) applyAppChanges()
        if (tab == TAB_LOC && i != TAB_LOC) hideKeyboard()
        tab = i
        pages.forEachIndexed { idx, p -> p.visibility = if (idx == i) View.VISIBLE else View.GONE }
        navBar.visibility = if (i == TAB_LOC) View.GONE else View.VISIBLE
        styleNav(if (i == TAB_LOC) TAB_HOME else i, animate)

        if (animate) {
            val p = pages[i]
            p.alpha = 0f
            p.translationY = 28f
            p.animate().alpha(1f).translationY(0f).setDuration(320)
                .setInterpolator(DecelerateInterpolator(1.8f)).start()
        }
        when (i) {
            TAB_HOME -> { lastChipBound = "?"; updateHome() }
            TAB_LOC -> { refreshCountries(); findViewById<RecyclerView>(R.id.rvCountries).scheduleLayoutAnimation() }
            TAB_PROXY -> {
                refreshProxies()
                findViewById<RecyclerView>(R.id.rvProxies).scheduleLayoutAnimation()
                if (!autoTested && proxyAdapter.items.isNotEmpty()) { autoTested = true; proxyAdapter.items.forEach { testOne(it) } }
            }
            TAB_APPS -> loadApps()
            TAB_LOGS -> refreshLogs(true)
        }
    }

    /** Active tab grows into a glowing pill with its label beside the icon. */
    private fun styleNav(active: Int, animate: Boolean) {
        if (animate) TransitionManager.beginDelayedTransition(navBar, ChangeBounds().setDuration(260))
        val d = resources.displayMetrics.density
        val muted = ContextCompat.getColor(this, R.color.text2)
        navItems.forEachIndexed { idx, v ->
            val on = idx == active
            val lp = v.layoutParams as LinearLayout.LayoutParams
            if (on) {
                v.orientation = LinearLayout.HORIZONTAL
                v.setBackgroundResource(R.drawable.bg_nav_active)
                v.elevation = 6 * d
                lp.weight = 0f
                lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                v.setPadding((14 * d).toInt(), 0, (16 * d).toInt(), 0)
                navLabels[idx].textSize = 13f
                (navLabels[idx].layoutParams as LinearLayout.LayoutParams).apply { topMargin = 0; marginStart = (8 * d).toInt() }
                navLabels[idx].setTextColor(Color.WHITE)
                navIcons[idx].setColorFilter(Color.WHITE)
            } else {
                v.orientation = LinearLayout.VERTICAL
                v.background = null
                v.elevation = 0f
                lp.weight = 1f
                lp.width = 0
                v.setPadding((4 * d).toInt(), 0, (4 * d).toInt(), 0)
                navLabels[idx].textSize = 10.5f
                (navLabels[idx].layoutParams as LinearLayout.LayoutParams).apply { topMargin = (3 * d).toInt(); marginStart = 0 }
                navLabels[idx].setTextColor(muted)
                navIcons[idx].setColorFilter(muted)
            }
            v.layoutParams = lp
        }
    }

    private fun openLocations(search: Boolean) {
        showTab(TAB_LOC)
        val et = findViewById<EditText>(R.id.etCountry)
        if (search) {
            et.requestFocus()
            et.postDelayed({
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(et, 0)
            }, 150)
        }
    }

    private fun openSettings() = startActivity(Intent(this, SettingsActivity::class.java))

    // ======================= home =======================

    private fun setupHome() {
        hero = findViewById(R.id.heroCard)
        ring = findViewById(R.id.ring)
        tvState = findViewById(R.id.tvState)
        tvStatusPill = findViewById(R.id.tvStatusPill)
        shieldBox = findViewById(R.id.shieldBox)
        ivShield = findViewById(R.id.ivShield)
        tvTimer = findViewById(R.id.tvTimer)
        tvRingSub = findViewById(R.id.tvRingSub)
        tvIp = findViewById(R.id.tvIp)
        tvLoc = findViewById(R.id.tvLoc)
        ivLocFlag = findViewById(R.id.ivLocFlag)
        chipRow = findViewById(R.id.chipRow)
        proxyCard = findViewById(R.id.proxyCard)
        tvProvLetter = findViewById(R.id.tvProvLetter)
        ivProv = findViewById(R.id.ivProv)
        ivProvAuto = findViewById(R.id.ivProvAuto)
        tvProxyName = findViewById(R.id.tvProxyName)
        tvProxyHost = findViewById(R.id.tvProxyHost)
        tvProxyPing = findViewById(R.id.tvProxyPing)

        findViewById<View>(R.id.btnMenu).setOnClickListener { openSettings() }
        findViewById<View>(R.id.searchBar).setOnClickListener { openLocations(true) }
        findViewById<View>(R.id.btnAllLoc).setOnClickListener { openLocations(false) }
        findViewById<View>(R.id.btnSeeAll).setOnClickListener { showTab(TAB_PROXY) }
        proxyCard.setOnClickListener { if (Store.profiles().isEmpty()) openAdd() else showTab(TAB_PROXY) }
        ring.setOnClickListener { onConnectClick() }
    }

    private fun hideKeyboard() {
        val et = findViewById<EditText>(R.id.etCountry)
        et.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .hideSoftInputFromWindow(et.windowToken, 0)
    }

    private fun onConnectClick() {
        if (SnakeVpnService.running || SnakeVpnService.connecting) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_STOP)
            return
        }
        if (Store.get(Store.selectedId) == null) {
            if (Store.profiles().isEmpty()) {
                Glass.show(this, Glass.INFO, "Add a proxy", "Fleet Proxy needs your SOCKS5 or HTTP proxy.", "Add proxy", { openAdd() }, "Later")
            } else {
                toast("Select a proxy")
                showTab(TAB_PROXY)
            }
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPermission.launch(i) else startVpn()
    }

    private fun startVpn() {
        lastErrSeq = SnakeVpnService.errorSeq
        SnakeVpnService.send(this, SnakeVpnService.ACTION_START, Store.selectedId)
        applyState(1)
    }

    private fun applyState(s: Int) {
        if (s == state) return
        state = s
        val green = ContextCompat.getColor(this, R.color.green)
        val red = ContextCompat.getColor(this, R.color.red)
        val amber = ContextCompat.getColor(this, R.color.amber)
        when (s) {
            2 -> {
                hero.setGlow(GlowColors.BLUE)
                ring.state = RingView.ON
                shieldBox.visibility = View.GONE
                tvTimer.visibility = View.VISIBLE
                tvRingSub.text = "Protected"
                tvStatusPill.text = "●  Secured"
                tvStatusPill.setBackgroundResource(R.drawable.bg_pill_ok)
                tvStatusPill.setTextColor(green)
                setPower(2)
            }
            1 -> {
                hero.setGlow(GlowColors.AMBER)
                ring.state = RingView.CONNECTING
                shieldBox.visibility = View.VISIBLE
                ivShield.setImageResource(R.drawable.ic_shield)
                ivShield.setColorFilter(amber)
                tvTimer.visibility = View.GONE
                tvRingSub.text = "Connecting…"
                tvState.text = "Connecting…"
                tvStatusPill.text = "●  Connecting"
                tvStatusPill.setBackgroundResource(R.drawable.bg_pill_warn)
                tvStatusPill.setTextColor(amber)
                setPower(1)
            }
            else -> {
                hero.setGlow(GlowColors.RED)
                ring.state = RingView.OFF
                shieldBox.visibility = View.VISIBLE
                ivShield.setImageResource(R.drawable.ic_shield_off)
                ivShield.setColorFilter(red)
                tvTimer.visibility = View.GONE
                tvRingSub.text = "Tap power to connect"
                tvState.text = "Not connected"
                tvStatusPill.text = "●  Unprotected"
                tvStatusPill.setBackgroundResource(R.drawable.bg_pill_bad)
                tvStatusPill.setTextColor(red)
                setPower(0)
            }
        }
        lastIpBound = "?"; lastChipBound = "?"
        tvStatusPill.alpha = 0f
        tvStatusPill.animate().alpha(1f).setDuration(320).start()
        shieldBox.scaleX = 0.8f; shieldBox.scaleY = 0.8f
        shieldBox.animate().scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(OvershootInterpolator(2f)).start()
    }

    private fun setPower(st: Int) {
        navPower.setBackgroundResource(when (st) { 2 -> R.drawable.bg_power_on; 1 -> R.drawable.bg_power_wait; else -> R.drawable.bg_power_off })
        if (st == 0) ivPower.setColorFilter(ContextCompat.getColor(this, R.color.mint)) else ivPower.setColorFilter(Color.WHITE)
        navPower.elevation = (if (st == 0) 6 else 12) * resources.displayMetrics.density
        if (Build.VERSION.SDK_INT >= 28) {
            val c = if (st == 1) GlowColors.AMBER else GlowColors.BLUE
            navPower.outlineSpotShadowColor = c
            navPower.outlineAmbientShadowColor = c
        }
    }

    private fun updateHome() {
        val s = SnakeVpnService
        applyState(if (s.running) 2 else if (s.connecting) 1 else 0)
        if (s.running && s.startedAt > 0) tvTimer.text = Fmt.dur(System.currentTimeMillis() - s.startedAt)

        val cc = Store.country
        val ipKey = "${s.running}|${s.exitIp}|${s.exitCc}|${s.exitCity}|$cc"
        if (ipKey != lastIpBound) {
            lastIpBound = ipKey
            if (s.running) {
                val place = s.exitCountry.ifBlank { if (s.exitCc.isNotEmpty()) Countries.name(s.exitCc) else "" }
                tvState.text = if (place.isNotEmpty()) "Connected to $place" else "Connected"
                tvIp.text = s.exitIp.ifEmpty { "Detecting…" }
                tvLoc.text = s.exitCity.ifBlank { s.exitCountry.ifBlank { "—" } }
                if (s.exitCc.isNotEmpty()) { ivLocFlag.visibility = View.VISIBLE; bindFlag(null, ivLocFlag, s.exitCc) }
                else ivLocFlag.visibility = View.GONE
            } else {
                tvIp.text = if (s.connecting) "…" else "Not hidden"
                tvLoc.text = if (cc.isEmpty()) "Auto" else Countries.name(cc)
                if (cc.isNotEmpty()) { ivLocFlag.visibility = View.VISIBLE; bindFlag(null, ivLocFlag, cc) }
                else ivLocFlag.visibility = View.GONE
            }
        }

        val connectedCc = if (s.running) s.exitCc.uppercase() else ""
        val popular = Store.recentCountries.filter { it.isNotEmpty() }.isEmpty()
        val chips = Store.recentCountries.filter { it.isNotEmpty() }.ifEmpty { POPULAR }.distinct().take(8)
        val chipKey = chips.joinToString(",") + "|" + cc + "|" + connectedCc
        if (chipKey != lastChipBound) {
            lastChipBound = chipKey
            bindChips(chips, cc.uppercase(), connectedCc, popular)
        }

        val p = Store.get(Store.selectedId)
        val res = p?.let { proxyAdapter.results[it.id] }
        val pKey = (p?.let { "${it.id}|${it.name}|${it.host}" } ?: "") + "|" + res + "|" + s.health
        if (pKey != lastProxyBound) {
            lastProxyBound = pKey
            if (p == null) {
                tvProxyName.text = "Add proxy"
                tvProxyHost.text = "SOCKS5 or HTTP"
                ivProvAuto.visibility = View.VISIBLE
                tvProvLetter.text = ""
                Img.load(ivProv, null)
                tvProxyPing.visibility = View.GONE
                proxyCard.setGlow(GlowColors.BLUE)
            } else {
                val prov = Providers.of(p.host)
                tvProxyName.text = p.name
                tvProxyHost.text = "${p.host} · ${p.type}"
                ivProvAuto.visibility = View.GONE
                bindProvider(tvProvLetter, ivProv, p.host, prov.name)
                val idx = Store.profiles().indexOfFirst { it.id == p.id }.coerceAtLeast(0)
                val bad = res?.state == 2
                proxyCard.setGlow(if (bad) GlowColors.RED else GlowColors.CYCLE[idx % GlowColors.CYCLE.size])
                val ping = when {
                    s.running && s.health.isNotEmpty() -> s.health.substringAfter("· ").ifEmpty { "OK" }
                    res?.state == 1 -> res!!.text.substringBefore("  ·")
                    bad -> "Offline"
                    else -> ""
                }
                tvProxyPing.visibility = if (ping.isEmpty()) View.GONE else View.VISIBLE
                tvProxyPing.text = ping
                tvProxyPing.setBackgroundResource(if (bad) R.drawable.bg_pill_bad else R.drawable.bg_pill_ok)
                tvProxyPing.setTextColor(ContextCompat.getColor(this, if (bad) R.color.red else R.color.green))
            }
        }

        if (!s.connecting && s.errorSeq != lastErrSeq) {
            lastErrSeq = s.errorSeq
            showError(s.lastErrorKind, s.lastError, s.lastErrorCc)
        }
    }

    private fun bindChips(list: List<String>, selected: String, connected: String, popular: Boolean) {
        chipRow.removeAllViews()
        val inf = LayoutInflater.from(this)
        list.forEach { code ->
            val v = inf.inflate(R.layout.item_chip, chipRow, false)
            val up = code.uppercase()
            val on = up == connected || (connected.isEmpty() && up == selected)
            v.setBackgroundResource(if (on) R.drawable.bg_nav_active else R.drawable.bg_recent_pill)
            v.elevation = (if (on) 8 else 3) * resources.displayMetrics.density
            v.findViewById<TextView>(R.id.tvName).apply {
                text = Countries.name(code)
                setTextColor(if (on) Color.WHITE else ContextCompat.getColor(context, R.color.text))
            }
            v.findViewById<TextView>(R.id.tvSub).apply {
                text = when {
                    up == connected -> "Connected"
                    up == selected -> "Selected"
                    popular -> "Popular"
                    else -> "Recent"
                }
                setTextColor(if (on) Color.argb(210, 255, 255, 255) else ContextCompat.getColor(context, R.color.text2))
            }
            bindFlag(v.findViewById(R.id.tvCc), v.findViewById(R.id.ivFlag), code)
            v.setOnClickListener { pickCountry(code) }
            Motion.pressable(v)
            chipRow.addView(v)
        }
    }

    private fun showError(kind: Int, msg: String, cc: String) {
        when (kind) {
            SnakeVpnService.ERR_COUNTRY_UNSUPPORTED -> Glass.show(
                this, Glass.WARN, "Country switching not supported", msg,
                "Use default location", { Store.country = ""; lastIpBound = "?"; onConnectClick() },
                "Choose another proxy", { showTab(TAB_PROXY) }, flagCc = cc
            )
            SnakeVpnService.ERR_COUNTRY_UNAVAILABLE -> Glass.show(
                this, Glass.WARN, "${Countries.name(cc)} not available", msg,
                "Pick another country", { openLocations(false) }, "Close", null, flagCc = cc
            )
            SnakeVpnService.ERR_PROXY_DOWN -> Glass.show(
                this, Glass.ERROR, "Proxy not responding", msg, "Check my proxies", { showTab(TAB_PROXY) }, "Close"
            )
            else -> Glass.show(
                this, Glass.ERROR, "Connection failed", msg, "View logs", { logFilter = 2; showTab(TAB_LOGS) }, "Close"
            )
        }
    }

    // ======================= locations =======================

    private fun setupLocations() {
        countryAdapter = CountryAdapter { pickCountry(it) }
        findViewById<RecyclerView>(R.id.rvCountries).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = countryAdapter
        }
        findViewById<View>(R.id.btnLocBack).setOnClickListener { showTab(TAB_HOME) }
        findViewById<View>(R.id.btnLocFocus).setOnClickListener { openLocations(true) }
        findViewById<EditText>(R.id.etCountry).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                countryAdapter.query = s?.toString() ?: ""
                refreshCountries()
            }
        })
        bindRegions()
    }

    private fun bindRegions() {
        val row = findViewById<LinearLayout>(R.id.regionRow)
        row.removeAllViews()
        val inf = LayoutInflater.from(this)
        Regions.names.forEach { r ->
            val v = inf.inflate(R.layout.item_region, row, false) as GlowLayout
            val on = r == region
            v.findViewById<TextView>(R.id.tvName).apply {
                text = r
                setTextColor(ContextCompat.getColor(context, if (on) R.color.text else R.color.text2))
            }
            v.findViewById<TextView>(R.id.tvCount).apply {
                text = Countries.all.count { Regions.of(r, it.code) }.toString()
                setTextColor(ContextCompat.getColor(context, R.color.text))
            }
            v.background = GlowDrawable(this, GlowColors.BLUE, false, 20 * resources.displayMetrics.density).also { it.glowOn = on; it.accentBorder = true }
            GlowSupport.applyShadow(v, GlowColors.BLUE, on)
            v.setOnClickListener { region = r; bindRegions(); refreshCountries() }
            Motion.pressable(v)
            row.addView(v)
        }
    }

    private fun refreshCountries() {
        val p = Store.get(Store.selectedId)
        val fixed = p != null && !CountryRouting.canTarget(p)
        findViewById<View>(R.id.fixedBanner).visibility = if (fixed) View.VISIBLE else View.GONE
        if (fixed && p != null) {
            findViewById<TextView>(R.id.tvFixed).text = "${p.name} has a fixed location. Use a rotating proxy to switch countries."
        }
        countryAdapter.selected = Store.country
        countryAdapter.region = region
        countryAdapter.rebuild()
    }

    /** Picks a country (chip or list) and connects, like tapping a VPN server. */
    private fun pickCountry(cc: String) {
        val p = Store.get(Store.selectedId)
        if (cc.isNotEmpty() && p != null && !CountryRouting.canTarget(p)) {
            Glass.show(
                this, Glass.WARN, "Fixed location proxy",
                "${p.name} always uses its own location, so ${Countries.name(cc)} can't be selected with it.",
                "Choose another proxy", { showTab(TAB_PROXY) }, "Close", null, flagCc = cc
            )
            return
        }
        Store.country = cc
        Store.pushRecent(cc)
        refreshCountries()
        lastChipBound = "?"; lastIpBound = "?"
        if (tab == TAB_LOC) {
            findViewById<EditText>(R.id.etCountry).setText("")
            showTab(TAB_HOME)
        }
        when {
            SnakeVpnService.running -> {
                SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
                toast(if (cc.isEmpty()) "Switching to auto…" else "Switching to ${Countries.name(cc)}…")
            }
            !SnakeVpnService.connecting -> onConnectClick()
        }
        updateHome()
    }

    // ======================= proxies =======================

    private fun setupProxies() {
        proxyAdapter = ProxyAdapter(::onProxyEdit, ::onProxySelect, ::onProxyLong)
        findViewById<RecyclerView>(R.id.rvProxies).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = proxyAdapter
        }
        findViewById<View>(R.id.btnAddProxy).setOnClickListener { openAdd() }
        findViewById<View>(R.id.btnEmptyAdd).setOnClickListener { openAdd() }
        findViewById<View>(R.id.btnImport).setOnClickListener { showImport() }
        findViewById<View>(R.id.btnTestAll).setOnClickListener {
            if (proxyAdapter.items.isEmpty()) toast("No proxies to test")
            else proxyAdapter.items.forEach { testOne(it) }
        }
    }

    private fun openAdd() = startActivity(Intent(this, EditProfileActivity::class.java))

    private fun refreshProxies() {
        proxyAdapter.items = Store.profiles()
        proxyAdapter.selectedId = Store.selectedId
        proxyAdapter.activeId = if (SnakeVpnService.running) SnakeVpnService.profileId else null
        proxyAdapter.notifyDataSetChanged()
        val n = proxyAdapter.items.size
        findViewById<View>(R.id.emptyProxies).visibility = if (n == 0) View.VISIBLE else View.GONE
        updateProxyStats()
        lastProxyBound = "?"
    }

    private fun updateProxyStats() {
        val items = proxyAdapter.items
        val n = items.size
        val ok = items.count { proxyAdapter.results[it.id]?.state == 1 }
        val bad = items.count { proxyAdapter.results[it.id]?.state == 2 }
        val tested = ok + bad > 0
        findViewById<TextView>(R.id.tvProxyCount).text = if (n == 1) "1 proxy" else "$n proxies"
        findViewById<TextView>(R.id.tvProxySub).text = if (tested) "$ok online · $bad offline" else "Tap Test all to check" 
        findViewById<TextView>(R.id.tvOnlineN).text = if (tested) ok.toString() else "–"
        findViewById<TextView>(R.id.tvOfflineN).text = if (tested) bad.toString() else "–"
        val on = findViewById<GlowLayout>(R.id.chipOnline)
        on.setGlow(GlowColors.GREEN, tested && ok > 0)
        findViewById<GlowLayout>(R.id.chipOffline).setGlow(GlowColors.RED, tested && bad > 0)
    }

    private fun onProxyEdit(p: ProxyProfile) {
        startActivity(Intent(this, EditProfileActivity::class.java).putExtra("id", p.id))
    }

    private fun onProxySelect(p: ProxyProfile) {
        Store.selectedId = p.id
        refreshProxies()
        if (SnakeVpnService.running && SnakeVpnService.profileId != p.id) {
            toast("Switching to ${p.name}…")
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
        } else if (!SnakeVpnService.running && !SnakeVpnService.connecting) {
            toast("${p.name} selected")
        }
    }

    private fun onProxyLong(p: ProxyProfile, anchor: View) {
        val pm = PopupMenu(this, anchor, Gravity.END)
        pm.menu.add(0, 1, 0, "Test")
        pm.menu.add(0, 2, 1, "Use this proxy")
        pm.menu.add(0, 5, 2, "Edit")
        pm.menu.add(0, 3, 3, "Copy")
        pm.menu.add(0, 4, 4, "Delete")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> testOne(p)
                2 -> onProxySelect(p)
                5 -> onProxyEdit(p)
                3 -> {
                    val line = if (p.user.isEmpty()) "${p.host}:${p.port}" else "${p.host}:${p.port}:${p.user}:${p.pass}"
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("proxy", line))
                    toast("Copied")
                }
                4 -> Glass.show(this, Glass.ERROR, "Delete proxy?", p.name, "Delete", { Store.delete(p.id); refreshProxies() }, "Cancel")
            }
            true
        }
        pm.show()
    }

    private fun testOne(p: ProxyProfile) {
        proxyAdapter.results[p.id] = Res(0, "Testing…")
        proxyAdapter.notifyDataSetChanged()
        val target = CountryRouting.apply(p, Store.country) ?: p
        bg.execute {
            val g = GeoCheck.through(target)
            runOnUiThread {
                proxyAdapter.results[p.id] =
                    if (g.ok) Res(1, "${g.ms} ms  ·  ${g.ip}" + if (g.cc.isNotEmpty()) "  ·  ${g.cc}" else "")
                    else Res(2, g.error)
                proxyAdapter.notifyDataSetChanged()
                updateProxyStats()
                lastProxyBound = "?"
            }
        }
    }

    private fun showImport() {
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, (8 * d).toInt(), pad, 0)
        }
        box.addView(TextView(this).apply {
            text = "One proxy per line\nhost:port:user:pass\nsocks5://user:pass@host:port\nhttp://user:pass@host:port"
            textSize = 12f
            setTextColor(ContextCompat.getColor(context, R.color.text2))
        })
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundResource(R.drawable.bg_track)
            val q = (4 * d).toInt()
            setPadding(q, q, q, q)
        }
        fun seg(t: String) = TextView(this).apply {
            text = t
            gravity = Gravity.CENTER
            textSize = 13f
            minHeight = (40 * d).toInt()
        }
        val sS = seg("SOCKS5")
        val sH = seg("HTTP")
        var type = "SOCKS5"
        track.addView(sS, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        track.addView(sH, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        styleSegments(0, sS, sH)
        sS.setOnClickListener { type = "SOCKS5"; styleSegments(0, sS, sH) }
        sH.setOnClickListener { type = "HTTP"; styleSegments(1, sS, sH) }
        box.addView(track, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (12 * d).toInt()
        })
        val et = EditText(this).apply {
            minLines = 5
            maxLines = 10
            gravity = Gravity.TOP
            hint = "Paste proxies here"
            textSize = 13f
            setBackgroundResource(R.drawable.bg_field)
            setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
        }
        try {
            val clip = getSystemService(ClipboardManager::class.java).primaryClip
            val t = clip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            if (ProxyParser.parseAll(t, "SOCKS5").isNotEmpty()) et.setText(t)
        } catch (ignored: Exception) {}
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (12 * d).toInt()
        })
        MaterialAlertDialogBuilder(this)
            .setTitle("Bulk import")
            .setView(box)
            .setPositiveButton("Import") { _, _ ->
                val list = ProxyParser.parseAll(et.text.toString(), type).map { it.copy(name = Providers.of(it.host).name + " " + it.port) }
                if (list.isEmpty()) {
                    toast("No valid proxies found")
                } else {
                    Store.saveProfiles(Store.profiles() + list)
                    if (Store.get(Store.selectedId) == null) Store.selectedId = list.first().id
                    refreshProxies()
                    Glass.show(this, Glass.OK, "Imported", "${list.size} proxies added.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ======================= apps =======================

    private fun setupApps() {
        appAdapter = AppAdapter()
        findViewById<RecyclerView>(R.id.rvApps).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = appAdapter
        }
        appAdapter.checked.addAll(Store.apps)
        val segs = listOf<TextView>(findViewById(R.id.segAll), findViewById(R.id.segOnly), findViewById(R.id.segBypass))
        val modes = listOf(Store.MODE_ALL, Store.MODE_ONLY, Store.MODE_EXCLUDE)
        segs.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                Store.appMode = modes[i]
                appsDirty = true
                styleAppMode()
            }
        }
        styleAppMode()
        findViewById<View>(R.id.btnSettings).setOnClickListener { openSettings() }
        findViewById<View>(R.id.btnAppSearch).setOnClickListener {
            val box = findViewById<View>(R.id.searchBox)
            val et = findViewById<EditText>(R.id.etSearch)
            if (box.visibility == View.VISIBLE) {
                et.setText("")
                box.visibility = View.GONE
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
            } else {
                box.visibility = View.VISIBLE
                et.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(et, 0)
            }
        }
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = appAdapter.filter(s?.toString() ?: "")
        })
    }

    private fun styleAppMode() {
        val segs = listOf<TextView>(findViewById(R.id.segAll), findViewById(R.id.segOnly), findViewById(R.id.segBypass))
        val m = Store.appMode
        styleSegments(when (m) { Store.MODE_ONLY -> 1; Store.MODE_EXCLUDE -> 2; else -> 0 }, *segs.toTypedArray())
        updateAppHeader()
        appAdapter.notifyDataSetChanged()
    }

    private fun updateAppHeader() {
        val n = appAdapter.checked.size
        val (title, sub) = when (Store.appMode) {
            Store.MODE_ONLY -> (if (n == 1) "1 app" else "$n apps") to "go through the proxy"
            Store.MODE_EXCLUDE -> (if (n == 1) "1 app" else "$n apps") to "skip the proxy, everything else is protected"
            else -> "All apps" to "every app goes through the proxy"
        }
        findViewById<TextView>(R.id.tvAppsCount).text = title
        findViewById<TextView>(R.id.tvAppsSub).text = sub
    }

    private fun loadApps() {
        if (appsLoaded) return
        appsLoaded = true
        val loading = findViewById<TextView>(R.id.tvLoading)
        loading.visibility = View.VISIBLE
        val checked = appAdapter.checked.toSet()
        bg.execute {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val list = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
                .filter { it.packageName != packageName && it.requestedPermissions?.contains(Manifest.permission.INTERNET) == true }
                .mapNotNull { pi ->
                    val ai = pi.applicationInfo ?: return@mapNotNull null
                    AppItem(pi.packageName, pm.getApplicationLabel(ai).toString(), ai)
                }
                .sortedWith(compareBy<AppItem>({ it.pkg !in checked }, { it.label.lowercase() }))
            runOnUiThread {
                appAdapter.all = list
                appAdapter.filter("")
                loading.visibility = View.GONE
                findViewById<TextView>(R.id.tvInstalledN).text = "${list.size} apps"
                findViewById<RecyclerView>(R.id.rvApps).scheduleLayoutAnimation()
            }
        }
    }

    private fun applyAppChanges() {
        if (!appsDirty) return
        appsDirty = false
        Store.apps = appAdapter.checked.toSet()
        if (SnakeVpnService.running) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
            toast("Applying app settings")
        }
    }

    // ======================= logs =======================

    private fun setupLogs() {
        logAdapter = LogAdapter()
        rvLogs = findViewById(R.id.rvLogs)
        rvLogs.layoutManager = LinearLayoutManager(this)
        rvLogs.adapter = logAdapter
        val segs = listOf<TextView>(findViewById(R.id.segLogAll), findViewById(R.id.segLogOk), findViewById(R.id.segLogFail))
        segs.forEachIndexed { i, tv -> tv.setOnClickListener { logFilter = i; refreshLogs(true) } }
        findViewById<View>(R.id.btnLogsMenu).setOnClickListener { openSettings() }
        findViewById<View>(R.id.btnClearLogs).setOnClickListener {
            ConnLog.clear(); AppLog.clear()
            refreshLogs(true)
        }
        findViewById<View>(R.id.btnUsage).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (e: Exception) { toast("Open Settings → Usage access") }
        }
        findViewById<RingView>(R.id.ringLogs).state = RingView.OFF
    }

    private fun refreshLogs(force: Boolean) {
        if (logFilter > 2) logFilter = 0
        val segs = listOf<TextView>(findViewById(R.id.segLogAll), findViewById(R.id.segLogOk), findViewById(R.id.segLogFail))
        styleSegments(logFilter, *segs.toTypedArray())
        if (!force && ConnLog.version == lastLogVersion) return
        lastLogVersion = ConnLog.version
        val all = ConnLog.snapshot()
        val ok = all.count { it.ok }
        val bad = all.size - ok
        findViewById<TextView>(R.id.tvOkCount).text = ok.toString()
        findViewById<TextView>(R.id.tvFailCount).text = bad.toString()
        findViewById<TextView>(R.id.tvAppCount).text = all.mapNotNull { it.pkg }.toSet().size.toString()
        val ring = findViewById<RingView>(R.id.ringLogs)
        if (all.isEmpty()) {
            findViewById<TextView>(R.id.tvRate).text = "–"
            ring.state = RingView.OFF
        } else {
            val rate = ok * 100 / all.size
            findViewById<TextView>(R.id.tvRate).text = "$rate%"
            ring.progress = ok.toFloat() / all.size
            ring.state = RingView.ON
        }
        val shown = when (logFilter) {
            1 -> all.filter { it.ok }
            2 -> all.filter { !it.ok }
            else -> all
        }.take(80)
        logAdapter.items = shown
        logAdapter.notifyDataSetChanged()
        findViewById<View>(R.id.tvLogsEmpty).visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ======================= adapters =======================

    inner class CountryAdapter(private val onPick: (String) -> Unit) : RecyclerView.Adapter<CountryAdapter.VH>() {
        var query = ""
        var selected = ""
        var region = "All"
        private var rows: List<Pair<String, String>> = emptyList()

        fun rebuild() {
            val q = query.trim().lowercase()
            val inRegion = Countries.all.filter { Regions.of(region, it.code) }
            rows = if (q.isNotEmpty()) {
                inRegion.filter { it.name.lowercase().contains(q) || it.code.lowercase() == q }.map { it.code to "" }
            } else {
                val recent = Store.recentCountries.filter { Regions.of(region, it) }.map { it to "Recent" }
                val head = if (region == "All") listOf("" to "Proxy default location") else emptyList()
                head + recent + inRegion.filter { c -> recent.none { it.first == c.code } }.map { it.code to "" }
            }
            notifyDataSetChanged()
        }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val row: GlowLayout = v.findViewById(R.id.row)
            val cc: TextView = v.findViewById(R.id.tvCc)
            val flag: ImageView = v.findViewById(R.id.ivFlag)
            val auto: ImageView = v.findViewById(R.id.ivAuto)
            val name: TextView = v.findViewById(R.id.tvName)
            val sub: TextView = v.findViewById(R.id.tvSub)
            val sel: TextView = v.findViewById(R.id.tvSel)
            val chev: ImageView = v.findViewById(R.id.ivChevron)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_country, parent, false).also { Motion.pressable(it) })

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val (code, sub) = rows[pos]
            if (code.isEmpty()) {
                h.name.text = "Auto"
                h.cc.text = ""
                h.auto.visibility = View.VISIBLE
                Img.load(h.flag, null)
            } else {
                h.name.text = Countries.name(code)
                h.auto.visibility = View.GONE
                bindFlag(h.cc, h.flag, code)
            }
            h.sub.text = sub
            h.sub.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
            val on = code.equals(selected, true)
            h.row.setGlow(GlowColors.BLUE, on)
            h.sel.visibility = if (on) View.VISIBLE else View.GONE
            h.chev.visibility = if (on) View.GONE else View.VISIBLE
            h.row.setOnClickListener { onPick(code) }
        }
    }

    inner class ProxyAdapter(
        private val onEdit: (ProxyProfile) -> Unit,
        private val onSelect: (ProxyProfile) -> Unit,
        private val onLong: (ProxyProfile, View) -> Unit
    ) : RecyclerView.Adapter<ProxyAdapter.VH>() {
        var items: List<ProxyProfile> = emptyList()
        var selectedId: String? = null
        var activeId: String? = null
        val results get() = proxyResults

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val card: GlowLayout = v.findViewById(R.id.card)
            val letter: TextView = v.findViewById(R.id.tvLetter)
            val prov: ImageView = v.findViewById(R.id.ivProv)
            val name: TextView = v.findViewById(R.id.tvName)
            val host: TextView = v.findViewById(R.id.tvHost)
            val type: TextView = v.findViewById(R.id.tvType)
            val geo: TextView = v.findViewById(R.id.tvGeo)
            val result: TextView = v.findViewById(R.id.tvResult)
            val select: TextView = v.findViewById(R.id.btnSelect)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_proxy, parent, false).also { Motion.pressable(it) })

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val p = items[pos]
            val ctx = h.itemView.context
            val prov = Providers.of(p.host)
            h.name.text = p.name
            h.host.text = "${p.host}:${p.port}"
            h.type.text = p.type
            h.geo.text = if (CountryRouting.canTarget(p)) "All countries" else "Fixed"
            bindProvider(h.letter, h.prov, p.host, prov.name)

            val r = results[p.id]
            val bad = r?.state == 2
            h.card.setGlow(if (bad) GlowColors.RED else GlowColors.CYCLE[pos % GlowColors.CYCLE.size])
            if (r == null) {
                h.result.visibility = View.GONE
            } else {
                h.result.visibility = View.VISIBLE
                h.result.text = when (r.state) { 1 -> r.text.substringBefore("  ·"); 2 -> "Offline"; else -> "Testing…" }
                h.result.setBackgroundResource(when (r.state) { 1 -> R.drawable.bg_pill_ok; 2 -> R.drawable.bg_pill_bad; else -> R.drawable.bg_circle_soft_pill })
                h.result.setTextColor(when (r.state) { 1 -> ContextCompat.getColor(ctx, R.color.green); 2 -> ContextCompat.getColor(ctx, R.color.red); else -> ContextCompat.getColor(ctx, R.color.text2) })
            }
            val selected = p.id == selectedId
            val active = p.id == activeId
            h.select.text = if (active) "Connected" else if (selected) "Selected" else "Select"
            h.select.setBackgroundResource(if (selected) R.drawable.bg_blue_btn else R.drawable.bg_select_off)
            h.select.setTextColor(if (selected) Color.WHITE else ContextCompat.getColor(ctx, R.color.text))
            h.select.setCompoundDrawablesRelativeWithIntrinsicBounds(if (selected) R.drawable.ic_radio_on else R.drawable.ic_radio_off, 0, 0, 0)
            h.select.setOnClickListener { if (!selected) onSelect(p) }
            h.card.setOnClickListener { onEdit(p) }
            h.card.setOnLongClickListener { onLong(p, it); true }
        }
    }

    data class Res(val state: Int, val text: String)
    private val proxyResults = HashMap<String, Res>()

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        var all: List<AppItem> = emptyList()
        private var shown: List<AppItem> = emptyList()
        val checked = HashSet<String>()

        fun filter(q: String) {
            val s = q.trim().lowercase()
            shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) || it.pkg.contains(s) }
            notifyDataSetChanged()
        }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val row: GlowLayout = v.findViewById(R.id.row)
            val icon: ImageView = v.findViewById(R.id.ivIcon)
            val label: TextView = v.findViewById(R.id.tvLabel)
            val pkg: TextView = v.findViewById(R.id.tvPkg)
            val tog: ToggleView = v.findViewById(R.id.tog)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false).also { Motion.pressable(it) })

        override fun getItemCount() = shown.size

        private fun sub(on: Boolean) = when (Store.appMode) {
            Store.MODE_ONLY -> if (on) "Through proxy" else "Direct"
            Store.MODE_EXCLUDE -> if (on) "Skips proxy" else "Through proxy"
            else -> "Through proxy"
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val a = shown[pos]
            h.label.text = a.label
            h.icon.setImageDrawable(try { a.info.loadIcon(packageManager) } catch (e: Exception) { null })
            val on = a.pkg in checked
            val modeAll = Store.appMode == Store.MODE_ALL
            h.tog.setCheckedNow(if (modeAll) true else on)
            h.tog.alpha = if (modeAll) 0.45f else 1f
            h.row.setGlow(if (Store.appMode == Store.MODE_EXCLUDE) GlowColors.ORANGE else GlowColors.BLUE, !modeAll && on)
            h.pkg.text = sub(on)
            h.tog.setOnClickListener { h.row.performClick() }
            h.row.setOnClickListener {
                if (Store.appMode == Store.MODE_ALL) {
                    toast("Choose Only selected or Except first")
                    return@setOnClickListener
                }
                if (!checked.add(a.pkg)) checked.remove(a.pkg)
                appsDirty = true
                val now = a.pkg in checked
                h.tog.isChecked = now
                h.row.setGlow(if (Store.appMode == Store.MODE_EXCLUDE) GlowColors.ORANGE else GlowColors.BLUE, now)
                h.pkg.text = sub(now)
                updateAppHeader()
            }
        }
    }

    inner class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {
        var items: List<ConnEvent> = emptyList()
        private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val card: GlowLayout = v.findViewById(R.id.card)
            val icon: ImageView = v.findViewById(R.id.ivApp)
            val app: TextView = v.findViewById(R.id.tvApp)
            val host: TextView = v.findViewById(R.id.tvHost)
            val err: TextView = v.findViewById(R.id.tvErr)
            val status: TextView = v.findViewById(R.id.tvStatus)
            val time: TextView = v.findViewById(R.id.tvTime)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_log, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val e = items[pos]
            val ctx = this@MainActivity
            val pad = (10 * resources.displayMetrics.density).toInt()
            val pkg = e.pkg
            h.icon.clearColorFilter()
            if (pkg != null) {
                h.app.text = AppInfo.label(ctx, pkg)
                val d = AppInfo.icon(ctx, pkg)
                if (d != null) { h.icon.setImageDrawable(d); h.icon.setPadding(0, 0, 0, 0) }
                else { h.icon.setImageResource(R.drawable.ic_apps); h.icon.setPadding(pad, pad, pad, pad) }
            } else {
                h.app.text = if (Foreground.hasPermission(ctx)) "Background app" else "App connection"
                h.icon.setImageResource(R.drawable.ic_apps)
                h.icon.setPadding(pad, pad, pad, pad)
            }
            h.host.text = "${e.host}:${e.port}"
            h.time.text = fmt.format(Date(e.time))
            if (e.ok) {
                h.card.setGlow(GlowColors.GREEN)
                h.status.setBackgroundResource(R.drawable.bg_pill_ok)
                h.status.setTextColor(ContextCompat.getColor(ctx, R.color.green))
                h.status.text = "${e.ms} ms"
                h.err.visibility = View.GONE
            } else {
                h.card.setGlow(GlowColors.RED)
                h.status.setBackgroundResource(R.drawable.bg_pill_bad)
                h.status.setTextColor(ContextCompat.getColor(ctx, R.color.red))
                h.status.text = "Failed"
                h.err.visibility = View.VISIBLE
                h.err.text = e.error
            }
        }
    }
}
