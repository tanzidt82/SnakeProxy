package com.snake.proxy

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** An installed app shown in the Apps tab. */
data class AppItem(val pkg: String, val label: String, val info: ApplicationInfo)

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAB_HOME = 0
        const val TAB_PROXY = 1
        const val TAB_APPS = 2
        const val TAB_LOGS = 3
        const val TAB_WORLD = 4
    }

    private val ui = Handler(Looper.getMainLooper())
    private val bg = Executors.newCachedThreadPool()
    private var tab = 0
    private lateinit var pages: List<View>
    private lateinit var navIcons: List<ImageView>
    private lateinit var navDots: List<View>

    // home
    private lateinit var tvState: TextView
    private lateinit var tvTimer: TextView
    private lateinit var orb: ImageView
    private lateinit var ringSweep: View
    private lateinit var ringGlass: View
    private lateinit var tvIp: TextView
    private lateinit var tvIpMeta: TextView
    private lateinit var tvIpCc: TextView
    private lateinit var ivIpFlag: ImageView
    private lateinit var tvHealth: TextView
    private lateinit var ivLocFlag: ImageView
    private lateinit var ivLocAuto: ImageView
    private lateinit var tvLocName: TextView
    private lateinit var tvLocSub: TextView
    private lateinit var tvProvLetter: TextView
    private lateinit var ivProv: ImageView
    private lateinit var ivProvAuto: ImageView
    private lateinit var tvProxyName: TextView
    private lateinit var tvProxyHost: TextView

    // lists
    private lateinit var countryAdapter: CountryAdapter
    private lateinit var proxyAdapter: ProxyAdapter
    private lateinit var appAdapter: AppAdapter
    private lateinit var logAdapter: LogAdapter
    private lateinit var rvLogs: RecyclerView
    private var logFilter = 0
    private var lastLogVersion = -1

    // apps tab
    private var appsLoaded = false
    private var appsDirty = false

    private var state = -1
    private var lastErrSeq = 0
    private var lastIpBound = "?"
    private var lastLocBound = "?"
    private var lastProxyBound = "?"
    private var homeAnimated = false
    private var ringAnim: ObjectAnimator? = null
    private var pulseAnim: ObjectAnimator? = null
    private var glowAnim: ObjectAnimator? = null

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpn()
        else toast("VPN permission is required")
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateHome()
            if (tab == TAB_LOGS) refreshLogs(false)
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lastErrSeq = SnakeVpnService.errorSeq

        pages = listOf(
            findViewById(R.id.pageHome), findViewById(R.id.pageProxies),
            findViewById(R.id.pageApps), findViewById(R.id.pageLogs), findViewById(R.id.pageLocations)
        )
        navIcons = listOf(
            findViewById(R.id.ivNavHome), findViewById(R.id.ivNavProxy),
            findViewById(R.id.ivNavApps), findViewById(R.id.ivNavLogs)
        )
        navDots = listOf(
            findViewById(R.id.dotNavHome), findViewById(R.id.dotNavProxy),
            findViewById(R.id.dotNavApps), findViewById(R.id.dotNavLogs)
        )
        listOf(R.id.navHome, R.id.navProxy, R.id.navApps, R.id.navLogs).forEachIndexed { i, id ->
            findViewById<View>(id).setOnClickListener { showTab(i) }
        }
        findViewById<View>(R.id.navFab).setOnClickListener { openAdd() }
        findViewById<View>(R.id.btnLocBack).setOnClickListener { showTab(TAB_HOME) }

        setupHome()
        setupLocations()
        setupProxies()
        setupApps()
        setupLogs()
        showTab(savedInstanceState?.getInt("tab") ?: TAB_HOME, animate = false)
        orb.tag = "noPress"
        Motion.pressable(findViewById(android.R.id.content))

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (tab != TAB_HOME) showTab(TAB_HOME) else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        refreshProxies()
        refreshCountries()
        lastLocBound = "?"; lastProxyBound = "?"; lastIpBound = "?"
        findViewById<View>(R.id.usageBanner).visibility =
            if (Foreground.hasPermission(this)) View.GONE else View.VISIBLE
        ui.post(ticker)
        if (Store.autoSync && Store.subUrl.isNotBlank() &&
            System.currentTimeMillis() - SubSync.lastSync > 5 * 60_000
        ) {
            bg.execute { SubSync.sync(); runOnUiThread { refreshProxies() } }
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
        applyAppChanges()
    }

    // ======================= tabs =======================

    private fun showTab(i: Int, animate: Boolean = true) {
        if (tab == TAB_APPS && i != TAB_APPS) applyAppChanges()
        tab = i
        pages.forEachIndexed { idx, p -> p.visibility = if (idx == i) View.VISIBLE else View.GONE }

        val on = ContextCompat.getColor(this, R.color.mint_dark)
        val off = ContextCompat.getColor(this, R.color.nav_icon)
        val navIndex = if (i == TAB_WORLD) TAB_HOME else i
        navIcons.forEachIndexed { idx, iv ->
            val active = idx == navIndex
            iv.setColorFilter(if (active) on else off)
            iv.animate().scaleX(if (active) 1.15f else 1f).scaleY(if (active) 1.15f else 1f)
                .translationY(if (active) -3f else 0f).setDuration(220)
                .setInterpolator(OvershootInterpolator(2f)).start()
            navDots[idx].visibility = if (active) View.VISIBLE else View.INVISIBLE
        }

        if (animate) {
            val p = pages[i]
            p.alpha = 0f
            p.translationY = 44f
            p.animate().alpha(1f).translationY(0f).setDuration(320)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
        when (i) {
            TAB_HOME -> if (!homeAnimated) {
                homeAnimated = true
                Motion.stagger(
                    findViewById(R.id.orbBox), tvState, tvTimer, findViewById(R.id.cardIp),
                    findViewById(R.id.cardLocation), findViewById(R.id.cardProxy), start = 80
                )
            }
            TAB_WORLD -> { refreshCountries(); findViewById<RecyclerView>(R.id.rvCountries).scheduleLayoutAnimation() }
            TAB_PROXY -> { refreshProxies(); findViewById<RecyclerView>(R.id.rvProxies).scheduleLayoutAnimation() }
            TAB_APPS -> loadApps()
            TAB_LOGS -> refreshLogs(true)
        }
    }

    // ======================= home =======================

    private fun setupHome() {
        tvState = findViewById(R.id.tvState)
        tvTimer = findViewById(R.id.tvTimer)
        orb = findViewById(R.id.btnOrb)
        ringSweep = findViewById(R.id.vRingSweep)
        ringGlass = findViewById(R.id.vRingGlass)
        tvIp = findViewById(R.id.tvIp)
        tvIpMeta = findViewById(R.id.tvIpMeta)
        tvIpCc = findViewById(R.id.tvIpCc)
        ivIpFlag = findViewById(R.id.ivIpFlag)
        tvHealth = findViewById(R.id.tvHealth)
        ivLocFlag = findViewById(R.id.ivLocFlag)
        ivLocAuto = findViewById(R.id.ivLocAuto)
        tvLocName = findViewById(R.id.tvLocName)
        tvLocSub = findViewById(R.id.tvLocSub)
        tvProvLetter = findViewById(R.id.tvProvLetter)
        ivProv = findViewById(R.id.ivProv)
        ivProvAuto = findViewById(R.id.ivProvAuto)
        tvProxyName = findViewById(R.id.tvProxyName)
        tvProxyHost = findViewById(R.id.tvProxyHost)

        orb.setOnClickListener {
            orb.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).withEndAction {
                orb.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(2.4f)).start()
            }.start()
            onConnectClick()
        }
        findViewById<View>(R.id.cardLocation).setOnClickListener { showTab(TAB_WORLD) }
        findViewById<View>(R.id.cardProxy).setOnClickListener {
            if (Store.profiles().isEmpty()) openAdd() else showTab(TAB_PROXY)
        }

        val btnTheme = findViewById<ImageButton>(R.id.btnTheme)
        btnTheme.setImageResource(if (isNight()) R.drawable.ic_sun else R.drawable.ic_moon)
        btnTheme.setOnClickListener {
            Store.themeMode = if (isNight()) 1 else 2
            Store.applyTheme()
        }

        // soft breathing glow on the glass ring
        glowAnim = ObjectAnimator.ofFloat(ringGlass, "alpha", 1f, 0.55f).apply {
            duration = 2400
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun isNight() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun onConnectClick() {
        if (SnakeVpnService.running || SnakeVpnService.connecting) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_STOP)
            return
        }
        if (Store.get(Store.selectedId) == null) {
            if (Store.profiles().isEmpty()) {
                Glass.show(
                    this, Glass.INFO, "Add a proxy",
                    "Fleet Proxy needs your SOCKS5 or HTTP proxy.",
                    "Add proxy", { openAdd() }, "Later"
                )
            } else {
                toast("Select a proxy")
                showTab(TAB_PROXY)
            }
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPermission.launch(i) else startVpn()
    }

    private fun startVpn() {
        lastErrSeq = SnakeVpnService.errorSeq
        SnakeVpnService.send(this, SnakeVpnService.ACTION_START, Store.selectedId)
        applyState(1)
    }

    private fun spinRing(ms: Long) {
        ringAnim?.cancel()
        ringAnim = ObjectAnimator.ofFloat(ringSweep, "rotation", ringSweep.rotation, ringSweep.rotation + 360f).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
    }

    private fun applyState(s: Int) {
        if (s == state) return
        state = s
        pulseAnim?.cancel(); pulseAnim = null
        orb.scaleX = 1f; orb.scaleY = 1f
        when (s) {
            2 -> {
                tvState.text = "Connected"
                orb.setImageResource(R.drawable.orb3d_on)
                ringSweep.animate().alpha(0.9f).setDuration(400).start()
                spinRing(6000)
                pulseAnim = ObjectAnimator.ofFloat(orb, "scaleX", 1f, 1.04f).apply {
                    duration = 1500
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    addUpdateListener { orb.scaleY = orb.scaleX }
                    start()
                }
            }
            1 -> {
                tvState.text = "Connecting…"
                orb.setImageResource(R.drawable.orb3d_wait)
                ringSweep.animate().alpha(1f).setDuration(300).start()
                spinRing(900)
            }
            else -> {
                tvState.text = "Disconnected"
                orb.setImageResource(R.drawable.orb3d_off)
                ringAnim?.cancel(); ringAnim = null
                ringSweep.animate().alpha(0f).setDuration(400).start()
            }
        }
        tvState.alpha = 0f
        tvState.translationY = 12f
        tvState.animate().alpha(1f).translationY(0f).setDuration(320).start()
    }

    private fun updateHome() {
        val s = SnakeVpnService
        applyState(if (s.running) 2 else if (s.connecting) 1 else 0)

        tvTimer.text = if (s.running && s.startedAt > 0) Fmt.dur(System.currentTimeMillis() - s.startedAt) else "00:00:00"

        val ipKey = if (s.running) "${s.exitIp}|${s.exitCc}" else ""
        if (ipKey != lastIpBound) {
            lastIpBound = ipKey
            if (s.running) {
                tvIp.text = s.exitIp.ifEmpty { "Detecting…" }
                tvIpMeta.text = listOf(s.exitCountry, s.exitCity).filter { it.isNotBlank() }.joinToString(", ")
                if (s.exitCc.isNotEmpty()) bindFlag(tvIpCc, ivIpFlag, s.exitCc)
                else { tvIpCc.text = "IP"; tvIpCc.visibility = View.VISIBLE; Img.load(ivIpFlag, null) }
            } else {
                tvIp.text = "Not protected"
                tvIpMeta.text = "Real IP visible"
                tvIpCc.text = "IP"
                tvIpCc.visibility = View.VISIBLE
                Img.load(ivIpFlag, null)
            }
        }
        if (s.running && s.health.isNotEmpty()) {
            val good = s.health.startsWith("Proxy OK")
            tvHealth.visibility = View.VISIBLE
            tvHealth.text = if (good) s.health.substringAfter("· ").ifEmpty { "OK" } else "Weak"
            tvHealth.setBackgroundResource(if (good) R.drawable.bg_pill_ok else R.drawable.bg_pill_warn)
            tvHealth.setTextColor(ContextCompat.getColor(this, if (good) R.color.green else R.color.amber))
        } else tvHealth.visibility = View.GONE

        val cc = Store.country
        if (cc != lastLocBound) {
            lastLocBound = cc
            if (cc.isEmpty()) {
                tvLocName.text = "Auto"
                ivLocAuto.visibility = View.VISIBLE
                Img.load(ivLocFlag, null)
            } else {
                tvLocName.text = Countries.name(cc)
                ivLocAuto.visibility = View.GONE
                bindFlag(null, ivLocFlag, cc)
            }
        }

        val p = Store.get(Store.selectedId)
        val pKey = p?.let { "${it.id}|${it.name}|${it.host}" } ?: ""
        if (pKey != lastProxyBound) {
            lastProxyBound = pKey
            if (p == null) {
                tvProxyName.text = "Add proxy"
                tvProxyHost.text = "Proxy"
                ivProvAuto.visibility = View.VISIBLE
                tvProvLetter.text = ""
                Img.load(ivProv, null)
            } else {
                val prov = Providers.of(p.host)
                tvProxyName.text = p.name
                tvProxyHost.text = prov.name
                ivProvAuto.visibility = View.GONE
                bindProvider(tvProvLetter, ivProv, p.host, prov.name)
            }
        }

        if (!s.connecting && s.errorSeq != lastErrSeq) {
            lastErrSeq = s.errorSeq
            showError(s.lastErrorKind, s.lastError, s.lastErrorCc)
        }
    }

    private fun showError(kind: Int, msg: String, cc: String) {
        when (kind) {
            SnakeVpnService.ERR_COUNTRY_UNSUPPORTED -> Glass.show(
                this, Glass.WARN, "Country switching not supported", msg,
                "Use default location", {
                    Store.country = ""
                    lastLocBound = "?"
                    onConnectClick()
                },
                "Choose another proxy", { showTab(TAB_PROXY) }, flagCc = cc
            )
            SnakeVpnService.ERR_COUNTRY_UNAVAILABLE -> Glass.show(
                this, Glass.WARN, "${Countries.name(cc)} not available", msg,
                "Pick another country", { showTab(TAB_WORLD) },
                "Close", null, flagCc = cc
            )
            SnakeVpnService.ERR_PROXY_DOWN -> Glass.show(
                this, Glass.ERROR, "Proxy not responding", msg,
                "Check my proxies", { showTab(TAB_PROXY) }, "Close"
            )
            else -> Glass.show(
                this, Glass.ERROR, "Connection failed", msg,
                "OK", null, "View logs", { logFilter = 2; showTab(TAB_LOGS) }
            )
        }
    }

    // ======================= locations =======================

    private fun setupLocations() {
        countryAdapter = CountryAdapter { onCountry(it) }
        findViewById<RecyclerView>(R.id.rvCountries).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = countryAdapter
        }
        findViewById<EditText>(R.id.etCountry).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                countryAdapter.query = s?.toString() ?: ""
                refreshCountries()
            }
        })
    }

    private fun refreshCountries() {
        val p = Store.get(Store.selectedId)
        val fixed = p != null && !CountryRouting.canTarget(p)
        findViewById<View>(R.id.fixedBanner).visibility = if (fixed) View.VISIBLE else View.GONE
        if (fixed && p != null) {
            findViewById<TextView>(R.id.tvFixed).text =
                "${p.name} has a fixed location. Use a rotating proxy (DataImpulse, 9Proxy, ABCProxy, Cliproxy…) to switch countries."
        }
        countryAdapter.selected = Store.country
        countryAdapter.rebuild()
    }

    private fun onCountry(cc: String) {
        val p = Store.get(Store.selectedId)
        if (cc.isNotEmpty() && p != null && !CountryRouting.canTarget(p)) {
            Glass.show(
                this, Glass.WARN, "Fixed location proxy",
                "${p.name} always uses its own location, so ${Countries.name(cc)} can't be selected with it.",
                "Choose another proxy", { showTab(TAB_PROXY) }, "Close", null, flagCc = cc
            )
            return
        }
        Store.country = cc
        Store.pushRecent(cc)
        refreshCountries()
        if (SnakeVpnService.running) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
            toast("Switching to ${Countries.name(cc)}…")
        }
        ui.postDelayed({ showTab(TAB_HOME) }, 180)
    }

    // ======================= proxies =======================

    private fun setupProxies() {
        proxyAdapter = ProxyAdapter(::onProxyEdit, ::onProxySelect, ::onProxyLong)
        findViewById<RecyclerView>(R.id.rvProxies).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = proxyAdapter
        }
        findViewById<View>(R.id.btnAddProxy).setOnClickListener { openAdd() }
        findViewById<View>(R.id.btnEmptyAdd).setOnClickListener { openAdd() }
        findViewById<View>(R.id.btnImport).setOnClickListener { showImport() }
        findViewById<View>(R.id.btnTestAll).setOnClickListener {
            if (proxyAdapter.items.isEmpty()) toast("No proxies to test")
            else proxyAdapter.items.forEach { testOne(it) }
        }
    }

    private fun openAdd() = startActivity(Intent(this, EditProfileActivity::class.java))

    private fun refreshProxies() {
        proxyAdapter.items = Store.profiles()
        proxyAdapter.selectedId = Store.selectedId
        proxyAdapter.activeId = SnakeVpnService.profileId
        proxyAdapter.notifyDataSetChanged()
        val n = proxyAdapter.items.size
        findViewById<View>(R.id.emptyProxies).visibility = if (n == 0) View.VISIBLE else View.GONE
        lastProxyBound = "?"
    }

    private fun onProxyEdit(p: ProxyProfile) {
        startActivity(Intent(this, EditProfileActivity::class.java).putExtra("id", p.id))
    }

    private fun onProxySelect(p: ProxyProfile) {
        Store.selectedId = p.id
        refreshProxies()
        if (SnakeVpnService.running && SnakeVpnService.profileId != p.id) {
            toast("Switching to ${p.name}…")
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
        }
    }

    private fun onProxyLong(p: ProxyProfile, anchor: View) {
        val pm = PopupMenu(this, anchor, Gravity.END)
        pm.menu.add(0, 1, 0, "Test")
        pm.menu.add(0, 2, 1, "Select")
        pm.menu.add(0, 3, 2, "Copy")
        pm.menu.add(0, 4, 3, "Delete")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> testOne(p)
                2 -> onProxySelect(p)
                3 -> {
                    val line = if (p.user.isEmpty()) "${p.host}:${p.port}" else "${p.host}:${p.port}:${p.user}:${p.pass}"
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("proxy", line))
                    toast("Copied")
                }
                4 -> Glass.show(
                    this, Glass.ERROR, "Delete proxy?", p.name,
                    "Delete", { Store.delete(p.id); refreshProxies() }, "Cancel"
                )
            }
            true
        }
        pm.show()
    }

    private fun testOne(p: ProxyProfile) {
        proxyAdapter.results[p.id] = ProxyAdapter.Res(0, "Testing…")
        proxyAdapter.notifyDataSetChanged()
        val target = CountryRouting.apply(p, Store.country) ?: p
        bg.execute {
            val g = GeoCheck.through(target)
            runOnUiThread {
                proxyAdapter.results[p.id] =
                    if (g.ok) ProxyAdapter.Res(1, "${g.ms} ms  ·  ${g.ip}" + if (g.cc.isNotEmpty()) "  ·  ${g.cc}" else "")
                    else ProxyAdapter.Res(2, g.error)
                proxyAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun showImport() {
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, (8 * d).toInt(), pad, 0)
        }
        box.addView(TextView(this).apply {
            text = "One proxy per line\nhost:port:user:pass\nsocks5://user:pass@host:port\nhttp://user:pass@host:port"
            textSize = 12f
            setTextColor(ContextCompat.getColor(context, R.color.text2))
        })
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundResource(R.drawable.bg_segment_track)
            val q = (4 * d).toInt()
            setPadding(q, q, q, q)
        }
        fun seg(t: String) = TextView(this).apply {
            text = t
            gravity = Gravity.CENTER
            textSize = 13f
            minHeight = (40 * d).toInt()
        }
        val sS = seg("SOCKS5")
        val sH = seg("HTTP")
        var type = "SOCKS5"
        track.addView(sS, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        track.addView(sH, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        styleSegments(0, sS, sH)
        sS.setOnClickListener { type = "SOCKS5"; styleSegments(0, sS, sH) }
        sH.setOnClickListener { type = "HTTP"; styleSegments(1, sS, sH) }
        box.addView(track, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (12 * d).toInt()
        })
        val et = EditText(this).apply {
            minLines = 5
            maxLines = 10
            gravity = Gravity.TOP
            hint = "Paste proxies here"
            textSize = 13f
            setBackgroundResource(R.drawable.bg_field)
            setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
        }
        try {
            val clip = getSystemService(ClipboardManager::class.java).primaryClip
            val t = clip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            if (ProxyParser.parseAll(t, "SOCKS5").isNotEmpty()) et.setText(t)
        } catch (ignored: Exception) {}
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (12 * d).toInt()
        })
        MaterialAlertDialogBuilder(this)
            .setTitle("Bulk import")
            .setView(box)
            .setPositiveButton("Import") { _, _ ->
                val list = ProxyParser.parseAll(et.text.toString(), type).map { it.copy(name = Providers.of(it.host).name + " " + it.port) }
                if (list.isEmpty()) {
                    toast("No valid proxies found")
                } else {
                    Store.saveProfiles(Store.profiles() + list)
                    if (Store.get(Store.selectedId) == null) Store.selectedId = list.first().id
                    refreshProxies()
                    Glass.show(this, Glass.OK, "Imported", "${list.size} proxies added.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ======================= apps =======================

    private fun setupApps() {
        appAdapter = AppAdapter()
        findViewById<RecyclerView>(R.id.rvApps).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = appAdapter
        }
        appAdapter.checked.addAll(Store.apps)
        val segs = listOf<TextView>(findViewById(R.id.segAll), findViewById(R.id.segOnly), findViewById(R.id.segBypass))
        val modes = listOf(Store.MODE_ALL, Store.MODE_ONLY, Store.MODE_EXCLUDE)
        segs.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                Store.appMode = modes[i]
                appsDirty = true
                styleAppMode()
            }
        }
        styleAppMode()
        findViewById<View>(R.id.btnSettings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = appAdapter.filter(s?.toString() ?: "")
        })
    }

    private fun styleAppMode() {
        val segs = listOf<TextView>(findViewById(R.id.segAll), findViewById(R.id.segOnly), findViewById(R.id.segBypass))
        val m = Store.appMode
        styleSegments(when (m) { Store.MODE_ONLY -> 1; Store.MODE_EXCLUDE -> 2; else -> 0 }, *segs.toTypedArray())
    }

    private fun loadApps() {
        if (appsLoaded) return
        appsLoaded = true
        val loading = findViewById<TextView>(R.id.tvLoading)
        loading.visibility = View.VISIBLE
        val checked = appAdapter.checked.toSet()
        bg.execute {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val list = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
                .filter { it.packageName != packageName && it.requestedPermissions?.contains(Manifest.permission.INTERNET) == true }
                .mapNotNull { pi ->
                    val ai = pi.applicationInfo ?: return@mapNotNull null
                    AppItem(pi.packageName, pm.getApplicationLabel(ai).toString(), ai)
                }
                .sortedWith(compareBy<AppItem>({ it.pkg !in checked }, { it.label.lowercase() }))
            runOnUiThread {
                appAdapter.all = list
                appAdapter.filter("")
                loading.visibility = View.GONE
                findViewById<RecyclerView>(R.id.rvApps).scheduleLayoutAnimation()
            }
        }
    }

    private fun applyAppChanges() {
        if (!appsDirty) return
        appsDirty = false
        Store.apps = appAdapter.checked.toSet()
        if (SnakeVpnService.running) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
            toast("Applying app settings")
        }
    }

    // ======================= logs =======================

    private fun setupLogs() {
        logAdapter = LogAdapter()
        rvLogs = findViewById(R.id.rvLogs)
        rvLogs.layoutManager = LinearLayoutManager(this)
        rvLogs.adapter = logAdapter
        val segs = listOf<TextView>(findViewById(R.id.segLogAll), findViewById(R.id.segLogOk), findViewById(R.id.segLogFail))
        segs.forEachIndexed { i, tv -> tv.setOnClickListener { logFilter = i; refreshLogs(true) } }
        findViewById<View>(R.id.btnClearLogs).setOnClickListener {
            ConnLog.clear(); AppLog.clear()
            refreshLogs(true)
        }
        findViewById<View>(R.id.btnUsage).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (e: Exception) { toast("Open Settings → Usage access") }
        }
    }

    private fun refreshLogs(force: Boolean) {
        if (logFilter > 2) logFilter = 0
        val segs = listOf<TextView>(findViewById(R.id.segLogAll), findViewById(R.id.segLogOk), findViewById(R.id.segLogFail))
        styleSegments(logFilter, *segs.toTypedArray())
        if (!force && ConnLog.version == lastLogVersion) return
        lastLogVersion = ConnLog.version
        val all = ConnLog.snapshot()
        findViewById<TextView>(R.id.tvOkCount).text = all.count { it.ok }.toString()
        findViewById<TextView>(R.id.tvFailCount).text = all.count { !it.ok }.toString()
        findViewById<TextView>(R.id.tvAppCount).text = all.mapNotNull { it.pkg }.toSet().size.toString()
        val shown = when (logFilter) {
            1 -> all.filter { it.ok }
            2 -> all.filter { !it.ok }
            else -> all
        }.take(250)
        val before = logAdapter.items.size
        logAdapter.items = shown
        if (!force && shown.size > before && before > 0) {
            logAdapter.notifyItemRangeInserted(0, shown.size - before)
            logAdapter.notifyItemRangeChanged(shown.size - before, before)
            if (!rvLogs.canScrollVertically(-1)) rvLogs.scrollToPosition(0)
        } else {
            logAdapter.notifyDataSetChanged()
        }
        findViewById<View>(R.id.tvLogsEmpty).visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ======================= adapters =======================

    inner class CountryAdapter(private val onPick: (String) -> Unit) : RecyclerView.Adapter<CountryAdapter.VH>() {
        var query = ""
        var selected = ""
        private var rows: List<Pair<String, String>> = emptyList()

        fun rebuild() {
            val q = query.trim().lowercase()
            rows = if (q.isNotEmpty()) {
                Countries.all.filter { it.name.lowercase().contains(q) || it.code.lowercase() == q }.map { it.code to it.code }
            } else {
                val recent = Store.recentCountries.map { it to "Recent" }
                listOf("" to "Proxy default location") + recent + Countries.all.map { it.code to it.code }
            }
            notifyDataSetChanged()
        }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val row: View = v.findViewById(R.id.row)
            val cc: TextView = v.findViewById(R.id.tvCc)
            val flag: ImageView = v.findViewById(R.id.ivFlag)
            val auto: ImageView = v.findViewById(R.id.ivAuto)
            val name: TextView = v.findViewById(R.id.tvName)
            val sub: TextView = v.findViewById(R.id.tvSub)
            val radio: View = v.findViewById(R.id.vRadio)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_country, parent, false).also { Motion.pressable(it) })

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val (code, sub) = rows[pos]
            if (code.isEmpty()) {
                h.name.text = "Auto"
                h.cc.text = ""
                h.auto.visibility = View.VISIBLE
                Img.load(h.flag, null)
            } else {
                h.name.text = Countries.name(code)
                h.auto.visibility = View.GONE
                bindFlag(h.cc, h.flag, code)
            }
            h.sub.text = sub
            val on = code == selected
            h.radio.setBackgroundResource(if (on) R.drawable.bg_radio_on else R.drawable.bg_check_off)
            h.row.setBackgroundResource(if (on) R.drawable.bg_glass_selected else R.drawable.bg_glass)
            h.row.setOnClickListener { onPick(code) }
        }
    }

    class ProxyAdapter(
        private val onEdit: (ProxyProfile) -> Unit,
        private val onSelect: (ProxyProfile) -> Unit,
        private val onLong: (ProxyProfile, View) -> Unit
    ) : RecyclerView.Adapter<ProxyAdapter.VH>() {
        data class Res(val state: Int, val text: String)

        var items: List<ProxyProfile> = emptyList()
        var selectedId: String? = null
        var activeId: String? = null
        val results = HashMap<String, Res>()

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val card: View = v.findViewById(R.id.card)
            val letter: TextView = v.findViewById(R.id.tvLetter)
            val prov: ImageView = v.findViewById(R.id.ivProv)
            val name: TextView = v.findViewById(R.id.tvName)
            val host: TextView = v.findViewById(R.id.tvHost)
            val type: TextView = v.findViewById(R.id.tvType)
            val geo: TextView = v.findViewById(R.id.tvGeo)
            val result: TextView = v.findViewById(R.id.tvResult)
            val radioBox: View = v.findViewById(R.id.radioBox)
            val radio: View = v.findViewById(R.id.vRadio)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_proxy, parent, false).also { Motion.pressable(it) })

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val p = items[pos]
            val ctx = h.itemView.context
            val prov = Providers.of(p.host)
            h.name.text = p.name
            h.host.text = "${p.host}:${p.port}" + if (p.user.isNotEmpty()) "  ·  login" else ""
            h.type.text = p.type
            val canGeo = CountryRouting.canTarget(p)
            h.geo.text = if (canGeo) "All countries" else "Fixed location"
            h.geo.setTextColor(ContextCompat.getColor(ctx, if (canGeo) R.color.mint_dark else R.color.text2))
            bindProvider(h.letter, h.prov, p.host, prov.name)

            val selected = p.id == selectedId
            h.card.setBackgroundResource(if (selected) R.drawable.bg_glass_selected else R.drawable.bg_glass)
            h.radio.setBackgroundResource(if (selected) R.drawable.bg_radio_on else R.drawable.bg_check_off)

            val r = results[p.id]
            if (r == null) {
                h.result.visibility = View.GONE
            } else {
                h.result.visibility = View.VISIBLE
                h.result.text = r.text
                h.result.setTextColor(
                    ContextCompat.getColor(ctx, when (r.state) { 1 -> R.color.green; 2 -> R.color.red; else -> R.color.text2 })
                )
            }
            h.card.setOnClickListener { onEdit(p) }
            h.radioBox.setOnClickListener {
                h.radio.animate().scaleX(1.25f).scaleY(1.25f).setDuration(110).withEndAction {
                    h.radio.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                }.start()
                onSelect(p)
            }
            h.card.setOnLongClickListener { onLong(p, it); true }
        }
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        var all: List<AppItem> = emptyList()
        private var shown: List<AppItem> = emptyList()
        val checked = HashSet<String>()

        fun filter(q: String) {
            val s = q.trim().lowercase()
            shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) || it.pkg.contains(s) }
            notifyDataSetChanged()
        }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val row: View = v.findViewById(R.id.row)
            val icon: ImageView = v.findViewById(R.id.ivIcon)
            val label: TextView = v.findViewById(R.id.tvLabel)
            val pkg: TextView = v.findViewById(R.id.tvPkg)
            val check: ImageView = v.findViewById(R.id.ivCheck)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false).also { Motion.pressable(it) })

        override fun getItemCount() = shown.size

        private fun paint(h: VH, on: Boolean) {
            if (on) {
                h.check.setBackgroundResource(R.drawable.bg_check_on)
                h.check.setImageResource(R.drawable.ic_check)
                h.check.setColorFilter(Color.WHITE)
            } else {
                h.check.setBackgroundResource(R.drawable.bg_check_off)
                h.check.setImageDrawable(null)
            }
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val a = shown[pos]
            h.label.text = a.label
            h.pkg.text = a.pkg
            h.icon.setImageDrawable(try { a.info.loadIcon(packageManager) } catch (e: Exception) { null })
            paint(h, a.pkg in checked)
            h.row.setOnClickListener {
                if (!checked.add(a.pkg)) checked.remove(a.pkg)
                appsDirty = true
                paint(h, a.pkg in checked)
                h.check.scaleX = 0.6f; h.check.scaleY = 0.6f
                h.check.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
        }
    }

    inner class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {
        var items: List<ConnEvent> = emptyList()
        private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.ivApp)
            val dot: View = v.findViewById(R.id.vStatus)
            val app: TextView = v.findViewById(R.id.tvApp)
            val host: TextView = v.findViewById(R.id.tvHost)
            val err: TextView = v.findViewById(R.id.tvErr)
            val status: TextView = v.findViewById(R.id.tvStatus)
            val time: TextView = v.findViewById(R.id.tvTime)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_log, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val e = items[pos]
            val ctx = this@MainActivity
            val pad = (10 * resources.displayMetrics.density).toInt()
            val pkg = e.pkg
            if (pkg != null) {
                h.app.text = AppInfo.label(ctx, pkg)
                val d = AppInfo.icon(ctx, pkg)
                if (d != null) { h.icon.setImageDrawable(d); h.icon.setPadding(2, 2, 2, 2) }
                else { h.icon.setImageResource(R.drawable.ic_apps); h.icon.setPadding(pad, pad, pad, pad) }
            } else {
                h.app.text = if (Foreground.hasPermission(ctx)) "Background app" else "App connection"
                h.icon.setImageResource(R.drawable.ic_apps)
                h.icon.setPadding(pad, pad, pad, pad)
            }
            h.host.text = "${e.host}:${e.port}"
            h.time.text = fmt.format(Date(e.time))
            if (e.ok) {
                h.dot.setBackgroundResource(R.drawable.bg_dot_green)
                h.status.setBackgroundResource(R.drawable.bg_pill_ok)
                h.status.setTextColor(ContextCompat.getColor(ctx, R.color.green))
                h.status.text = "OK ${e.ms}ms"
                h.err.visibility = View.GONE
            } else {
                h.dot.setBackgroundResource(R.drawable.bg_dot_red)
                h.status.setBackgroundResource(R.drawable.bg_pill_bad)
                h.status.setTextColor(ContextCompat.getColor(ctx, R.color.red))
                h.status.text = "FAILED"
                h.err.visibility = View.VISIBLE
                h.err.text = e.error
            }
        }
    }
}
