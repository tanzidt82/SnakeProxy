package com.snake.proxy

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvProfile: TextView
    private lateinit var tvHealth: TextView
    private lateinit var tvUp: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvUptime: TextView
    private lateinit var tvIp: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnConnect: MaterialButton
    private lateinit var adapter: ProfileAdapter

    private val ui = Handler(Looper.getMainLooper())
    private val bg = Executors.newCachedThreadPool()
    private var shownError = ""
    private var state = -1

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpn()
        else toast("VPN permission is required to connect")
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvProfile = findViewById(R.id.tvProfile)
        tvHealth = findViewById(R.id.tvHealth)
        tvUp = findViewById(R.id.tvUp)
        tvDown = findViewById(R.id.tvDown)
        tvTotal = findViewById(R.id.tvTotal)
        tvUptime = findViewById(R.id.tvUptime)
        tvIp = findViewById(R.id.tvIp)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnConnect = findViewById(R.id.btnConnect)

        adapter = ProfileAdapter(::onSelect, ::onLongPress)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        btnConnect.setOnClickListener { onConnectClick() }
        findViewById<View>(R.id.btnLeak).setOnClickListener { leakTest() }
        findViewById<View>(R.id.btnApps).setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        findViewById<View>(R.id.btnLog).setOnClickListener { startActivity(Intent(this, LogActivity::class.java)) }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        ui.post(ticker)
        if (Store.autoSync && Store.subUrl.isNotBlank() &&
            System.currentTimeMillis() - SubSync.lastSync > 5 * 60_000
        ) {
            bg.execute { SubSync.sync(); runOnUiThread { refreshList() } }
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    // ---------------- menu ----------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.m_add -> startActivity(Intent(this, EditProfileActivity::class.java))
            R.id.m_import -> showImport()
            R.id.m_sync -> {
                if (Store.subUrl.isBlank()) {
                    toast("Set a subscription URL in Settings first")
                    startActivity(Intent(this, SettingsActivity::class.java))
                } else {
                    toast("Syncing…")
                    bg.execute {
                        val r = SubSync.sync()
                        runOnUiThread {
                            refreshList()
                            toast(r.fold({ "✅ $it proxies loaded" }, { "❌ ${it.message}" }))
                        }
                    }
                }
            }
            R.id.m_testall -> testAll()
            R.id.m_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------- connect ----------------

    private fun onConnectClick() {
        if (SnakeVpnService.running || SnakeVpnService.connecting) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_STOP)
            return
        }
        if (Store.get(Store.selectedId) == null) {
            toast("Select a proxy from the list first")
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPermission.launch(i) else startVpn()
    }

    private fun startVpn() {
        shownError = ""
        SnakeVpnService.send(this, SnakeVpnService.ACTION_START, Store.selectedId)
    }

    private fun updateStatus() {
        val s = SnakeVpnService
        val newState = when {
            s.running -> 2
            s.connecting -> 1
            else -> 0
        }
        if (newState != state) {
            state = newState
            val (label, statusText, color) = when (newState) {
                2 -> Triple("DISCONNECT", "Connected", ContextCompat.getColor(this, R.color.green))
                1 -> Triple("CANCEL", "Connecting…", Color.parseColor("#F59E0B"))
                else -> Triple("CONNECT", "Disconnected", ContextCompat.getColor(this, R.color.snake))
            }
            btnConnect.text = label
            btnConnect.backgroundTintList = ColorStateList.valueOf(color)
            tvStatus.text = statusText
            tvStatus.setTextColor(if (newState == 0) tvProfile.currentTextColor else color)
        }

        val sel = Store.get(Store.selectedId)
        tvProfile.text = if (s.running) s.profileName else sel?.name ?: "No proxy selected"
        val h = if (s.running) s.health else s.lastError.let { if (it.isEmpty()) "" else "❌ $it" }
        tvHealth.text = h
        tvHealth.visibility = if (h.isEmpty()) View.GONE else View.VISIBLE
        tvUp.text = Fmt.speed(s.upSpeed)
        tvDown.text = Fmt.speed(s.downSpeed)
        tvTotal.text = Fmt.bytes(s.totalUp + s.totalDown)
        tvUptime.text = if (s.running && s.startedAt > 0) Fmt.dur(System.currentTimeMillis() - s.startedAt) else "00:00:00"
        tvIp.text = s.exitIp.ifEmpty { "—" }

        if (!s.running && !s.connecting && s.lastError.isNotEmpty() && s.lastError != shownError) {
            shownError = s.lastError
            MaterialAlertDialogBuilder(this)
                .setTitle("Connection failed")
                .setMessage(s.lastError)
                .setPositiveButton("OK", null)
                .setNeutralButton("View logs") { _, _ -> startActivity(Intent(this, LogActivity::class.java)) }
                .show()
        }

        if (adapter.activeId != s.profileId || adapter.selectedId != Store.selectedId) {
            adapter.activeId = s.profileId
            adapter.selectedId = Store.selectedId
            adapter.notifyDataSetChanged()
        }
    }

    // ---------------- list ----------------

    private fun refreshList() {
        adapter.items = Store.profiles()
        adapter.selectedId = Store.selectedId
        adapter.activeId = SnakeVpnService.profileId
        adapter.notifyDataSetChanged()
        tvEmpty.visibility = if (adapter.items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun onSelect(p: ProxyProfile) {
        Store.selectedId = p.id
        refreshList()
        if (SnakeVpnService.running && SnakeVpnService.profileId != p.id) {
            toast("Switching to ${p.name}…")
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
        }
    }

    private fun onLongPress(p: ProxyProfile, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Test")
        pm.menu.add(0, 2, 1, "Edit")
        pm.menu.add(0, 3, 2, "Copy (ip:port:user:pass)")
        pm.menu.add(0, 4, 3, "Delete")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> testOne(p)
                2 -> startActivity(Intent(this, EditProfileActivity::class.java).putExtra("id", p.id))
                3 -> {
                    val line = if (p.user.isEmpty()) "${p.host}:${p.port}" else "${p.host}:${p.port}:${p.user}:${p.pass}"
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("proxy", line))
                    toast("Copied")
                }
                4 -> MaterialAlertDialogBuilder(this)
                    .setTitle("Delete proxy?")
                    .setMessage(p.name)
                    .setPositiveButton("Delete") { _, _ -> Store.delete(p.id); refreshList() }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun testOne(p: ProxyProfile) {
        adapter.results[p.id] = "⏳ Testing…"
        adapter.notifyDataSetChanged()
        bg.execute {
            val r = ProxyTester.test(p)
            runOnUiThread {
                adapter.results[p.id] = if (r.ok) "✅ ${r.ms} ms · ${r.ip}" else "❌ ${r.error}"
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun testAll() {
        if (adapter.items.isEmpty()) { toast("No proxies to test"); return }
        adapter.items.forEach { testOne(it) }
    }

    // ---------------- bulk import ----------------

    private fun showImport() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad + pad / 2, pad / 2, pad + pad / 2, 0)
        }
        box.addView(TextView(this).apply {
            text = "One proxy per line:\nip:port:user:pass\nsocks5://user:pass@ip:port\nhttp://user:pass@ip:port"
            textSize = 13f
        })
        val rg = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rbS = RadioButton(this).apply { id = View.generateViewId(); text = "SOCKS5" }
        val rbH = RadioButton(this).apply { id = View.generateViewId(); text = "HTTP" }
        rg.addView(rbS); rg.addView(rbH); rg.check(rbS.id)
        box.addView(TextView(this).apply {
            text = "Type for lines without a scheme:"
            textSize = 13f
            setPadding(0, pad / 2, 0, 0)
        })
        box.addView(rg)
        val et = EditText(this).apply {
            minLines = 5
            maxLines = 10
            gravity = Gravity.TOP
            hint = "Paste here"
            textSize = 13f
        }
        try {
            val clip = getSystemService(ClipboardManager::class.java).primaryClip
            val t = clip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            if (ProxyParser.parseAll(t, "SOCKS5").isNotEmpty()) et.setText(t)
        } catch (ignored: Exception) {}
        box.addView(et, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        MaterialAlertDialogBuilder(this)
            .setTitle("Bulk import")
            .setView(box)
            .setPositiveButton("Import") { _, _ ->
                val list = ProxyParser.parseAll(et.text.toString(), if (rbH.isChecked) "HTTP" else "SOCKS5")
                if (list.isEmpty()) {
                    toast("No valid proxies found")
                } else {
                    Store.saveProfiles(Store.profiles() + list)
                    if (Store.get(Store.selectedId) == null) Store.selectedId = list.first().id
                    refreshList()
                    toast("✅ Added ${list.size} proxies")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- leak test ----------------

    private fun leakTest() {
        val p = Store.get(Store.selectedId)
        if (p == null) { toast("Select a proxy first"); return }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("Leak test")
            .setMessage("⏳ Checking…")
            .setPositiveButton("OK", null)
            .show()
        bg.execute {
            val real = ProxyTester.directIp()
            val r = ProxyTester.test(p)
            val msg = buildString {
                appendLine("Your real IP: $real")
                appendLine("Proxy IP: " + if (r.ok) r.ip else "❌ ${r.error}")
                appendLine()
                when {
                    !r.ok -> appendLine("The proxy is not working. Check host, port, username and password.")
                    r.ip == real -> appendLine("⚠ Proxy IP equals your real IP — this proxy does not hide you.")
                    else -> appendLine("✅ The proxy changes your IP correctly.")
                }
                appendLine()
                if (SnakeVpnService.running) {
                    appendLine("Final check: open the browser tests below. If they show the proxy IP and no IPv6/DNS from your real country or carrier, there is no leak.")
                } else {
                    appendLine("Connect first, then run this test again for a full leak check.")
                }
            }
            runOnUiThread {
                if (!dlg.isShowing) return@runOnUiThread
                dlg.dismiss()
                val b = MaterialAlertDialogBuilder(this)
                    .setTitle("Leak test result")
                    .setMessage(msg)
                    .setNegativeButton("Close", null)
                if (SnakeVpnService.running) {
                    b.setPositiveButton("IP check") { _, _ -> openUrl("https://browserleaks.com/ip") }
                    b.setNeutralButton("DNS check") { _, _ -> openUrl("https://browserleaks.com/dns") }
                }
                b.show()
            }
        }
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (ignored: Exception) { toast("Could not open browser") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

class ProfileAdapter(
    private val onClick: (ProxyProfile) -> Unit,
    private val onLong: (ProxyProfile, View) -> Unit
) : RecyclerView.Adapter<ProfileAdapter.VH>() {

    var items: List<ProxyProfile> = emptyList()
    var selectedId: String? = null
    var activeId: String? = null
    val results = HashMap<String, String>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: MaterialCardView = v.findViewById(R.id.itemCard)
        val dot: TextView = v.findViewById(R.id.tvDot)
        val name: TextView = v.findViewById(R.id.tvName)
        val detail: TextView = v.findViewById(R.id.tvDetail)
        val result: TextView = v.findViewById(R.id.tvResult)
        val badge: TextView = v.findViewById(R.id.tvBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        val ctx = h.itemView.context
        val accent = ContextCompat.getColor(ctx, R.color.snake)
        val green = ContextCompat.getColor(ctx, R.color.green)
        val selected = p.id == selectedId
        val active = p.id == activeId

        h.name.text = p.name + if (p.fromSub) "  ☁" else ""
        h.detail.text = p.detail
        h.dot.text = if (p.type == "HTTP") "HTTP" else "S5"
        h.dot.textSize = if (p.type == "HTTP") 10f else 12f
        h.dot.setBackgroundResource(R.drawable.bg_badge)
        h.dot.setTextColor(accent)

        h.badge.text = when {
            active -> "● ACTIVE"
            selected -> "SELECTED"
            else -> ""
        }
        h.badge.setTextColor(if (active) green else accent)
        h.badge.visibility = if (h.badge.text.isEmpty()) View.GONE else View.VISIBLE

        h.card.strokeColor = if (active) green else if (selected) accent else Color.parseColor("#33888888")
        h.card.strokeWidth = if (selected || active) 4 else 2

        val r = results[p.id]
        h.result.text = r ?: ""
        h.result.visibility = if (r == null) View.GONE else View.VISIBLE
        h.itemView.setOnClickListener { onClick(p) }
        h.itemView.setOnLongClickListener { onLong(p, it); true }
    }
}
