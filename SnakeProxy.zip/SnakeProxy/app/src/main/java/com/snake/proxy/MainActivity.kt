package com.snake.proxy

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvProfile: TextView
    private lateinit var tvHealth: TextView
    private lateinit var tvUp: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvUptime: TextView
    private lateinit var tvIp: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnConnect: MaterialButton
    private lateinit var adapter: ProfileAdapter

    private val ui = Handler(Looper.getMainLooper())
    private val bg = Executors.newCachedThreadPool()

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpn()
        else toast("VPN অনুমতি না দিলে প্রক্সি চালু হবে না")
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvProfile = findViewById(R.id.tvProfile)
        tvHealth = findViewById(R.id.tvHealth)
        tvUp = findViewById(R.id.tvUp)
        tvDown = findViewById(R.id.tvDown)
        tvTotal = findViewById(R.id.tvTotal)
        tvUptime = findViewById(R.id.tvUptime)
        tvIp = findViewById(R.id.tvIp)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnConnect = findViewById(R.id.btnConnect)

        adapter = ProfileAdapter(::onSelect, ::onLongPress)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        btnConnect.setOnClickListener { onConnectClick() }
        findViewById<View>(R.id.btnLeak).setOnClickListener { leakTest() }
        findViewById<View>(R.id.btnApps).setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        findViewById<View>(R.id.btnLog).setOnClickListener { startActivity(Intent(this, LogActivity::class.java)) }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        ui.post(ticker)
        if (Store.autoSync && Store.subUrl.isNotBlank() &&
            System.currentTimeMillis() - SubSync.lastSync > 5 * 60_000
        ) {
            bg.execute { SubSync.sync(); runOnUiThread { refreshList() } }
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    // ---------------- মেনু ----------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.m_add -> startActivity(Intent(this, EditProfileActivity::class.java))
            R.id.m_import -> showImport()
            R.id.m_sync -> {
                if (Store.subUrl.isBlank()) {
                    toast("আগে সেটিংসে সাবস্ক্রিপশন লিংক দিন")
                    startActivity(Intent(this, SettingsActivity::class.java))
                } else {
                    toast("সিঙ্ক হচ্ছে...")
                    bg.execute {
                        val r = SubSync.sync()
                        runOnUiThread {
                            refreshList()
                            toast(r.fold({ "✅ ${it}টি প্রক্সি পাওয়া গেছে" }, { "❌ ${it.message}" }))
                        }
                    }
                }
            }
            R.id.m_testall -> testAll()
            R.id.m_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------- কানেক্ট ----------------

    private fun onConnectClick() {
        if (SnakeVpnService.running || SnakeVpnService.connecting) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_STOP)
            return
        }
        if (Store.get(Store.selectedId) == null) {
            toast("আগে লিস্ট থেকে একটা প্রক্সি বাছাই করুন")
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPermission.launch(i) else startVpn()
    }

    private fun startVpn() {
        SnakeVpnService.send(this, SnakeVpnService.ACTION_START, Store.selectedId)
    }

    private fun updateStatus() {
        val s = SnakeVpnService
        when {
            s.running -> {
                tvStatus.text = "● সংযুক্ত"
                tvStatus.setTextColor(ContextCompat.getColor(this, R.color.green))
                btnConnect.text = "ডিসকানেক্ট"
            }
            s.connecting -> {
                tvStatus.text = "● কানেক্ট হচ্ছে..."
                tvStatus.setTextColor(ContextCompat.getColor(this, R.color.snake))
                btnConnect.text = "বাতিল"
            }
            else -> {
                tvStatus.text = "● সংযুক্ত নয়"
                tvStatus.setTextColor(tvProfile.currentTextColor)
                btnConnect.text = "কানেক্ট"
            }
        }
        val sel = Store.get(Store.selectedId)
        tvProfile.text = "প্রক্সি: " + (if (s.running) s.profileName else sel?.name ?: "-")
        tvHealth.text = s.health
        tvHealth.visibility = if (s.health.isEmpty()) View.GONE else View.VISIBLE
        tvUp.text = "↑ ${Fmt.speed(s.upSpeed)}"
        tvDown.text = "↓ ${Fmt.speed(s.downSpeed)}"
        tvTotal.text = "মোট ডাটা: ↑ ${Fmt.bytes(s.totalUp)}   ↓ ${Fmt.bytes(s.totalDown)}"
        tvUptime.text = "সময়: " + if (s.running && s.startedAt > 0) Fmt.dur(System.currentTimeMillis() - s.startedAt) else "00:00:00"
        tvIp.text = "প্রক্সি IP: " + s.exitIp.ifEmpty { "-" }

        if (adapter.activeId != s.profileId || adapter.selectedId != Store.selectedId) {
            adapter.activeId = s.profileId
            adapter.selectedId = Store.selectedId
            adapter.notifyDataSetChanged()
        }
    }

    // ---------------- লিস্ট ----------------

    private fun refreshList() {
        adapter.items = Store.profiles()
        adapter.selectedId = Store.selectedId
        adapter.activeId = SnakeVpnService.profileId
        adapter.notifyDataSetChanged()
        tvEmpty.visibility = if (adapter.items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun onSelect(p: ProxyProfile) {
        Store.selectedId = p.id
        refreshList()
        if (SnakeVpnService.running) {
            toast("${p.name} এ বদলানো হচ্ছে (ডিসকানেক্ট ছাড়াই)")
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
        }
    }

    private fun onLongPress(p: ProxyProfile, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "টেস্ট")
        pm.menu.add(0, 2, 1, "এডিট")
        pm.menu.add(0, 3, 2, "কপি (ip:port:user:pass)")
        pm.menu.add(0, 4, 3, "ডিলিট")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> testOne(p)
                2 -> startActivity(Intent(this, EditProfileActivity::class.java).putExtra("id", p.id))
                3 -> {
                    val cm = getSystemService(ClipboardManager::class.java)
                    val line = if (p.user.isEmpty()) "${p.host}:${p.port}" else "${p.host}:${p.port}:${p.user}:${p.pass}"
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("proxy", line))
                    toast("কপি হয়েছে")
                }
                4 -> MaterialAlertDialogBuilder(this)
                    .setTitle("ডিলিট করবেন?")
                    .setMessage(p.name)
                    .setPositiveButton("ডিলিট") { _, _ -> Store.delete(p.id); refreshList() }
                    .setNegativeButton("না", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun testOne(p: ProxyProfile) {
        adapter.results[p.id] = "⏳ টেস্ট হচ্ছে..."
        adapter.notifyDataSetChanged()
        bg.execute {
            val r = ProxyTester.test(p)
            runOnUiThread {
                adapter.results[p.id] = if (r.ok) "✅ ${r.ms}ms • IP: ${r.ip}" else "❌ ${r.error}"
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun testAll() {
        if (adapter.items.isEmpty()) { toast("কোনো প্রক্সি নেই"); return }
        adapter.items.forEach { testOne(it) }
    }

    // ---------------- বাল্ক ইমপোর্ট ----------------

    private fun showImport() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad + pad / 2, pad / 2, pad + pad / 2, 0)
        }
        box.addView(TextView(this).apply {
            text = "প্রতি লাইনে একটা প্রক্সি:\nip:port:user:pass\nsocks5://user:pass@ip:port\nhttp://user:pass@ip:port"
            textSize = 13f
        })
        val rg = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rbS = RadioButton(this).apply { id = View.generateViewId(); text = "SOCKS5" }
        val rbH = RadioButton(this).apply { id = View.generateViewId(); text = "HTTP" }
        rg.addView(rbS); rg.addView(rbH); rg.check(rbS.id)
        box.addView(TextView(this).apply { text = "যেসব লাইনে টাইপ লেখা নেই সেগুলোর টাইপ:"; textSize = 13f; setPadding(0, pad / 2, 0, 0) })
        box.addView(rg)
        val et = EditText(this).apply {
            minLines = 5
            maxLines = 10
            gravity = Gravity.TOP
            hint = "এখানে পেস্ট করুন"
            textSize = 13f
        }
        try {
            val clip = getSystemService(ClipboardManager::class.java).primaryClip
            val t = clip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            if (ProxyParser.parseAll(t, "SOCKS5").isNotEmpty()) et.setText(t)
        } catch (ignored: Exception) {}
        box.addView(et, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        MaterialAlertDialogBuilder(this)
            .setTitle("বাল্ক ইমপোর্ট")
            .setView(box)
            .setPositiveButton("ইমপোর্ট") { _, _ ->
                val list = ProxyParser.parseAll(et.text.toString(), if (rbH.isChecked) "HTTP" else "SOCKS5")
                if (list.isEmpty()) {
                    toast("কোনো সঠিক প্রক্সি পাওয়া যায়নি")
                } else {
                    Store.saveProfiles(Store.profiles() + list)
                    if (Store.get(Store.selectedId) == null) Store.selectedId = list.first().id
                    refreshList()
                    toast("✅ ${list.size}টি প্রক্সি যোগ হয়েছে")
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---------------- লিক টেস্ট ----------------

    private fun leakTest() {
        val p = Store.get(Store.selectedId)
        if (p == null) { toast("আগে একটা প্রক্সি বাছাই করুন"); return }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("লিক টেস্ট")
            .setMessage("⏳ চেক হচ্ছে...")
            .setPositiveButton("ঠিক আছে", null)
            .show()
        bg.execute {
            val real = ProxyTester.directIp()
            val r = ProxyTester.test(p)
            val msg = buildString {
                appendLine("আপনার আসল IP: $real")
                appendLine("প্রক্সি IP: " + if (r.ok) r.ip else "❌ ${r.error}")
                appendLine()
                when {
                    !r.ok -> appendLine("প্রক্সি কাজ করছে না। ইউজারনেম/পাসওয়ার্ড/পোর্ট চেক করুন।")
                    r.ip == real -> appendLine("⚠ প্রক্সি IP আর আসল IP একই! এই প্রক্সি আপনার IP লুকাচ্ছে না।")
                    else -> appendLine("✅ প্রক্সি ঠিকমতো IP বদলাচ্ছে।")
                }
                appendLine()
                if (SnakeVpnService.running) {
                    appendLine("শেষ ধাপ: নিচের বাটন চেপে ব্রাউজারে চেক করুন। সেখানে IP যদি ${if (r.ok) r.ip else "প্রক্সি IP"} দেখায় এবং IPv6/DNS এ আপনার আসল দেশ বা অপারেটর না দেখায়, তাহলে কোনো লিক নেই।")
                } else {
                    appendLine("পুরো লিক টেস্টের জন্য আগে কানেক্ট করুন, তারপর আবার এই টেস্ট চালান।")
                }
            }
            runOnUiThread {
                if (!dlg.isShowing) return@runOnUiThread
                dlg.dismiss()
                val b = MaterialAlertDialogBuilder(this)
                    .setTitle("লিক টেস্ট ফলাফল")
                    .setMessage(msg)
                    .setNegativeButton("বন্ধ", null)
                if (SnakeVpnService.running) {
                    b.setPositiveButton("IP চেক (ব্রাউজার)") { _, _ -> openUrl("https://browserleaks.com/ip") }
                    b.setNeutralButton("DNS চেক") { _, _ -> openUrl("https://browserleaks.com/dns") }
                }
                b.show()
            }
        }
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (ignored: Exception) { toast("ব্রাউজার খোলা যায়নি") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

class ProfileAdapter(
    private val onClick: (ProxyProfile) -> Unit,
    private val onLong: (ProxyProfile, View) -> Unit
) : RecyclerView.Adapter<ProfileAdapter.VH>() {

    var items: List<ProxyProfile> = emptyList()
    var selectedId: String? = null
    var activeId: String? = null
    val results = HashMap<String, String>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: MaterialCardView = v.findViewById(R.id.itemCard)
        val dot: TextView = v.findViewById(R.id.tvDot)
        val name: TextView = v.findViewById(R.id.tvName)
        val detail: TextView = v.findViewById(R.id.tvDetail)
        val result: TextView = v.findViewById(R.id.tvResult)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        val ctx = h.itemView.context
        h.name.text = p.name + if (p.fromSub) "  ☁" else ""
        h.detail.text = p.detail
        h.dot.text = when {
            p.id == activeId -> "🟢"
            p.id == selectedId -> "◉"
            else -> "○"
        }
        h.card.strokeColor = ContextCompat.getColor(
            ctx, if (p.id == selectedId) R.color.snake else android.R.color.darker_gray
        )
        h.card.strokeWidth = if (p.id == selectedId) 4 else 1
        val r = results[p.id]
        h.result.text = r ?: ""
        h.result.visibility = if (r == null) View.GONE else View.VISIBLE
        h.itemView.setOnClickListener { onClick(p) }
        h.itemView.setOnLongClickListener { onLong(p, it); true }
    }
}
