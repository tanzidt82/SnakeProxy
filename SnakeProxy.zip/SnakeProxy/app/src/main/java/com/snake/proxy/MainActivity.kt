package com.snake.proxy

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvBadge: TextView
    private lateinit var vDot: View
    private lateinit var tvProfile: TextView
    private lateinit var tvHealth: TextView
    private lateinit var tvUp: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvUptime: TextView
    private lateinit var tvIp: TextView
    private lateinit var emptyBox: View
    private lateinit var btnConnect: TextView
    private lateinit var btnOrb: ImageButton
    private lateinit var ivOrb: ImageView
    private lateinit var adapter: ProfileAdapter

    private val ui = Handler(Looper.getMainLooper())
    private val bg = Executors.newCachedThreadPool()
    private var shownError = ""
    private var state = -1
    private var spin: ObjectAnimator? = null
    private var pulse: ObjectAnimator? = null

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpn()
        else toast("VPN permission is required to connect")
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateStatus()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvBadge = findViewById(R.id.tvBadge)
        vDot = findViewById(R.id.vDot)
        tvProfile = findViewById(R.id.tvProfile)
        tvHealth = findViewById(R.id.tvHealth)
        tvUp = findViewById(R.id.tvUp)
        tvDown = findViewById(R.id.tvDown)
        tvTotal = findViewById(R.id.tvTotal)
        tvUptime = findViewById(R.id.tvUptime)
        tvIp = findViewById(R.id.tvIp)
        emptyBox = findViewById(R.id.emptyBox)
        btnConnect = findViewById(R.id.btnConnect)
        btnOrb = findViewById(R.id.btnOrb)
        ivOrb = findViewById(R.id.ivOrb)

        adapter = ProfileAdapter(::onSelect, ::onLongPress)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        btnConnect.setOnClickListener { onConnectClick() }
        btnOrb.setOnClickListener { onConnectClick() }
        val openAdd = View.OnClickListener { startActivity(Intent(this, EditProfileActivity::class.java)) }
        findViewById<View>(R.id.btnAdd).setOnClickListener(openAdd)
        findViewById<View>(R.id.qaAdd).setOnClickListener(openAdd)
        findViewById<View>(R.id.qaImport).setOnClickListener { showImport() }
        findViewById<View>(R.id.qaApps).setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        findViewById<View>(R.id.qaLeak).setOnClickListener { leakTest() }
        findViewById<View>(R.id.qaSync).setOnClickListener { syncNow() }
        findViewById<View>(R.id.btnTestAll).setOnClickListener { testAll() }
        findViewById<View>(R.id.navApps).setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        findViewById<View>(R.id.navLogs).setOnClickListener { startActivity(Intent(this, LogActivity::class.java)) }
        findViewById<View>(R.id.navSettings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        // gentle floating motion on the 3D globe
        ObjectAnimator.ofFloat(ivOrb, "translationY", -6f, 6f).apply {
            duration = 2600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        ui.post(ticker)
        if (Store.autoSync && Store.subUrl.isNotBlank() &&
            System.currentTimeMillis() - SubSync.lastSync > 5 * 60_000
        ) {
            bg.execute { SubSync.sync(); runOnUiThread { refreshList() } }
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    // ---------------- connect ----------------

    private fun onConnectClick() {
        if (SnakeVpnService.running || SnakeVpnService.connecting) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_STOP)
            return
        }
        if (Store.get(Store.selectedId) == null) {
            toast("Select a proxy from the list first")
            return
        }
        val i = VpnService.prepare(this)
        if (i != null) vpnPermission.launch(i) else startVpn()
    }

    private fun startVpn() {
        shownError = ""
        SnakeVpnService.send(this, SnakeVpnService.ACTION_START, Store.selectedId)
    }

    private fun applyState(newState: Int) {
        state = newState
        spin?.cancel(); spin = null
        pulse?.cancel(); pulse = null
        btnOrb.rotation = 0f
        btnOrb.scaleX = 1f; btnOrb.scaleY = 1f
        when (newState) {
            2 -> {
                tvBadge.text = "PROTECTED"
                vDot.setBackgroundResource(R.drawable.bg_dot_green)
                tvStatus.text = "You're protected"
                btnConnect.text = "Disconnect"
                btnOrb.setBackgroundResource(R.drawable.bg_orb_on)
                btnOrb.setColorFilter(ContextCompat.getColor(this, R.color.mint))
                pulse = ObjectAnimator.ofFloat(btnOrb, "scaleX", 1f, 1.05f).apply {
                    duration = 1200
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    addUpdateListener { btnOrb.scaleY = btnOrb.scaleX }
                    start()
                }
            }
            1 -> {
                tvBadge.text = "CONNECTING"
                vDot.setBackgroundResource(R.drawable.bg_dot_gray)
                tvStatus.text = "Connecting…"
                btnConnect.text = "Cancel"
                btnOrb.setBackgroundResource(R.drawable.bg_orb_wait)
                btnOrb.setColorFilter(Color.WHITE)
                spin = ObjectAnimator.ofFloat(btnOrb, "rotation", 0f, 360f).apply {
                    duration = 1400
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    start()
                }
            }
            else -> {
                tvBadge.text = "UNPROTECTED"
                vDot.setBackgroundResource(R.drawable.bg_dot_gray)
                tvStatus.text = "Not connected"
                btnConnect.text = "Connect"
                btnOrb.setBackgroundResource(R.drawable.bg_orb_off)
                btnOrb.setColorFilter(ContextCompat.getColor(this, R.color.ink))
            }
        }
    }

    private fun updateStatus() {
        val s = SnakeVpnService
        val newState = when {
            s.running -> 2
            s.connecting -> 1
            else -> 0
        }
        if (newState != state) applyState(newState)

        val sel = Store.get(Store.selectedId)
        tvProfile.text = if (s.running) s.profileName else sel?.name ?: "Select a proxy below"
        val h = if (s.running) s.health else if (s.lastError.isEmpty()) "" else "Last error: ${s.lastError}"
        tvHealth.text = h
        tvHealth.setTextColor(
            when {
                h.startsWith("Proxy OK") -> Palette.ok(tvHealth)
                s.running -> Palette.warn(tvHealth)
                else -> Palette.bad(tvHealth)
            }
        )
        tvHealth.visibility = if (h.isEmpty()) View.GONE else View.VISIBLE
        tvUp.text = Fmt.speed(s.upSpeed)
        tvDown.text = Fmt.speed(s.downSpeed)
        tvTotal.text = "${Fmt.bytes(s.totalUp + s.totalDown)} used"
        tvUptime.text = if (s.running && s.startedAt > 0) Fmt.dur(System.currentTimeMillis() - s.startedAt) else "00:00:00"
        tvIp.text = if (s.running) s.exitIp.ifEmpty { "Detecting IP…" } else "Real IP visible"

        if (!s.running && !s.connecting && s.lastError.isNotEmpty() && s.lastError != shownError) {
            shownError = s.lastError
            MaterialAlertDialogBuilder(this)
                .setTitle("Connection failed")
                .setMessage(s.lastError)
                .setPositiveButton("OK", null)
                .setNeutralButton("View logs") { _, _ -> startActivity(Intent(this, LogActivity::class.java)) }
                .show()
        }

        if (adapter.activeId != s.profileId || adapter.selectedId != Store.selectedId) {
            adapter.activeId = s.profileId
            adapter.selectedId = Store.selectedId
            adapter.notifyDataSetChanged()
        }
    }

    // ---------------- list ----------------

    private fun refreshList() {
        adapter.items = Store.profiles()
        adapter.selectedId = Store.selectedId
        adapter.activeId = SnakeVpnService.profileId
        adapter.notifyDataSetChanged()
        emptyBox.visibility = if (adapter.items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun onSelect(p: ProxyProfile) {
        Store.selectedId = p.id
        refreshList()
        if (SnakeVpnService.running && SnakeVpnService.profileId != p.id) {
            toast("Switching to ${p.name}")
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
        }
    }

    private fun onLongPress(p: ProxyProfile, anchor: View) {
        val pm = PopupMenu(this, anchor, Gravity.END)
        pm.menu.add(0, 1, 0, "Test")
        pm.menu.add(0, 2, 1, "Edit")
        pm.menu.add(0, 3, 2, "Copy")
        pm.menu.add(0, 4, 3, "Delete")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> testOne(p)
                2 -> startActivity(Intent(this, EditProfileActivity::class.java).putExtra("id", p.id))
                3 -> {
                    val line = if (p.user.isEmpty()) "${p.host}:${p.port}" else "${p.host}:${p.port}:${p.user}:${p.pass}"
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("proxy", line))
                    toast("Copied")
                }
                4 -> MaterialAlertDialogBuilder(this)
                    .setTitle("Delete proxy?")
                    .setMessage(p.name)
                    .setPositiveButton("Delete") { _, _ -> Store.delete(p.id); refreshList() }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun testOne(p: ProxyProfile) {
        adapter.results[p.id] = ProfileAdapter.Res(0, "Testing…")
        adapter.notifyDataSetChanged()
        bg.execute {
            val r = ProxyTester.test(p)
            runOnUiThread {
                adapter.results[p.id] =
                    if (r.ok) ProfileAdapter.Res(1, "${r.ms} ms  ·  ${r.ip}")
                    else ProfileAdapter.Res(2, r.error)
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun testAll() {
        if (adapter.items.isEmpty()) { toast("No proxies to test"); return }
        adapter.items.forEach { testOne(it) }
    }

    private fun syncNow() {
        if (Store.subUrl.isBlank()) {
            toast("Add a subscription URL in Settings")
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        toast("Syncing…")
        bg.execute {
            val r = SubSync.sync()
            runOnUiThread {
                refreshList()
                toast(r.fold({ "$it proxies loaded" }, { "Sync failed: ${it.message}" }))
            }
        }
    }

    // ---------------- bulk import ----------------

    private fun showImport() {
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, (8 * d).toInt(), pad, 0)
        }
        box.addView(TextView(this).apply {
            text = "One proxy per line\nip:port:user:pass\nsocks5://user:pass@ip:port\nhttp://user:pass@ip:port"
            textSize = 12f
            setTextColor(ContextCompat.getColor(context, R.color.muted))
        })

        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundResource(R.drawable.bg_segment_track)
            setPadding((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
        }
        fun seg(t: String) = TextView(this).apply {
            text = t
            gravity = Gravity.CENTER
            textSize = 13f
            minHeight = (40 * d).toInt()
        }
        val sS = seg("SOCKS5")
        val sH = seg("HTTP")
        var type = "SOCKS5"
        track.addView(sS, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        track.addView(sH, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        styleSegments(0, sS, sH)
        sS.setOnClickListener { type = "SOCKS5"; styleSegments(0, sS, sH) }
        sH.setOnClickListener { type = "HTTP"; styleSegments(1, sS, sH) }
        box.addView(track, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (12 * d).toInt()
        })

        val et = EditText(this).apply {
            minLines = 5
            maxLines = 10
            gravity = Gravity.TOP
            hint = "Paste proxies here"
            textSize = 13f
            setBackgroundResource(R.drawable.bg_field)
            setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
        }
        try {
            val clip = getSystemService(ClipboardManager::class.java).primaryClip
            val t = clip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            if (ProxyParser.parseAll(t, "SOCKS5").isNotEmpty()) et.setText(t)
        } catch (ignored: Exception) {}
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (12 * d).toInt()
        })

        MaterialAlertDialogBuilder(this)
            .setTitle("Bulk import")
            .setView(box)
            .setPositiveButton("Import") { _, _ ->
                val list = ProxyParser.parseAll(et.text.toString(), type)
                if (list.isEmpty()) {
                    toast("No valid proxies found")
                } else {
                    Store.saveProfiles(Store.profiles() + list)
                    if (Store.get(Store.selectedId) == null) Store.selectedId = list.first().id
                    refreshList()
                    toast("Added ${list.size} proxies")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- leak test ----------------

    private fun leakTest() {
        val p = Store.get(Store.selectedId)
        if (p == null) { toast("Select a proxy first"); return }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("Leak test")
            .setMessage("Checking your connection…")
            .setPositiveButton("OK", null)
            .show()
        bg.execute {
            val real = ProxyTester.directIp()
            val r = ProxyTester.test(p)
            val msg = buildString {
                appendLine("Real IP:   $real")
                appendLine("Proxy IP:  " + if (r.ok) r.ip else "unreachable")
                appendLine()
                when {
                    !r.ok -> appendLine("The proxy is not working: ${r.error}")
                    r.ip == real -> appendLine("Warning: the proxy IP equals your real IP, so it does not hide you.")
                    else -> appendLine("The proxy changes your IP correctly.")
                }
                appendLine()
                if (SnakeVpnService.running) {
                    appendLine("Final check: open the browser tests. If they show the proxy IP and no DNS or IPv6 from your real country or carrier, there is no leak.")
                } else {
                    appendLine("Connect first, then run this test again for a full leak check.")
                }
            }
            runOnUiThread {
                if (!dlg.isShowing) return@runOnUiThread
                dlg.dismiss()
                val b = MaterialAlertDialogBuilder(this)
                    .setTitle("Leak test result")
                    .setMessage(msg)
                    .setNegativeButton("Close", null)
                if (SnakeVpnService.running) {
                    b.setPositiveButton("IP check") { _, _ -> openUrl("https://browserleaks.com/ip") }
                    b.setNeutralButton("DNS check") { _, _ -> openUrl("https://browserleaks.com/dns") }
                }
                b.show()
            }
        }
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (ignored: Exception) { toast("Could not open browser") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

class ProfileAdapter(
    private val onClick: (ProxyProfile) -> Unit,
    private val onLong: (ProxyProfile, View) -> Unit
) : RecyclerView.Adapter<ProfileAdapter.VH>() {

    /** state: 0 = testing, 1 = ok, 2 = failed */
    data class Res(val state: Int, val text: String)

    var items: List<ProxyProfile> = emptyList()
    var selectedId: String? = null
    var activeId: String? = null
    val results = HashMap<String, Res>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: LinearLayout = v.findViewById(R.id.itemCard)
        val tile: FrameLayout = v.findViewById(R.id.iconTile)
        val icon: ImageView = v.findViewById(R.id.ivIcon)
        val name: TextView = v.findViewById(R.id.tvName)
        val detail: TextView = v.findViewById(R.id.tvDetail)
        val result: TextView = v.findViewById(R.id.tvResult)
        val type: TextView = v.findViewById(R.id.tvType)
        val badge: TextView = v.findViewById(R.id.tvBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_profile, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        val ctx = h.itemView.context
        val ink = ContextCompat.getColor(ctx, R.color.ink)
        val mint = ContextCompat.getColor(ctx, R.color.mint)
        val mintDark = ContextCompat.getColor(ctx, R.color.mint_dark)
        val muted = ContextCompat.getColor(ctx, R.color.muted)
        val active = p.id == activeId
        val selected = p.id == selectedId

        h.name.text = p.name
        h.detail.text = "${p.host}:${p.port}" + if (p.user.isNotEmpty()) "  ·  auth" else ""
        h.type.text = if (p.type == "HTTP") "HTTP" else "SOCKS5"

        if (active) {
            h.card.setBackgroundResource(R.drawable.bg_card_active)
            h.card.elevation = 10 * ctx.resources.displayMetrics.density
            h.tile.setBackgroundResource(R.drawable.bg_icon_tile_glass)
            h.icon.setColorFilter(mint)
            h.name.setTextColor(Color.WHITE)
            h.detail.setTextColor(ContextCompat.getColor(ctx, R.color.white_70))
            h.type.setBackgroundResource(R.drawable.bg_pill_type_dark)
            h.type.setTextColor(Color.WHITE)
        } else {
            h.card.setBackgroundResource(if (selected) R.drawable.bg_card_selected else R.drawable.bg_card)
            h.card.elevation = 4 * ctx.resources.displayMetrics.density
            h.tile.setBackgroundResource(R.drawable.bg_icon_tile)
            h.icon.setColorFilter(ink)
            h.name.setTextColor(ink)
            h.detail.setTextColor(muted)
            h.type.setBackgroundResource(R.drawable.bg_pill_type)
            h.type.setTextColor(ink)
        }

        h.badge.visibility = if (active || selected) View.VISIBLE else View.GONE
        h.badge.text = if (active) "ACTIVE" else "SELECTED"
        h.badge.setTextColor(if (active) mint else mintDark)

        val r = results[p.id]
        if (r == null) {
            h.result.visibility = View.GONE
        } else {
            h.result.visibility = View.VISIBLE
            h.result.text = r.text
            h.result.setTextColor(
                when (r.state) {
                    1 -> if (active) mint else mintDark
                    2 -> ContextCompat.getColor(ctx, R.color.red)
                    else -> if (active) Color.WHITE else muted
                }
            )
        }
        h.card.setOnClickListener { onClick(p) }
        h.card.setOnLongClickListener { onLong(p, it); true }
    }
}
