package com.snake.proxy

import android.os.SystemClock
import org.json.JSONObject
import java.util.Locale

/** Every country in the world (ISO 3166), with English names. */
object Countries {
    data class C(val code: String, val name: String)

    val all: List<C> by lazy {
        Locale.getISOCountries()
            .map { C(it.uppercase(), Locale("", it).getDisplayCountry(Locale.ENGLISH)) }
            .filter { it.name.isNotBlank() && !it.name.equals(it.code, true) }
            .sortedBy { it.name }
    }

    fun name(code: String): String {
        if (code.isEmpty()) return "Auto"
        val n = Locale("", code.uppercase()).getDisplayCountry(Locale.ENGLISH)
        return if (n.isBlank()) code.uppercase() else n
    }
}

/** Recognises well-known proxy providers by host, for name + icon. */
object Providers {
    data class P(val name: String, val domain: String)

    private val known = listOf(
        "dataimpulse" to P("DataImpulse", "dataimpulse.com"),
        "9proxy" to P("9Proxy", "9proxy.com"),
        "abcproxy" to P("ABCProxy", "abcproxy.com"),
        "cliproxy" to P("Cliproxy", "cliproxy.com"),
        "oxylabs" to P("Oxylabs", "oxylabs.io"),
        "brightdata" to P("Bright Data", "brightdata.com"),
        "luminati" to P("Bright Data", "brightdata.com"),
        "smartproxy" to P("Smartproxy", "smartproxy.com"),
        "decodo" to P("Decodo", "decodo.com"),
        "iproyal" to P("IPRoyal", "iproyal.com"),
        "webshare" to P("Webshare", "webshare.io"),
        "soax" to P("SOAX", "soax.com"),
        "proxy-cheap" to P("Proxy-Cheap", "proxy-cheap.com"),
        "proxyseller" to P("Proxy-Seller", "proxy-seller.com"),
        "proxy-seller" to P("Proxy-Seller", "proxy-seller.com"),
        "922proxy" to P("922 Proxy", "922proxy.com"),
        "lunaproxy" to P("LunaProxy", "lunaproxy.com"),
        "pyproxy" to P("PYPROXY", "pyproxy.com"),
        "rapidproxy" to P("RapidProxy", "rapidproxy.io"),
        "bestproxy" to P("BestProxy", "bestproxy.com"),
        "proxyempire" to P("ProxyEmpire", "proxyempire.io"),
        "netnut" to P("NetNut", "netnut.io"),
        "packetstream" to P("PacketStream", "packetstream.io"),
    )

    private val ipRx = Regex("^[0-9.:\\[\\]]+$")

    fun rootDomain(host: String): String {
        val h = host.lowercase().trim().trimEnd('.')
        if (h.isEmpty() || ipRx.matches(h)) return ""
        val parts = h.split('.').filter { it.isNotEmpty() }
        if (parts.size <= 2) return h
        val sld = parts[parts.size - 2]
        return if (sld in setOf("co", "com", "net", "org", "gov", "ac", "edu") && parts.size >= 3)
            parts.takeLast(3).joinToString(".") else parts.takeLast(2).joinToString(".")
    }

    fun of(host: String): P {
        val h = host.lowercase()
        known.firstOrNull { h.contains(it.first) }?.let { return it.second }
        val root = rootDomain(host)
        if (root.isEmpty()) return P("Custom server", "")
        val label = root.substringBefore('.')
        return P(label.replaceFirstChar { it.uppercase() }, root)
    }

    fun iconUrl(host: String): String? {
        val d = of(host).domain
        return if (d.isEmpty()) null else "https://www.google.com/s2/favicons?domain=$d&sz=128"
    }
}

/**
 * Changes the country of rotating/residential proxies by editing the username,
 * the way each provider documents it:
 *   DataImpulse  login__cr.us
 *   ABCProxy     user-zone-abc-region-US
 *   Cliproxy     user-region-US
 *   9Proxy       user-country-us
 * plus common generic forms used by many other providers.
 */
object CountryRouting {
    private val patterns = listOf(
        Regex("(_{1,2}cr\\.)([A-Za-z]{2}(?:,[A-Za-z]{2})*)"),
        Regex("(-region-)([A-Za-z]{2})(?=$|-)"),
        Regex("(-country-)([A-Za-z]{2})(?=$|-)"),
        Regex("(_country-)([A-Za-z]{2})(?=$|_)"),
        Regex("(-cc-)([A-Za-z]{2})(?=$|-)"),
        Regex("(country-)([A-Za-z]{2})(?=$|[-_])")
    )

    /** (text to append before the code, upper-case code?) for providers we know. */
    private fun suffixFor(p: ProxyProfile): Pair<String, Boolean>? {
        val h = p.host.lowercase()
        return when {
            h.contains("dataimpulse") -> Pair("__cr.", false)
            h.contains("abcproxy") -> Pair(if (p.user.contains("-zone-")) "-region-" else "-zone-abc-region-", true)
            h.contains("cliproxy") -> Pair("-region-", true)
            h.contains("9proxy") -> Pair("-country-", false)
            else -> null
        }
    }

    /** True when this proxy's country can be changed from the app. */
    fun canTarget(p: ProxyProfile): Boolean =
        p.user.isNotEmpty() && (patterns.any { it.containsMatchIn(p.user) } || suffixFor(p) != null)

    /** Country currently written in the username, or "" if none. */
    fun currentCountry(p: ProxyProfile): String {
        for (rx in patterns) {
            val m = rx.find(p.user) ?: continue
            return m.groupValues[2].substringBefore(',').uppercase()
        }
        return ""
    }

    /** Profile with [cc] applied, the same profile for "" (auto), or null if not possible. */
    fun apply(p: ProxyProfile, cc: String): ProxyProfile? {
        if (cc.isEmpty()) return p
        if (p.user.isEmpty()) return null
        for (rx in patterns) {
            val m = rx.find(p.user) ?: continue
            val group = m.groups[2] ?: continue
            val old = group.value
            val code = if (old.first().isUpperCase()) cc.uppercase() else cc.lowercase()
            return p.copy(user = p.user.replaceRange(group.range, code))
        }
        val suffix = suffixFor(p) ?: return null
        val code = if (suffix.second) cc.uppercase() else cc.lowercase()
        return p.copy(user = p.user + suffix.first + code)
    }
}

/** Exit IP + location seen through a proxy. */
data class GeoInfo(
    val ok: Boolean,
    val ip: String = "",
    val cc: String = "",
    val country: String = "",
    val city: String = "",
    val isp: String = "",
    val ms: Long = 0,
    val error: String = ""
)

object GeoCheck {
    fun through(p: ProxyProfile): GeoInfo {
        val t0 = SystemClock.elapsedRealtime()
        try {
            ProxyDialer.open(p, "ip-api.com", 80, 10000).use { s ->
                val ms = SystemClock.elapsedRealtime() - t0
                s.soTimeout = 12000
                s.getOutputStream().write(
                    ("GET /json/?fields=status,message,country,countryCode,city,isp,query HTTP/1.0\r\n" +
                        "Host: ip-api.com\r\nUser-Agent: FleetProxy\r\nConnection: close\r\n\r\n").toByteArray()
                )
                val resp = s.getInputStream().readBytes().toString(Charsets.UTF_8)
                val start = resp.indexOf('{')
                if (start >= 0) {
                    val o = JSONObject(resp.substring(start))
                    if (o.optString("status") == "success") {
                        return GeoInfo(
                            true, o.optString("query"), o.optString("countryCode").uppercase(),
                            o.optString("country"), o.optString("city"), o.optString("isp"), ms
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // fall back to a plain IP check below
            val r = ProxyTester.test(p)
            return if (r.ok) GeoInfo(true, r.ip, ms = r.ms) else GeoInfo(false, error = r.error.ifEmpty { e.message ?: "Proxy unreachable" })
        }
        val r = ProxyTester.test(p)
        return if (r.ok) GeoInfo(true, r.ip, ms = r.ms) else GeoInfo(false, error = r.error)
    }
}
