package com.snake.proxy

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.VpnService
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

/** Get started screens shown the first time the app opens. */
class OnboardingActivity : AppCompatActivity() {

    private data class Slide(val title: String, val desc: String, val ill: Int)

    private val slides = listOf(
        Slide("Bring your own proxy", "Paste or import SOCKS5 / HTTP proxies. Fleet Proxy detects the provider and tests them for you.", R.layout.onb_ill_proxy),
        Slide("Switch country\nin one tap", "Change location instantly and see your live exit IP, city and speed.", R.layout.onb_ill_country),
        Slide("Every app,\nfully protected", "IPv4, IPv6 and DNS go through your proxy. Kill switch and failover keep you safe.", R.layout.onb_ill_apps),
        Slide("You're in control", "Choose which apps use the proxy and watch every connection live.", R.layout.onb_ill_control)
    )
    private val pageCount get() = slides.size + 1

    private lateinit var pager: ViewPager2
    private lateinit var btnNext: TextView
    private lateinit var btnSkip: View
    private lateinit var tvImport: TextView
    private lateinit var dots: LinearLayout
    private var appIcons: List<Pair<String, Drawable>> = emptyList()

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        finishOnboarding(null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)
        appIcons = loadAppIcons()

        pager = findViewById(R.id.pager)
        btnNext = findViewById(R.id.btnNext)
        btnSkip = findViewById(R.id.btnSkip)
        tvImport = findViewById(R.id.tvImport)
        dots = findViewById(R.id.dots)

        tvImport.text = android.text.Html.fromHtml(
            "Already have a proxy list? <font color='#2F8CF5'><b>Import</b></font>", android.text.Html.FROM_HTML_MODE_LEGACY
        )
        tvImport.setOnClickListener { finishOnboarding("import") }
        btnSkip.setOnClickListener { finishOnboarding(null) }
        btnNext.setOnClickListener {
            val i = pager.currentItem
            if (i < pageCount - 1) pager.currentItem = i + 1
            else {
                val req = VpnService.prepare(this)
                if (req != null) vpnPermission.launch(req) else finishOnboarding(null)
            }
        }

        pager.adapter = PageAdapter()
        pager.offscreenPageLimit = 1
        pager.setPageTransformer { page, pos ->
            page.alpha = 1f - abs(pos) * 0.7f
            val s = 1f - abs(pos) * 0.08f
            page.scaleX = s
            page.scaleY = s
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateChrome(position)
        })
        buildDots()
        updateChrome(0)
        Motion.pressable(findViewById(android.R.id.content))
    }

    private fun buildDots() {
        dots.removeAllViews()
        val d = resources.displayMetrics.density
        repeat(pageCount) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams((8 * d).toInt(), (8 * d).toInt())
            lp.marginStart = (3.5f * d).toInt(); lp.marginEnd = (3.5f * d).toInt()
            v.layoutParams = lp
            dots.addView(v)
        }
    }

    private fun updateChrome(pos: Int) {
        val d = resources.displayMetrics.density
        for (i in 0 until dots.childCount) {
            val v = dots.getChildAt(i)
            val on = i == pos
            v.setBackgroundResource(if (on) R.drawable.bg_dot_on else R.drawable.bg_dot_off)
            v.layoutParams = (v.layoutParams as LinearLayout.LayoutParams).apply { width = ((if (on) 26 else 8) * d).toInt() }
        }
        dots.visibility = if (pos == 0) View.INVISIBLE else View.VISIBLE
        tvImport.visibility = if (pos == 0) View.VISIBLE else View.INVISIBLE
        btnSkip.visibility = if (pos == 0 || pos == pageCount - 1) View.INVISIBLE else View.VISIBLE
        btnNext.text = when (pos) {
            0 -> "Get started"
            pageCount - 1 -> "Allow VPN & start"
            else -> "Continue"
        }
    }

    private fun finishOnboarding(extra: String?) {
        Store.onboarded = true
        val i = Intent(this, MainActivity::class.java)
        if (extra != null) i.putExtra("onboard_action", extra)
        else if (Store.profiles().isEmpty()) i.putExtra("onboard_action", "add")
        startActivity(i)
        finish()
    }

    /** Real icons of internet apps installed on this phone, popular ones first. */
    private fun loadAppIcons(): List<Pair<String, Drawable>> {
        val pm = packageManager
        val preferred = listOf(
            "com.whatsapp", "com.android.chrome", "org.telegram.messenger", "com.google.android.youtube",
            "com.facebook.katana", "com.instagram.android", "com.facebook.orca", "com.zhiliaoapp.musically",
            "com.twitter.android", "com.google.android.gm", "com.snapchat.android", "com.spotify.music"
        )
        val out = ArrayList<Pair<String, Drawable>>()
        for (p in preferred) {
            try {
                val ai = pm.getApplicationInfo(p, 0)
                out += pm.getApplicationLabel(ai).toString() to pm.getApplicationIcon(ai)
            } catch (ignored: PackageManager.NameNotFoundException) {}
            if (out.size >= 6) return out
        }
        try {
            val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            for (ri in pm.queryIntentActivities(launch, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || out.any { it.first == ri.loadLabel(pm).toString() }) continue
                out += ri.loadLabel(pm).toString() to ri.loadIcon(pm)
                if (out.size >= 6) break
            }
        } catch (ignored: Exception) {}
        return out
    }

    private inner class PageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = pageCount
        override fun getItemViewType(position: Int) = position

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inf = LayoutInflater.from(parent.context)
            val v: View = if (viewType == 0) {
                inf.inflate(R.layout.page_onb_welcome, parent, false).also { w ->
                    val logo = w.findViewById<View>(R.id.ivLogo)
                    logo.scaleX = 0.8f; logo.scaleY = 0.8f; logo.alpha = 0f
                    logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(150).setDuration(700)
                        .setInterpolator(DecelerateInterpolator(2f)).start()
                }
            } else {
                val s = slides[viewType - 1]
                inf.inflate(R.layout.page_onb_slide, parent, false).also { p ->
                    p.findViewById<TextView>(R.id.tvTitle).text = s.title
                    p.findViewById<TextView>(R.id.tvDesc).text = s.desc
                    val box = p.findViewById<FrameLayout>(R.id.illus)
                    val ill = inf.inflate(s.ill, box, false)
                    (ill.layoutParams as FrameLayout.LayoutParams).gravity = android.view.Gravity.CENTER
                    box.addView(ill)
                    fillIllustration(s.ill, ill)
                }
            }
            v.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            return object : RecyclerView.ViewHolder(v) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {}
    }

    private fun fillIllustration(layout: Int, v: View) {
        when (layout) {
            R.layout.onb_ill_country -> {
                val orbit = v.findViewById<ViewGroup>(R.id.orbit)
                val d = resources.displayMetrics.density
                for (i in 0 until orbit.childCount) {
                    val c = orbit.getChildAt(i)
                    val cc = c.tag as? String ?: continue
                    if (c is ViewGroup && c.childCount == 2) bindFlag(c.getChildAt(0) as TextView, c.getChildAt(1) as ImageView, cc)
                    Fx.spin(c, 24000, reverse = true)   // keeps each flag upright while the ring turns
                }
                Fx.spin(orbit, 24000)
                Fx.bob(v.findViewById(R.id.earth), 6 * d, 2000)
                val glow = v.findViewById<View>(R.id.earthGlow)
                Fx.breathe(glow, 0.55f, 1f, 1500)
                Fx.pulse(glow, 1.08f, 1500)
            }
            R.layout.onb_ill_apps -> {
                val box = v as ViewGroup
                var k = 0
                for (i in 0 until box.childCount) {
                    val c = box.getChildAt(i)
                    if (c.tag == "app" && c is ImageView) {
                        val icon = appIcons.getOrNull(k++)
                        if (icon != null) c.setImageDrawable(icon.second) else c.visibility = View.GONE
                    }
                }
            }
            R.layout.onb_ill_control -> {
                val rows = v.findViewById<LinearLayout>(R.id.ctrlRows)
                val d = resources.displayMetrics.density
                appIcons.take(4).forEachIndexed { i, (label, icon) ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = android.view.Gravity.CENTER_VERTICAL
                        setPadding(0, (8 * d).toInt(), 0, (8 * d).toInt())
                    }
                    row.addView(ImageView(this).apply {
                        setImageDrawable(icon)
                        layoutParams = LinearLayout.LayoutParams((32 * d).toInt(), (32 * d).toInt())
                    })
                    row.addView(TextView(this).apply {
                        text = label
                        setTextColor(androidx.core.content.ContextCompat.getColor(context, R.color.text))
                        textSize = 13.5f
                        typeface = androidx.core.content.res.ResourcesCompat.getFont(context, R.font.poppins_medium)
                        maxLines = 1
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = (12 * d).toInt() }
                    })
                    row.addView(ToggleView(this).apply { setCheckedNow(i != 2); isClickable = false })
                    rows.addView(row)
                }
            }
        }
    }
}
