package com.snake.proxy

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.concurrent.Executors

/** One connection made through the proxy. */
data class ConnEvent(
    val time: Long,
    val pkg: String?,
    val host: String,
    val port: Int,
    val ok: Boolean,
    val ms: Long,
    val error: String
)

object ConnLog {
    private val list = ArrayDeque<ConnEvent>()
    @Volatile var version = 0
        private set

    @Synchronized
    fun add(e: ConnEvent) {
        list.addFirst(e)
        while (list.size > 600) list.removeLast()
        version++
    }

    @Synchronized
    fun snapshot(): List<ConnEvent> = list.toList()

    @Synchronized
    fun clear() {
        list.clear()
        version++
    }
}

/**
 * Which app is on screen right now. Needs "Usage access" (the user grants it once in
 * Settings). Connections are tagged with the app the user is currently using.
 */
object Foreground {
    @Volatile var pkg: String? = null
        private set

    fun hasPermission(ctx: Context): Boolean = try {
        val aom = ctx.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            aom.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            aom.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) {
        false
    }

    @Suppress("DEPRECATION")
    fun refresh(ctx: Context) {
        if (!hasPermission(ctx)) { pkg = null; return }
        try {
            val usm = ctx.getSystemService(UsageStatsManager::class.java)
            val end = System.currentTimeMillis()
            val events = usm.queryEvents(end - 15_000, end)
            val e = UsageEvents.Event()
            var last: String? = null
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
            }
            if (last != null) pkg = if (last == ctx.packageName) null else last
        } catch (ignored: Exception) {}
    }

    /** Best guess of the app that owns a new connection. */
    fun current(): String? {
        if (Store.appMode == Store.MODE_ONLY) {
            val only = Store.apps
            if (only.size == 1) return only.first()
        }
        return pkg
    }
}

/** App label + icon lookups with a small cache. */
object AppInfo {
    private val labels = HashMap<String, String>()
    private val icons = HashMap<String, Drawable?>()

    @Synchronized
    fun label(ctx: Context, pkg: String): String = labels.getOrPut(pkg) {
        try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            pkg
        }
    }

    @Synchronized
    fun icon(ctx: Context, pkg: String): Drawable? = icons.getOrPut(pkg) {
        try { ctx.packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
    }
}

/** Tiny image loader with memory + disk cache, for country flags and provider icons. */
object Img {
    private val mem = LruCache<String, Bitmap>(300)
    private val pool = Executors.newFixedThreadPool(4)
    private val failed: MutableSet<String> = Collections.synchronizedSet(HashSet())
    private val main = Handler(Looper.getMainLooper())

    /** Round, flat flags (circle-flags, MIT) like premium VPN apps; PNG flag as fallback. */
    fun flagUrl(cc: String) = "https://hatscripts.github.io/circle-flags/flags/${cc.lowercase()}.svg"
    fun flagFallback(cc: String) = "https://cdn.jsdelivr.net/gh/HatScripts/circle-flags@gh-pages/flags/${cc.lowercase()}.svg"

    /**
     * Shows the image when ready; until then (or on failure) the view is left empty.
     * [done] tells the caller whether an image is now shown (to hide placeholder text).
     */
    fun load(iv: ImageView, url: String?, done: ((Boolean) -> Unit)? = null, fallback: String? = null) {
        iv.tag = url
        if (url == null) { iv.setImageDrawable(null); done?.invoke(false); return }
        val hit = mem.get(url)
        if (hit != null) { iv.setImageBitmap(hit); done?.invoke(true); return }
        iv.setImageDrawable(null)
        done?.invoke(false)
        if (url in failed) { if (fallback != null) load(iv, fallback, done); return }
        pool.execute {
            val bmp = try { fromDisk(url) ?: download(url) } catch (e: Throwable) { null }
            main.post {
                if (bmp == null) {
                    failed.add(url)
                    if (fallback != null && iv.tag == url) load(iv, fallback, done)
                } else {
                    mem.put(url, bmp)
                    if (iv.tag == url) {
                        iv.alpha = 0f
                        iv.setImageBitmap(bmp)
                        iv.animate().alpha(1f).setDuration(220).start()
                        done?.invoke(true)
                    }
                }
            }
        }
    }

    private fun file(url: String): File {
        val dir = File(Store.appContext.cacheDir, "img")
        dir.mkdirs()
        return File(dir, Integer.toHexString(url.hashCode()) + ".png")
    }

    private fun fromDisk(url: String): Bitmap? {
        val f = file(url)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    private fun download(url: String): Bitmap? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "FleetProxy")
        val bytes = c.inputStream.use { it.readBytes() }
        if (url.endsWith(".svg")) {
            val svg = com.caverock.androidsvg.SVG.getFromString(String(bytes))
            val size = 160
            svg.setDocumentWidth(size.toFloat())
            svg.setDocumentHeight(size.toFloat())
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            svg.renderToCanvas(android.graphics.Canvas(out))
            try { file(url).outputStream().use { o -> out.compress(Bitmap.CompressFormat.PNG, 100, o) } } catch (ignored: Exception) {}
            return out
        }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        if (bmp.width < 8) return null
        try { file(url).writeBytes(bytes) } catch (ignored: Exception) {}
        return bmp
    }
}
