package com.snake.proxy

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.VideoView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

/** Full-screen "Under maintenance" (or "blocked") page driven by the admin panel. */
class MaintenanceActivity : AppCompatActivity() {
    companion object {
        var open = false
        fun open(a: Activity, blocked: Boolean) {
            if (open) return
            open = true
            a.startActivity(Intent(a, MaintenanceActivity::class.java).putExtra("blocked", blocked)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
            a.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maintenance)
        bind(Remote.cfg)
        findViewById<View>(R.id.mtRetry).setOnClickListener { v ->
            v.isEnabled = false
            findViewById<TextView>(R.id.mtRetryText).text = "Checking…"
            Remote.fetch(this, 0) { c ->
                v.isEnabled = true
                findViewById<TextView>(R.id.mtRetryText).text = "Try again"
                val stillClosed = c.optBoolean("blocked") || c.optJSONObject("maintenance")?.optBoolean("on") == true
                if (!stillClosed) finish() else bind(c)
            }
        }
        findViewById<View>(R.id.mtSupport).setOnClickListener { Remote.open(this, Remote.link("support").ifBlank { Remote.link("telegram") }) }
        Fx.pulse(findViewById(R.id.mtIcon), 1.08f, 1100)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finishAffinity() }
        })
    }

    private fun bind(c: JSONObject) {
        val blocked = c.optBoolean("blocked") || intent.getBooleanExtra("blocked", false) && !c.has("blocked")
        val m = c.optJSONObject("maintenance") ?: JSONObject()
        val title = findViewById<TextView>(R.id.mtTitle)
        val msg = findViewById<TextView>(R.id.mtMsg)
        val bar = findViewById<ProgressBar>(R.id.mtProgress)
        val eta = findViewById<TextView>(R.id.mtEta)
        val hasSupport = Remote.link("support").isNotBlank() || Remote.link("telegram").isNotBlank()
        findViewById<View>(R.id.mtSupport).visibility = if (hasSupport) View.VISIBLE else View.GONE
        timer?.cancel()
        if (blocked) {
            title.text = "Access blocked"
            msg.text = "This device has been blocked. Contact support if you think this is a mistake."
            bar.visibility = View.GONE; eta.visibility = View.GONE
            return
        }
        title.text = m.optString("title").ifBlank { "Under maintenance" }
        msg.text = m.optString("message").ifBlank { "We are upgrading our servers. Please try again in a little while." }
        val since = m.optLong("since") * 1000
        val until = m.optLong("until") * 1000
        if (until > since && since > 0) {
            bar.visibility = View.VISIBLE; eta.visibility = View.VISIBLE
            timer = object : CountDownTimer(86_400_000L, 1000) {
                override fun onTick(ms: Long) {
                    val now = System.currentTimeMillis()
                    bar.progress = (((now - since).toDouble() / (until - since)) * 1000).toInt().coerceIn(0, 1000)
                    val left = (until - now) / 60_000
                    eta.text = if (until > now) "Back in ~${left + 1} min" else "Almost done… tap Try again"
                }
                override fun onFinish() {}
            }.start()
        } else { bar.visibility = View.GONE; eta.visibility = View.GONE }
    }

    override fun onDestroy() { timer?.cancel(); open = false; super.onDestroy() }
}

/** Own (admin-uploaded) full-screen photo / video ad with skip countdown. */
class AdActivity : AppCompatActivity() {
    companion object {
        fun intent(ctx: Context, ad: JSONObject): Intent = Intent(ctx, AdActivity::class.java)
            .putExtra("id", ad.optString("id")).putExtra("type", ad.optString("type"))
            .putExtra("url", ad.optString("url")).putExtra("link", ad.optString("link"))
            .putExtra("secs", ad.optInt("secs", 15)).putExtra("skip", ad.optInt("skip", 5))
    }

    private var canClose = false
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_ad)
        val id = intent.getStringExtra("id") ?: ""
        val url = intent.getStringExtra("url") ?: ""
        val link = intent.getStringExtra("link") ?: ""
        val secs = intent.getIntExtra("secs", 15).coerceAtLeast(3)
        val skip = intent.getIntExtra("skip", 5).coerceIn(0, secs)

        val img = findViewById<ImageView>(R.id.adImage)
        val vid = findViewById<VideoView>(R.id.adVideo)
        if (intent.getStringExtra("type") == "video") {
            img.visibility = View.GONE
            vid.visibility = View.VISIBLE
            vid.setVideoURI(Uri.parse(url))
            vid.setOnPreparedListener { it.isLooping = true; vid.start() }
            vid.setOnErrorListener { _, _, _ -> canClose = true; showClose(); true }
        } else {
            vid.visibility = View.GONE
            Img.load(img, url)
        }

        val visit = findViewById<View>(R.id.adVisit)
        visit.visibility = if (link.isNotBlank()) View.VISIBLE else View.GONE
        visit.setOnClickListener { Remote.event(this, "click", "own", id); Remote.open(this, link) }

        val bar = findViewById<View>(R.id.adBar)
        bar.pivotX = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = secs * 1000L
            interpolator = LinearInterpolator()
            addUpdateListener { bar.scaleX = it.animatedValue as Float }
            start()
        }
        val skipText = findViewById<TextView>(R.id.adSkipText)
        findViewById<View>(R.id.adSkip).setOnClickListener { if (canClose) finish() }
        timer = object : CountDownTimer(secs * 1000L, 250) {
            override fun onTick(ms: Long) {
                val passed = secs - (ms / 1000).toInt() - 1
                val left = skip - passed
                if (left > 0) skipText.text = "Skip in $left" else { canClose = true; showClose() }
            }
            override fun onFinish() { finish() }
        }.start()
        if (skip == 0) { canClose = true; showClose() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (canClose) finish() }
        })
    }

    private fun showClose() {
        findViewById<TextView>(R.id.adSkipText).text = "Skip"
        findViewById<View>(R.id.adSkipX).visibility = View.VISIBLE
    }

    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
}
