package com.snake.proxy

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Store.applyTheme()
        Remote.init(this)
        Ads.init(this)
    }
}

data class ProxyProfile(
    val id: String,
    var name: String,
    var type: String,          // "SOCKS5" or "HTTP"
    var host: String,
    var port: Int,
    var user: String = "",
    var pass: String = "",
    var fromSub: Boolean = false
) {
    val detail: String get() = "$type  $host:$port" + if (user.isNotEmpty()) "  · auth" else ""

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("type", type)
        .put("host", host).put("port", port)
        .put("user", user).put("pass", pass).put("sub", fromSub)

    companion object {
        fun newId(): String = UUID.randomUUID().toString()
        fun fromJson(o: JSONObject) = ProxyProfile(
            o.getString("id"), o.optString("name"), o.optString("type", "SOCKS5"),
            o.optString("host"), o.optInt("port"), o.optString("user"), o.optString("pass"),
            o.optBoolean("sub", false)
        )
    }
}

object Store {
    private lateinit var sp: SharedPreferences
    lateinit var appContext: Context
        private set

    const val MODE_ALL = 0
    const val MODE_ONLY = 1
    const val MODE_EXCLUDE = 2

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        appContext = ctx.applicationContext
        sp = appContext.getSharedPreferences("snake", Context.MODE_PRIVATE)
    }

    private var cacheRaw: String? = null
    private var cacheList: List<ProxyProfile> = emptyList()

    /** Saved proxies (stored encrypted with a key that never leaves the phone's keystore). */
    @Synchronized
    fun profiles(): MutableList<ProxyProfile> {
        val raw = sp.getString("profiles", "[]") ?: "[]"
        if (raw != cacheRaw) {
            val json = if (raw.startsWith(Vault.PREFIX)) (Vault.open(raw) ?: "[]") else raw
            val arr = try { JSONArray(json) } catch (e: Exception) { JSONArray() }
            cacheList = List(arr.length()) { ProxyProfile.fromJson(arr.getJSONObject(it)) }
            cacheRaw = raw
            if (!raw.startsWith(Vault.PREFIX) && arr.length() > 0) saveProfiles(cacheList)   // migrate old plain data
        }
        return cacheList.map { it.copy() }.toMutableList()
    }

    @Synchronized
    fun saveProfiles(list: List<ProxyProfile>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        val plain = arr.toString()
        val stored = Vault.seal(plain) ?: plain
        sp.edit().putString("profiles", stored).apply()
        cacheRaw = stored
        cacheList = list.map { it.copy() }
    }

    fun get(id: String?): ProxyProfile? = if (id == null) null else profiles().firstOrNull { it.id == id }

    @Synchronized
    fun upsert(p: ProxyProfile) {
        val list = profiles()
        val i = list.indexOfFirst { it.id == p.id }
        if (i >= 0) list[i] = p else list.add(p)
        saveProfiles(list)
    }

    @Synchronized
    fun delete(id: String) {
        saveProfiles(profiles().filter { it.id != id })
        if (selectedId == id) selectedId = null
    }

    var selectedId: String?
        get() = sp.getString("selected", null)
        set(v) = sp.edit().putString("selected", v).apply()

    var appMode: Int
        get() = sp.getInt("appMode", MODE_ALL)
        set(v) = sp.edit().putInt("appMode", v).apply()

    var apps: Set<String>
        get() = sp.getStringSet("apps", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("apps", v).apply()

    var subUrl: String
        get() = sp.getString("subUrl", "")!!
        set(v) = sp.edit().putString("subUrl", v).apply()

    var autoSync: Boolean
        get() = sp.getBoolean("autoSync", true)
        set(v) = sp.edit().putBoolean("autoSync", v).apply()

    var autoFailover: Boolean
        get() = sp.getBoolean("autoFailover", true)
        set(v) = sp.edit().putBoolean("autoFailover", v).apply()

    /** True once the Get started screens were completed or skipped. */
    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) = sp.edit().putBoolean("onboarded", v).apply()

    /** Selected exit country (ISO code), "" = proxy default. */
    var country: String
        get() = sp.getString("country", "")!!
        set(v) = sp.edit().putString("country", v).apply()

    var recentCountries: List<String>
        get() = sp.getString("recent", "")!!.split(',').filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("recent", v.take(6).joinToString(",")).apply()

    fun pushRecent(cc: String) {
        if (cc.isEmpty()) return
        recentCountries = listOf(cc) + recentCountries.filter { it != cc }
    }

    /** 0 = follow system, 1 = light, 2 = dark */
    var themeMode: Int
        get() = sp.getInt("theme", 1)
        set(v) = sp.edit().putInt("theme", v).apply()

    fun applyTheme() {
        AppCompatDelegate.setDefaultNightMode(
            when (themeMode) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    var debugLog: Boolean
        get() = sp.getBoolean("debugLog", false)
        set(v) = sp.edit().putBoolean("debugLog", v).apply()
}

/** Parses proxy text into profiles. Supported formats:
 *  ip:port   ip:port:user:pass   user:pass@ip:port
 *  socks5://user:pass@ip:port   http://user:pass@ip:port */
object ProxyParser {
    private val schemeRx = Regex("^(socks5h?|socks4?|https?)://", RegexOption.IGNORE_CASE)

    fun parseLine(raw: String, defType: String): ProxyProfile? {
        var s = raw.trim()
        if (s.isEmpty() || s.startsWith("#") || s.startsWith("//")) return null
        var type = defType
        var hadScheme = false
        schemeRx.find(s)?.let {
            type = if (it.value.lowercase().startsWith("http")) "HTTP" else "SOCKS5"
            s = s.substring(it.value.length)
            hadScheme = true
        }
        s = s.substringBefore("#").substringBefore("/").trim()

        var user = ""
        var pass = ""
        var hostPort = s
        if (s.contains("@")) {
            val cred = s.substringBeforeLast("@")
            hostPort = s.substringAfterLast("@")
            user = cred.substringBefore(":")
            pass = cred.substringAfter(":", "")
            if (hadScheme) {
                user = dec(user); pass = dec(pass)
            }
        } else if (!s.startsWith("[")) {
            val parts = s.split(":")
            if (parts.size >= 4) {
                hostPort = parts[0] + ":" + parts[1]
                user = parts[2]
                pass = parts.drop(3).joinToString(":")
            }
        }
        val host = hostPort.substringBeforeLast(":").trim().trim('[', ']')
        val port = hostPort.substringAfterLast(":").trim().toIntOrNull() ?: return null
        if (host.isBlank() || port !in 1..65535) return null
        return ProxyProfile(ProxyProfile.newId(), "$host:$port", type, host, port, user, pass)
    }

    // a proxy written anywhere inside a line (after labels / emojis like "📋 Full IP: …")
    private val hostRx = """(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}|\d{1,3}(?:\.\d{1,3}){3}"""
    private val tokenRx = Regex(
        """(?:(?:socks5h?|socks4|https?)://\S+)""" +                                  // scheme://…
        """|(?:[^\s@:/]+:[^\s@]*@(?:$hostRx):\d{1,5})""" +                            // user:pass@host:port
        """|(?:[^\s:]+:[^\s:]+:(?:$hostRx):\d{1,5}(?![\d.]))""" +                     // user:pass:host:port
        """|(?:(?:$hostRx):\d{1,5}(?::[^\s:]+:\S+)?)""", RegexOption.IGNORE_CASE)     // host:port[:user:pass]
    private val labelRx = Regex("""^[^A-Za-z0-9]*([A-Za-z][A-Za-z /_-]{0,20}?)\s*[:=：]\s*(.+)$""")

    /** Reads every proxy in any text: plain lists, URLs, or bot messages with Server / Port / Username / Password lines. */
    fun parseAll(text: String, defType: String): List<ProxyProfile> {
        val out = LinkedHashMap<String, ProxyProfile>()
        val type = typeHint(text) ?: defType
        for (line in text.lines()) {
            val token = tokenRx.find(line)?.value ?: continue
            val p = parseLine(fixOrder(token), type) ?: continue
            out.putIfAbsent("${p.host}:${p.port}:${p.user}", p)
        }
        if (out.isEmpty()) parseLabeled(text, type)?.let { out["${it.host}:${it.port}:${it.user}"] = it }
        return out.values.toList()
    }

    /** "Server: x / Port: y / Username: u / Password: p" style messages. */
    private fun parseLabeled(text: String, type: String): ProxyProfile? {
        var host = ""; var port = 0; var user = ""; var pass = ""
        for (line in text.lines()) {
            val m = labelRx.find(line.trim()) ?: continue
            val k = m.groupValues[1].lowercase().trim()
            val v = m.groupValues[2].trim().trim('`', '"', '\'')
            when {
                k in listOf("server", "host", "hostname", "ip", "address", "proxy host", "gateway", "endpoint") && host.isEmpty() -> {
                    host = v.substringBefore(" ")
                    if (host.count { it == ':' } == 1) { port = host.substringAfter(":").toIntOrNull() ?: port; host = host.substringBefore(":") }
                }
                k == "port" || k.endsWith(" port") -> port = v.filter { it.isDigit() }.toIntOrNull() ?: port
                k in listOf("username", "user", "login", "user name") -> user = v.substringBefore(" ")
                k in listOf("password", "pass", "pwd") -> pass = v.substringBefore(" ")
            }
        }
        if (host.isBlank() || port !in 1..65535) return null
        return ProxyProfile(ProxyProfile.newId(), "$host:$port", type, host, port, user, pass)
    }

    /** user:pass:host:port → host:port:user:pass */
    private fun fixOrder(t: String): String {
        if (t.contains("://") || t.contains("@")) return t
        val parts = t.split(":")
        if (parts.size == 4 && parts[3].toIntOrNull() != null && parts[1].toIntOrNull() == null &&
            Regex("^(?:$hostRx)$", RegexOption.IGNORE_CASE).matches(parts[2])) {
            return "${parts[2]}:${parts[3]}:${parts[0]}:${parts[1]}"
        }
        return t
    }

    /** "Type: HTTP" / "Protocol: SOCKS5" in a message picks the type. */
    private fun typeHint(text: String): String? {
        val m = Regex("""(?im)^\W*(?:type|protocol|proxy type)\s*[:=]\s*(socks5|socks|https?)""").find(text) ?: return null
        return if (m.groupValues[1].lowercase().startsWith("http")) "HTTP" else "SOCKS5"
    }

    private fun dec(x: String) = try { URLDecoder.decode(x, "UTF-8") } catch (e: Exception) { x }
}

/** AES-GCM with a non-exportable Android Keystore key: other apps / file viewers only see random bytes. */
object Vault {
    const val PREFIX = "v1:"
    private const val ALIAS = "fp_vault"

    private fun key(): javax.crypto.SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(ALIAS, null) as? java.security.KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val g = javax.crypto.KeyGenerator.getInstance(android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            android.security.keystore.KeyGenParameterSpec.Builder(ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    fun seal(plain: String): String? = try {
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        c.init(javax.crypto.Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        PREFIX + android.util.Base64.encodeToString(out, android.util.Base64.NO_WRAP)
    } catch (e: Throwable) { null }

    fun open(sealed: String): String? = try {
        val b = android.util.Base64.decode(sealed.removePrefix(PREFIX), android.util.Base64.NO_WRAP)
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        c.init(javax.crypto.Cipher.DECRYPT_MODE, key(), javax.crypto.spec.GCMParameterSpec(128, b, 0, 12))
        String(c.doFinal(b, 12, b.size - 12), Charsets.UTF_8)
    } catch (e: Throwable) { null }
}

object AppLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(msg: String) {
        lines.addLast("[${fmt.format(Date())}] $msg")
        while (lines.size > 500) lines.removeFirst()
    }

    @Synchronized
    fun dump(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() = lines.clear()
}

object Fmt {
    fun bytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.2f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun speed(b: Long) = bytes(b) + "/s"

    fun dur(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }
}
