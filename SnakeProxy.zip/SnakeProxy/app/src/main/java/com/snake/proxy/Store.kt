package com.snake.proxy

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}

data class ProxyProfile(
    val id: String,
    var name: String,
    var type: String,          // "SOCKS5" বা "HTTP"
    var host: String,
    var port: Int,
    var user: String = "",
    var pass: String = "",
    var fromSub: Boolean = false
) {
    val detail: String get() = "$type  $host:$port" + if (user.isNotEmpty()) "  (লগইন সহ)" else ""

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("type", type)
        .put("host", host).put("port", port)
        .put("user", user).put("pass", pass).put("sub", fromSub)

    companion object {
        fun newId(): String = UUID.randomUUID().toString()
        fun fromJson(o: JSONObject) = ProxyProfile(
            o.getString("id"), o.optString("name"), o.optString("type", "SOCKS5"),
            o.optString("host"), o.optInt("port"), o.optString("user"), o.optString("pass"),
            o.optBoolean("sub", false)
        )
    }
}

object Store {
    private lateinit var sp: SharedPreferences
    lateinit var appContext: Context
        private set

    const val MODE_ALL = 0
    const val MODE_ONLY = 1
    const val MODE_EXCLUDE = 2

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        appContext = ctx.applicationContext
        sp = appContext.getSharedPreferences("snake", Context.MODE_PRIVATE)
    }

    @Synchronized
    fun profiles(): MutableList<ProxyProfile> {
        val arr = JSONArray(sp.getString("profiles", "[]"))
        return MutableList(arr.length()) { ProxyProfile.fromJson(arr.getJSONObject(it)) }
    }

    @Synchronized
    fun saveProfiles(list: List<ProxyProfile>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString("profiles", arr.toString()).apply()
    }

    fun get(id: String?): ProxyProfile? = if (id == null) null else profiles().firstOrNull { it.id == id }

    @Synchronized
    fun upsert(p: ProxyProfile) {
        val list = profiles()
        val i = list.indexOfFirst { it.id == p.id }
        if (i >= 0) list[i] = p else list.add(p)
        saveProfiles(list)
    }

    @Synchronized
    fun delete(id: String) {
        saveProfiles(profiles().filter { it.id != id })
        if (selectedId == id) selectedId = null
    }

    var selectedId: String?
        get() = sp.getString("selected", null)
        set(v) = sp.edit().putString("selected", v).apply()

    var appMode: Int
        get() = sp.getInt("appMode", MODE_ALL)
        set(v) = sp.edit().putInt("appMode", v).apply()

    var apps: Set<String>
        get() = sp.getStringSet("apps", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("apps", v).apply()

    var subUrl: String
        get() = sp.getString("subUrl", "")!!
        set(v) = sp.edit().putString("subUrl", v).apply()

    var autoSync: Boolean
        get() = sp.getBoolean("autoSync", true)
        set(v) = sp.edit().putBoolean("autoSync", v).apply()

    var autoFailover: Boolean
        get() = sp.getBoolean("autoFailover", true)
        set(v) = sp.edit().putBoolean("autoFailover", v).apply()

    var debugLog: Boolean
        get() = sp.getBoolean("debugLog", false)
        set(v) = sp.edit().putBoolean("debugLog", v).apply()
}

/** প্রক্সি লেখা থেকে প্রোফাইল বানায়। সাপোর্টেড ফরম্যাট:
 *  ip:port   ip:port:user:pass   user:pass@ip:port
 *  socks5://user:pass@ip:port   http://user:pass@ip:port */
object ProxyParser {
    private val schemeRx = Regex("^(socks5h?|socks4?|https?)://", RegexOption.IGNORE_CASE)

    fun parseLine(raw: String, defType: String): ProxyProfile? {
        var s = raw.trim()
        if (s.isEmpty() || s.startsWith("#") || s.startsWith("//")) return null
        var type = defType
        var hadScheme = false
        schemeRx.find(s)?.let {
            type = if (it.value.lowercase().startsWith("http")) "HTTP" else "SOCKS5"
            s = s.substring(it.value.length)
            hadScheme = true
        }
        s = s.substringBefore("#").substringBefore("/").trim()

        var user = ""
        var pass = ""
        var hostPort = s
        if (s.contains("@")) {
            val cred = s.substringBeforeLast("@")
            hostPort = s.substringAfterLast("@")
            user = cred.substringBefore(":")
            pass = cred.substringAfter(":", "")
            if (hadScheme) {
                user = dec(user); pass = dec(pass)
            }
        } else if (!s.startsWith("[")) {
            val parts = s.split(":")
            if (parts.size >= 4) {
                hostPort = parts[0] + ":" + parts[1]
                user = parts[2]
                pass = parts.drop(3).joinToString(":")
            }
        }
        val host = hostPort.substringBeforeLast(":").trim().trim('[', ']')
        val port = hostPort.substringAfterLast(":").trim().toIntOrNull() ?: return null
        if (host.isBlank() || port !in 1..65535) return null
        return ProxyProfile(ProxyProfile.newId(), "$host:$port", type, host, port, user, pass)
    }

    fun parseAll(text: String, defType: String): List<ProxyProfile> =
        text.lines().mapNotNull { parseLine(it, defType) }

    private fun dec(x: String) = try { URLDecoder.decode(x, "UTF-8") } catch (e: Exception) { x }
}

object AppLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(msg: String) {
        lines.addLast("[${fmt.format(Date())}] $msg")
        while (lines.size > 500) lines.removeFirst()
    }

    @Synchronized
    fun dump(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() = lines.clear()
}

object Fmt {
    fun bytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.2f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun speed(b: Long) = bytes(b) + "/s"

    fun dur(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }
}
