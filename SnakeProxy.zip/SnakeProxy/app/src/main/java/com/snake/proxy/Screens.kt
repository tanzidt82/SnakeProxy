package com.snake.proxy

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import java.io.File
import java.io.RandomAccessFile
import kotlin.concurrent.thread

// ======================= Add / edit proxy =======================

class EditProfileActivity : AppCompatActivity() {
    private var editing: ProxyProfile? = null
    private var type = "SOCKS5"
    private var showPass = false
    private lateinit var etName: EditText
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etPaste: EditText
    private lateinit var segSocks: TextView
    private lateinit var segHttp: TextView
    private lateinit var resultBox: View
    private lateinit var ivResult: ImageView
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        etName = findViewById(R.id.etName)
        etHost = findViewById(R.id.etHost)
        etPort = findViewById(R.id.etPort)
        etUser = findViewById(R.id.etUser)
        etPass = findViewById(R.id.etPass)
        etPaste = findViewById(R.id.etPaste)
        segSocks = findViewById(R.id.segSocks)
        segHttp = findViewById(R.id.segHttp)
        resultBox = findViewById(R.id.resultBox)
        ivResult = findViewById(R.id.ivResult)
        tvResult = findViewById(R.id.tvResult)

        editing = Store.get(intent.getStringExtra("id"))
        setupHeader(if (editing == null) "Add proxy" else "Edit proxy")
        setType("SOCKS5")
        editing?.let { fill(it) }

        segSocks.setOnClickListener { setType("SOCKS5") }
        segHttp.setOnClickListener { setType("HTTP") }

        findViewById<View>(R.id.btnShowPass).setOnClickListener {
            showPass = !showPass
            val variation = if (showPass) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                            else InputType.TYPE_TEXT_VARIATION_PASSWORD
            etPass.inputType = InputType.TYPE_CLASS_TEXT or variation
            etPass.setSelection(etPass.text.length)
            (it as TextView).text = if (showPass) "Hide" else "Show"
        }

        findViewById<View>(R.id.btnFill).setOnClickListener {
            var t = etPaste.text.toString()
            if (t.isBlank()) {
                t = try {
                    getSystemService(ClipboardManager::class.java).primaryClip
                        ?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                } catch (e: Exception) { "" }
                etPaste.setText(t)
            }
            val p = ProxyParser.parseLine(t.lines().firstOrNull() ?: "", type)
            if (p == null) toast("Unrecognized format") else fill(p.copy(name = etName.text.toString().ifBlank { p.name }))
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            val p = read() ?: return@setOnClickListener
            Store.upsert(p)
            if (Store.get(Store.selectedId) == null) Store.selectedId = p.id
            if (SnakeVpnService.running && SnakeVpnService.profileId == p.id) {
                SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
            }
            toast("Proxy saved")
            finish()
        }
        findViewById<View>(R.id.btnTest).setOnClickListener {
            val p = read() ?: return@setOnClickListener
            showResult(0, "Testing connection…")
            thread {
                val r = ProxyTester.test(p)
                runOnUiThread {
                    if (r.ok) showResult(1, "Working  ·  ${r.ms} ms\nProxy IP: ${r.ip}")
                    else showResult(2, "Not working\n${r.error}")
                }
            }
        }
    }

    private fun showResult(state: Int, text: String) {
        resultBox.visibility = View.VISIBLE
        tvResult.text = text
        ivResult.setImageResource(if (state == 1) R.drawable.ic_check else R.drawable.ic_bolt)
        ivResult.setColorFilter(
            when (state) {
                1 -> Palette.ok(ivResult)
                2 -> Palette.bad(ivResult)
                else -> ContextCompat.getColor(this, R.color.ink)
            }
        )
    }

    private fun setType(t: String) {
        type = t
        styleSegments(if (t == "HTTP") 1 else 0, segSocks, segHttp)
    }

    private fun fill(p: ProxyProfile) {
        etName.setText(p.name)
        etHost.setText(p.host)
        etPort.setText(p.port.toString())
        etUser.setText(p.user)
        etPass.setText(p.pass)
        setType(p.type)
    }

    private fun read(): ProxyProfile? {
        val host = etHost.text.toString().trim().trim('[', ']')
        val port = etPort.text.toString().trim().toIntOrNull()
        if (host.isEmpty()) { toast("Enter the server address"); return null }
        if (port == null || port !in 1..65535) { toast("Enter a valid port"); return null }
        return ProxyProfile(
            id = editing?.id ?: ProxyProfile.newId(),
            name = etName.text.toString().trim().ifEmpty { "$host:$port" },
            type = type,
            host = host, port = port,
            user = etUser.text.toString().trim(),
            pass = etPass.text.toString(),
            fromSub = editing?.fromSub ?: false
        )
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

// ======================= Per-app proxy =======================

class AppsActivity : AppCompatActivity() {
    data class AppItem(val pkg: String, val label: String, val info: ApplicationInfo)

    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private val checked = HashSet<String>()
    private var mode = Store.MODE_ALL
    private var startMode = Store.MODE_ALL
    private var startApps: Set<String> = emptySet()
    private lateinit var segAll: TextView
    private lateinit var segOnly: TextView
    private lateinit var segBypass: TextView
    private lateinit var tvHint: TextView

    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
            object : RecyclerView.ViewHolder(
                LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
            ) {}

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val a = shown[pos]
            val v = h.itemView
            v.findViewById<TextView>(R.id.tvLabel).text = a.label
            v.findViewById<TextView>(R.id.tvPkg).text = a.pkg
            v.findViewById<ImageView>(R.id.ivIcon).setImageDrawable(
                try { a.info.loadIcon(packageManager) } catch (e: Exception) { null }
            )
            val check = v.findViewById<ImageView>(R.id.ivCheck)
            fun paint() {
                if (a.pkg in checked) {
                    check.setBackgroundResource(R.drawable.bg_check_on)
                    check.setImageResource(R.drawable.ic_check)
                    check.setColorFilter(android.graphics.Color.WHITE)
                } else {
                    check.setBackgroundResource(R.drawable.bg_check_off)
                    check.setImageDrawable(null)
                }
            }
            paint()
            v.findViewById<View>(R.id.row).setOnClickListener {
                if (!checked.add(a.pkg)) checked.remove(a.pkg)
                paint()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)
        setupHeader("Apps")
        startMode = Store.appMode
        mode = startMode
        startApps = Store.apps
        checked.addAll(startApps)

        segAll = findViewById(R.id.segAll)
        segOnly = findViewById(R.id.segOnly)
        segBypass = findViewById(R.id.segBypass)
        tvHint = findViewById(R.id.tvModeHint)
        segAll.setOnClickListener { setMode(Store.MODE_ALL) }
        segOnly.setOnClickListener { setMode(Store.MODE_ONLY) }
        segBypass.setOnClickListener { setMode(Store.MODE_EXCLUDE) }
        setMode(mode)

        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@AppsActivity)
            adapter = this@AppsActivity.adapter
        }
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = filter(s?.toString() ?: "")
        })

        val loading = findViewById<TextView>(R.id.tvLoading)
        thread {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val list = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
                .filter { it.packageName != packageName && it.requestedPermissions?.contains(android.Manifest.permission.INTERNET) == true }
                .mapNotNull { pi ->
                    val ai = pi.applicationInfo ?: return@mapNotNull null
                    AppItem(pi.packageName, pm.getApplicationLabel(ai).toString(), ai)
                }
                .sortedWith(compareBy<AppItem>({ it.pkg !in checked }, { it.label.lowercase() }))
            runOnUiThread {
                all = list
                loading.visibility = View.GONE
                filter("")
            }
        }
    }

    private fun setMode(m: Int) {
        mode = m
        styleSegments(
            when (m) { Store.MODE_ONLY -> 1; Store.MODE_EXCLUDE -> 2; else -> 0 },
            segAll, segOnly, segBypass
        )
        tvHint.text = when (m) {
            Store.MODE_ONLY -> "Only the apps you check will use the proxy."
            Store.MODE_EXCLUDE -> "Checked apps go direct. Everything else uses the proxy."
            else -> "Every app on this phone uses the proxy."
        }
    }

    private fun filter(q: String) {
        val s = q.trim().lowercase()
        shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) || it.pkg.contains(s) }
        adapter.notifyDataSetChanged()
    }

    override fun onPause() {
        super.onPause()
        Store.appMode = mode
        Store.apps = checked.toSet()
        if ((mode != startMode || checked != startApps) && SnakeVpnService.running) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
            Toast.makeText(this, "Applying app settings", Toast.LENGTH_SHORT).show()
        }
        startMode = mode
        startApps = checked.toSet()
    }
}

// ======================= Live log =======================

class LogActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var tv: TextView
    private lateinit var scroll: ScrollView
    private var last = ""

    private val tick = object : Runnable {
        override fun run() {
            val text = buildString {
                append(AppLog.dump().ifEmpty { "Waiting for activity…" })
                val engine = tail(File(filesDir, "hev.log"), 48_000)
                if (engine.isNotBlank()) {
                    append("\n\n— engine —\n")
                    append(engine)
                }
            }
            if (text != last) {
                val atBottom = !scroll.canScrollVertically(1)
                tv.text = text
                last = text
                if (atBottom) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)
        setupHeader("Live logs")
        tv = findViewById(R.id.tvLog)
        scroll = findViewById(R.id.scroll)
        val sw = findViewById<MaterialSwitch>(R.id.swDetail)
        sw.isChecked = Store.debugLog
        sw.setOnCheckedChangeListener { _, on ->
            Store.debugLog = on
            if (SnakeVpnService.running) SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
        }
        findViewById<View>(R.id.btnCopy).setOnClickListener {
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("log", tv.text))
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnClear).setOnClickListener {
            AppLog.clear()
            try { RandomAccessFile(File(filesDir, "hev.log"), "rw").use { it.setLength(0) } } catch (ignored: Exception) {}
            last = ""
        }
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun tail(f: File, max: Int): String = try {
        if (!f.exists()) "" else RandomAccessFile(f, "r").use { r ->
            val len = r.length()
            val start = (len - max).coerceAtLeast(0)
            r.seek(start)
            val b = ByteArray((len - start).toInt())
            r.readFully(b)
            String(b).let { if (start > 0) it.substringAfter('\n') else it }
        }
    } catch (e: Exception) { "" }
}

// ======================= Settings =======================

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setupHeader("Settings")
        val etSub = findViewById<EditText>(R.id.etSub)
        val swSync = findViewById<MaterialSwitch>(R.id.swAutoSync)
        val swFail = findViewById<MaterialSwitch>(R.id.swFailover)
        etSub.setText(Store.subUrl)
        swSync.isChecked = Store.autoSync
        swFail.isChecked = Store.autoFailover

        fun save() {
            Store.subUrl = etSub.text.toString().trim()
            Store.autoSync = swSync.isChecked
            Store.autoFailover = swFail.isChecked
        }

        findViewById<View>(R.id.btnSyncNow).setOnClickListener {
            save()
            Toast.makeText(this, "Syncing…", Toast.LENGTH_SHORT).show()
            thread {
                val r = SubSync.sync()
                runOnUiThread {
                    Toast.makeText(
                        this, r.fold({ "$it proxies loaded" }, { "Sync failed: ${it.message}" }), Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        findViewById<View>(R.id.btnKill).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (ignored: Exception) {
                Toast.makeText(this, "Could not open VPN settings", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            save()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
