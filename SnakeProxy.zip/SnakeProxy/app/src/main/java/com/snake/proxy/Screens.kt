package com.snake.proxy

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import java.io.File
import java.io.RandomAccessFile
import kotlin.concurrent.thread

// ======================= প্রক্সি যোগ / এডিট =======================

class EditProfileActivity : AppCompatActivity() {
    private var editing: ProxyProfile? = null
    private lateinit var etName: EditText
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etPaste: EditText
    private lateinit var rbHttp: RadioButton
    private lateinit var rbSocks: RadioButton
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        etName = findViewById(R.id.etName)
        etHost = findViewById(R.id.etHost)
        etPort = findViewById(R.id.etPort)
        etUser = findViewById(R.id.etUser)
        etPass = findViewById(R.id.etPass)
        etPaste = findViewById(R.id.etPaste)
        rbHttp = findViewById(R.id.rbHttp)
        rbSocks = findViewById(R.id.rbSocks)
        tvResult = findViewById(R.id.tvResult)

        editing = Store.get(intent.getStringExtra("id"))
        title = if (editing == null) "নতুন প্রক্সি" else "প্রক্সি এডিট"
        editing?.let { fill(it) }

        findViewById<View>(R.id.btnFill).setOnClickListener {
            var t = etPaste.text.toString()
            if (t.isBlank()) {
                t = try {
                    getSystemService(ClipboardManager::class.java).primaryClip
                        ?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                } catch (e: Exception) { "" }
                etPaste.setText(t)
            }
            val p = ProxyParser.parseLine(t.lines().firstOrNull() ?: "", if (rbHttp.isChecked) "HTTP" else "SOCKS5")
            if (p == null) toast("ফরম্যাট বুঝতে পারিনি") else fill(p.copy(name = etName.text.toString().ifBlank { p.name }))
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            val p = read() ?: return@setOnClickListener
            Store.upsert(p)
            if (Store.get(Store.selectedId) == null) Store.selectedId = p.id
            if (SnakeVpnService.running && SnakeVpnService.profileId == p.id) {
                SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
            }
            toast("সেভ হয়েছে")
            finish()
        }
        findViewById<View>(R.id.btnTest).setOnClickListener {
            val p = read() ?: return@setOnClickListener
            tvResult.text = "⏳ টেস্ট হচ্ছে..."
            thread {
                val r = ProxyTester.test(p)
                runOnUiThread {
                    tvResult.text = if (r.ok) "✅ কাজ করছে\nগতি: ${r.ms}ms\nপ্রক্সি IP: ${r.ip}" else "❌ কাজ করছে না\n${r.error}"
                }
            }
        }
    }

    private fun fill(p: ProxyProfile) {
        etName.setText(p.name)
        etHost.setText(p.host)
        etPort.setText(p.port.toString())
        etUser.setText(p.user)
        etPass.setText(p.pass)
        if (p.type == "HTTP") rbHttp.isChecked = true else rbSocks.isChecked = true
    }

    private fun read(): ProxyProfile? {
        val host = etHost.text.toString().trim().trim('[', ']')
        val port = etPort.text.toString().trim().toIntOrNull()
        if (host.isEmpty()) { toast("সার্ভার লিখুন"); return null }
        if (port == null || port !in 1..65535) { toast("সঠিক পোর্ট লিখুন"); return null }
        return ProxyProfile(
            id = editing?.id ?: ProxyProfile.newId(),
            name = etName.text.toString().trim().ifEmpty { "$host:$port" },
            type = if (rbHttp.isChecked) "HTTP" else "SOCKS5",
            host = host, port = port,
            user = etUser.text.toString().trim(),
            pass = etPass.text.toString(),
            fromSub = editing?.fromSub ?: false
        )
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

// ======================= অ্যাপ বাছাই (Per-app) =======================

class AppsActivity : AppCompatActivity() {
    data class AppItem(val pkg: String, val label: String, val info: ApplicationInfo)

    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private val checked = HashSet<String>()
    private var startMode = 0
    private var startApps: Set<String> = emptySet()
    private lateinit var rg: RadioGroup
    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            object : RecyclerView.ViewHolder(
                LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
            ) {}

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val a = shown[pos]
            val v = h.itemView
            v.findViewById<TextView>(R.id.tvLabel).text = a.label
            v.findViewById<TextView>(R.id.tvPkg).text = a.pkg
            v.findViewById<ImageView>(R.id.ivIcon).setImageDrawable(
                try { a.info.loadIcon(packageManager) } catch (e: Exception) { null }
            )
            val cb = v.findViewById<CheckBox>(R.id.cb)
            cb.isChecked = a.pkg in checked
            v.setOnClickListener {
                if (!checked.add(a.pkg)) checked.remove(a.pkg)
                cb.isChecked = a.pkg in checked
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)
        title = "অ্যাপ বাছাই"
        startMode = Store.appMode
        startApps = Store.apps
        checked.addAll(startApps)

        rg = findViewById(R.id.rgMode)
        rg.check(
            when (startMode) {
                Store.MODE_ONLY -> R.id.rbOnly
                Store.MODE_EXCLUDE -> R.id.rbExclude
                else -> R.id.rbAll
            }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@AppsActivity)
            adapter = this@AppsActivity.adapter
        }
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = filter(s?.toString() ?: "")
        })

        val loading = findViewById<TextView>(R.id.tvLoading)
        thread {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val list = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
                .filter { it.packageName != packageName && it.requestedPermissions?.contains(android.Manifest.permission.INTERNET) == true }
                .mapNotNull { pi ->
                    val ai = pi.applicationInfo ?: return@mapNotNull null
                    AppItem(pi.packageName, pm.getApplicationLabel(ai).toString(), ai)
                }
                .sortedWith(compareBy({ it.pkg !in checked }, { it.label.lowercase() }))
            runOnUiThread {
                all = list
                loading.visibility = View.GONE
                filter("")
            }
        }
    }

    private fun filter(q: String) {
        val s = q.trim().lowercase()
        shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) || it.pkg.contains(s) }
        adapter.notifyDataSetChanged()
    }

    override fun onPause() {
        super.onPause()
        val mode = when (rg.checkedRadioButtonId) {
            R.id.rbOnly -> Store.MODE_ONLY
            R.id.rbExclude -> Store.MODE_EXCLUDE
            else -> Store.MODE_ALL
        }
        Store.appMode = mode
        Store.apps = checked.toSet()
        if ((mode != startMode || checked != startApps) && SnakeVpnService.running) {
            SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
            Toast.makeText(this, "নতুন অ্যাপ সেটিং চালু হচ্ছে", Toast.LENGTH_SHORT).show()
        }
        startMode = mode
        startApps = checked.toSet()
    }
}

// ======================= লাইভ লগ =======================

class LogActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var tv: TextView
    private lateinit var scroll: ScrollView
    private var last = ""

    private val tick = object : Runnable {
        override fun run() {
            val text = buildString {
                append(AppLog.dump().ifEmpty { "(এখনো কিছু নেই)" })
                val engine = tail(File(filesDir, "hev.log"), 48_000)
                if (engine.isNotBlank()) {
                    append("\n\n------ ইঞ্জিন লগ ------\n")
                    append(engine)
                }
            }
            if (text != last) {
                val atBottom = !scroll.canScrollVertically(1)
                tv.text = text
                last = text
                if (atBottom) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)
        title = "লাইভ লগ"
        tv = findViewById(R.id.tvLog)
        scroll = findViewById(R.id.scroll)
        val sw = findViewById<MaterialSwitch>(R.id.swDetail)
        sw.isChecked = Store.debugLog
        sw.setOnCheckedChangeListener { _, on ->
            Store.debugLog = on
            if (SnakeVpnService.running) SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, SnakeVpnService.profileId)
        }
        findViewById<View>(R.id.btnCopy).setOnClickListener {
            getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("log", tv.text))
            Toast.makeText(this, "কপি হয়েছে", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnClear).setOnClickListener {
            AppLog.clear()
            try { RandomAccessFile(File(filesDir, "hev.log"), "rw").use { it.setLength(0) } } catch (_: Exception) {}
            last = ""
        }
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun tail(f: File, max: Int): String = try {
        if (!f.exists()) "" else RandomAccessFile(f, "r").use { r ->
            val len = r.length()
            val start = (len - max).coerceAtLeast(0)
            r.seek(start)
            val b = ByteArray((len - start).toInt())
            r.readFully(b)
            String(b).let { if (start > 0) it.substringAfter('\n') else it }
        }
    } catch (e: Exception) { "" }
}

// ======================= সেটিংস =======================

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        title = "সেটিংস"
        val etSub = findViewById<EditText>(R.id.etSub)
        val swSync = findViewById<MaterialSwitch>(R.id.swAutoSync)
        val swFail = findViewById<MaterialSwitch>(R.id.swFailover)
        etSub.setText(Store.subUrl)
        swSync.isChecked = Store.autoSync
        swFail.isChecked = Store.autoFailover

        fun save() {
            Store.subUrl = etSub.text.toString().trim()
            Store.autoSync = swSync.isChecked
            Store.autoFailover = swFail.isChecked
        }

        findViewById<View>(R.id.btnSyncNow).setOnClickListener {
            save()
            Toast.makeText(this, "সিঙ্ক হচ্ছে...", Toast.LENGTH_SHORT).show()
            thread {
                val r = SubSync.sync()
                runOnUiThread {
                    Toast.makeText(
                        this, r.fold({ "✅ ${it}টি প্রক্সি পাওয়া গেছে" }, { "❌ ${it.message}" }), Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        findViewById<View>(R.id.btnKill).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (_: Exception) {
                Toast.makeText(this, "VPN সেটিংস খোলা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            save()
            Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
