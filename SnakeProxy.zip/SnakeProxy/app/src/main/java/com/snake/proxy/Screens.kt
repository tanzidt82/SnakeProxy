package com.snake.proxy

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.RandomAccessFile
import kotlin.concurrent.thread

// ======================= Add / edit proxy =======================

class EditProfileActivity : AppCompatActivity() {
    private var editing: ProxyProfile? = null
    private var type = "SOCKS5"
    private var showPass = false
    private lateinit var etName: EditText
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etPaste: EditText
    private lateinit var segSocks: TextView
    private lateinit var segHttp: TextView
    private lateinit var resultBox: View
    private lateinit var ivResult: ImageView
    private lateinit var tvResult: TextView

    private fun updateProvider() {
        val host = etHost.text.toString().trim()
        val row = findViewById<View>(R.id.provRow)
        if (host.isEmpty()) { row.visibility = View.GONE; return }
        row.visibility = View.VISIBLE
        val prov = Providers.of(host)
        findViewById<TextView>(R.id.tvProvName).text = prov.name
        bindProvider(findViewById(R.id.tvProvLetter), findViewById(R.id.ivProv), host, prov.name)
        val probe = ProxyProfile("x", "x", type, host, 1, etUser.text.toString().trim(), etPass.text.toString())
        val geo = findViewById<TextView>(R.id.tvProvGeo)
        when {
            CountryRouting.canTarget(probe) -> {
                geo.text = "All countries"
                geo.setTextColor(Palette.ok(geo))
            }
            probe.user.isEmpty() -> {
                geo.text = ""
                geo.setTextColor(Palette.muted(geo))
            }
            else -> {
                geo.text = "Fixed location"
                geo.setTextColor(Palette.muted(geo))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        etName = findViewById(R.id.etName)
        etHost = findViewById(R.id.etHost)
        etPort = findViewById(R.id.etPort)
        etUser = findViewById(R.id.etUser)
        etPass = findViewById(R.id.etPass)
        etPaste = findViewById(R.id.etPaste)
        segSocks = findViewById(R.id.segSocks)
        segHttp = findViewById(R.id.segHttp)
        resultBox = findViewById(R.id.resultBox)
        ivResult = findViewById(R.id.ivResult)
        tvResult = findViewById(R.id.tvResult)

        editing = Store.get(intent.getStringExtra("id"))
        setupHeader(if (editing == null) "Add proxy" else "Edit proxy")
        Motion.stagger(findViewById(R.id.sheet))
        setType("SOCKS5")
        editing?.let { fill(it) }

        segSocks.setOnClickListener { setType("SOCKS5") }
        segHttp.setOnClickListener { setType("HTTP") }
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = updateProvider()
        }
        etHost.addTextChangedListener(watcher)
        etUser.addTextChangedListener(watcher)
        etPass.addTextChangedListener(watcher)
        updateProvider()
        Motion.pressable(findViewById(android.R.id.content))

        findViewById<View>(R.id.btnShowPass).setOnClickListener {
            showPass = !showPass
            val variation = if (showPass) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                            else InputType.TYPE_TEXT_VARIATION_PASSWORD
            etPass.inputType = InputType.TYPE_CLASS_TEXT or variation
            etPass.setSelection(etPass.text.length)
            it.alpha = if (showPass) 1f else 0.6f
        }

        findViewById<View>(R.id.btnFill).setOnClickListener {
            var t = etPaste.text.toString()
            if (t.isBlank()) {
                t = try {
                    getSystemService(ClipboardManager::class.java).primaryClip
                        ?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                } catch (e: Exception) { "" }
                etPaste.setText(t)
            }
            val p = ProxyParser.parseLine(t.lines().firstOrNull() ?: "", type)
            if (p == null) toast("Unrecognized format") else fill(p.copy(name = etName.text.toString().ifBlank { p.name }))
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            val p = read() ?: return@setOnClickListener
            Store.upsert(p)
            if (Store.get(Store.selectedId) == null) Store.selectedId = p.id
            if (SnakeVpnService.running && SnakeVpnService.profileId == p.id) {
                SnakeVpnService.send(this, SnakeVpnService.ACTION_RELOAD, p.id)
            }
            toast("Proxy saved")
            finish()
        }
        findViewById<View>(R.id.btnTest).setOnClickListener {
            val p = read() ?: return@setOnClickListener
            showResult(0, "Testing connection…")
            val target = CountryRouting.apply(p, Store.country) ?: p
            thread {
                val g = GeoCheck.through(target)
                runOnUiThread {
                    if (g.ok) showResult(1, "Working  ·  ${g.ms} ms\n${g.ip}" + if (g.country.isNotEmpty()) "  ·  ${g.country}" else "")
                    else showResult(2, "Not working\n${g.error}")
                }
            }
        }
    }

    private fun showResult(state: Int, text: String) {
        resultBox.visibility = View.VISIBLE
        tvResult.text = text
        (resultBox as GlowLayout).setGlow(when (state) { 1 -> GlowColors.GREEN; 2 -> GlowColors.RED; else -> GlowColors.BLUE })
        ivResult.setImageResource(when (state) { 1 -> R.drawable.ic_check; 2 -> R.drawable.ic_error; else -> R.drawable.ic_bolt })
        ivResult.setColorFilter(android.graphics.Color.WHITE)
    }

    private fun setType(t: String) {
        type = t
        styleSegments(if (t == "HTTP") 1 else 0, segSocks, segHttp)
    }

    override fun onResume() {
        super.onResume()
        if (::etHost.isInitialized) updateProvider()
    }

    private fun fill(p: ProxyProfile) {
        etName.setText(p.name)
        etHost.setText(p.host)
        etPort.setText(p.port.toString())
        etUser.setText(p.user)
        etPass.setText(p.pass)
        setType(p.type)
    }

    private fun read(): ProxyProfile? {
        val host = etHost.text.toString().trim().trim('[', ']')
        val port = etPort.text.toString().trim().toIntOrNull()
        if (host.isEmpty()) { toast("Enter the server address"); return null }
        if (port == null || port !in 1..65535) { toast("Enter a valid port"); return null }
        return ProxyProfile(
            id = editing?.id ?: ProxyProfile.newId(),
            name = etName.text.toString().trim().ifEmpty { Providers.of(host).name + " " + port },
            type = type,
            host = host, port = port,
            user = etUser.text.toString().trim(),
            pass = etPass.text.toString(),
            fromSub = editing?.fromSub ?: false
        )
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

// ======================= Settings =======================

class SettingsActivity : AppCompatActivity() {
    private lateinit var themeChips: List<GlowLayout>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setupHeader("Settings")
        val etSub = findViewById<EditText>(R.id.etSub)
        val togSync = findViewById<ToggleView>(R.id.togAutoSync)
        val togFail = findViewById<ToggleView>(R.id.togFailover)
        etSub.setText(Store.subUrl)
        togSync.setCheckedNow(Store.autoSync)
        togFail.setCheckedNow(Store.autoFailover)
        findViewById<View>(R.id.cardAutoSync).setOnClickListener { togSync.performClick() }
        findViewById<View>(R.id.cardFailover).setOnClickListener { togFail.performClick() }

        themeChips = listOf(findViewById(R.id.segThemeSys), findViewById(R.id.segThemeLight), findViewById(R.id.segThemeDark))
        styleTheme(Store.themeMode)
        themeChips.forEachIndexed { i, v ->
            v.setOnClickListener {
                if (Store.themeMode != i) {
                    Store.themeMode = i
                    styleTheme(i)
                    Store.applyTheme()
                }
            }
        }

        fun save() {
            Store.subUrl = etSub.text.toString().trim()
            Store.autoSync = togSync.isChecked
            Store.autoFailover = togFail.isChecked
        }

        findViewById<View>(R.id.btnSyncNow).setOnClickListener {
            save()
            Toast.makeText(this, "Syncing…", Toast.LENGTH_SHORT).show()
            thread {
                val r = SubSync.sync()
                runOnUiThread {
                    r.fold(
                        { Glass.show(this, Glass.OK, "Synced", "$it proxies loaded from your subscription.") },
                        { Glass.show(this, Glass.ERROR, "Sync failed", it.message ?: "Unknown error") }
                    )
                }
            }
        }
        findViewById<View>(R.id.btnUsage).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (ignored: Exception) {}
        }
        findViewById<View>(R.id.btnKill).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (ignored: Exception) {
                Toast.makeText(this, "Could not open VPN settings", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            save()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            finish()
        }
        Motion.stagger(findViewById(R.id.segThemeSys), findViewById(R.id.btnKill), findViewById(R.id.cardDns), findViewById(R.id.cardFailover))
        Motion.pressable(findViewById(android.R.id.content))
    }

    private fun styleTheme(sel: Int) {
        val d = resources.displayMetrics.density
        themeChips.forEachIndexed { i, v ->
            val on = i == sel
            v.background = GlowDrawable(this, GlowColors.BLUE, !on, 20 * d).also { it.glowOn = on }
            GlowSupport.applyShadow(v, GlowColors.BLUE, on)
            val icon = v.getChildAt(0) as ImageView
            val label = v.getChildAt(1) as TextView
            icon.setColorFilter(if (on) android.graphics.Color.WHITE else ContextCompat.getColor(this, R.color.text))
            label.setTextColor(if (on) android.graphics.Color.WHITE else ContextCompat.getColor(this, R.color.text2))
        }
    }

    override fun onResume() {
        super.onResume()
        findViewById<TextView>(R.id.tvUsageState).text =
            if (Foreground.hasPermission(this)) "Enabled · logs show the app for each connection"
            else "Off · tap to allow Fleet Proxy"
    }
}
