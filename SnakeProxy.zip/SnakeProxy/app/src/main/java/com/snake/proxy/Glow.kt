package com.snake.proxy

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatTextView
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min

/** Accent colours used by glowing cards. */
object GlowColors {
    val BLUE = Color.rgb(60, 140, 255)
    val ORANGE = Color.rgb(255, 120, 40)
    val GREEN = Color.rgb(40, 220, 110)
    val PURPLE = Color.rgb(170, 80, 255)
    val RED = Color.rgb(255, 70, 100)
    val AMBER = Color.rgb(245, 165, 36)
    val CYCLE = listOf(ORANGE, BLUE, PURPLE, GREEN)

    fun night(ctx: Context) =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
}

/**
 * Dark glass card whose colour light rises from the bottom edge, drifting left/right and
 * breathing, with a bright rim and a highlight that slides along the bottom.
 */
class GlowDrawable(
    ctx: Context,
    color: Int,
    var soft: Boolean,
    private val radius: Float
) : Drawable(), Animatable {

    private val d = ctx.resources.displayMetrics.density
    private val night = GlowColors.night(ctx)
    private val whiteBase = !night
    private val baseTop = androidx.core.content.ContextCompat.getColor(ctx, R.color.card_top)
    private val baseBottom = androidx.core.content.ContextCompat.getColor(ctx, R.color.card_bottom)

    /** Draws a thin border in the accent colour while glowing (selected chips). */
    var accentBorder = false
        set(v) { field = v; invalidateSelf() }

    var color: Int = color
        set(v) { if (field != v) { field = v; glowShader = null; invalidateSelf() } }

    /** When false the card is drawn plain (no colour light). */
    var glowOn = true
        set(v) { if (field != v) { field = v; invalidateSelf() } }

    private val path = Path()
    private val rect = RectF()
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val hazePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val m = Matrix()
    private var glowShader: RadialGradient? = null
    private var lastH = -1

    private var phase = Math.random().toFloat()
    private var shine = Math.random().toFloat()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        val off = phase
        addUpdateListener {
            val f = it.animatedValue as Float
            phase = (f + off) % 1f
            shine = (f + off * 0.7f) % 1f
            invalidateSelf()
        }
    }

    private fun alpha(c: Int, a: Float) = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    override fun onBoundsChange(b: android.graphics.Rect) {
        super.onBoundsChange(b)
        rect.set(b)
        path.reset()
        val r = min(radius, min(rect.width(), rect.height()) / 2f)
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        if (b.height() != lastH) {
            lastH = b.height()
            val h = rect.height()
            basePaint.shader = if (whiteBase) null else
                LinearGradient(0f, rect.top, 0f, rect.bottom, baseTop, baseBottom, Shader.TileMode.CLAMP)
            if (whiteBase) basePaint.color = Color.WHITE
            hazePaint.shader = LinearGradient(0f, rect.bottom - 16 * d, 0f, rect.bottom,
                Color.TRANSPARENT, Color.argb(if (whiteBase) 60 else 90, 255, 255, 255), Shader.TileMode.CLAMP)
            val rimTop = rect.bottom - min(h * 0.5f, r * 1.4f + 6 * d)
            rimShaderTop = rimTop
            rimPaint.shader = null
        }
        glowShader = null
    }

    private var rimShaderTop = 0f

    override fun draw(c: Canvas) {
        if (rect.isEmpty) return
        val w = rect.width()
        val h = rect.height()
        c.save()
        c.clipPath(path)
        c.drawPath(path, basePaint)

        if (glowOn) {
            val e = ((1 - cos(2 * PI * phase)) / 2).toFloat()
            val gx = 0.28f + 0.44f * e
            val ga = 0.72f + 0.28f * e
            if (glowShader == null) {
                val a = if (whiteBase) floatArrayOf(0.5f, 0.17f, 0.05f) else if (soft) floatArrayOf(0.95f, 0.4f, 0.08f) else floatArrayOf(0.95f, 0.45f, 0.08f)
                glowShader = RadialGradient(
                    0f, 0f, 1f,
                    intArrayOf(alpha(color, a[0]), alpha(color, a[1]), alpha(color, a[2]), Color.TRANSPARENT),
                    floatArrayOf(0f, if (soft) 0.32f else 0.28f, if (soft) 0.6f else 0.55f, if (soft) 0.72f else 0.7f),
                    Shader.TileMode.CLAMP
                )
                glowPaint.shader = glowShader
                rimPaint.shader = LinearGradient(0f, rimShaderTop, 0f, rect.bottom,
                    Color.TRANSPARENT, color, Shader.TileMode.CLAMP)
            }
            val rx = w * (if (soft) 1.3f else 1.2f)
            val ry = h * (if (soft) 0.55f else 0.7f)
            m.reset()
            m.setScale(rx, ry)
            m.postTranslate(rect.left + w * gx, rect.top + h * (if (soft) 1.22f else 1.2f))
            glowShader?.setLocalMatrix(m)
            glowPaint.shader = glowShader
            glowPaint.alpha = (ga * 255).toInt()
            c.drawRect(rect, glowPaint)

            if (!soft && !whiteBase) c.drawRect(rect.left, rect.bottom - 16 * d, rect.right, rect.bottom, hazePaint)

            rimPaint.strokeWidth = 2.4f * d
            c.drawPath(path, rimPaint)

            val sx = rect.left + w * (-0.3f + 1.6f * shine)
            val half = w * 0.16f
            shinePaint.shader = LinearGradient(sx - half, 0f, sx + half, 0f,
                intArrayOf(Color.TRANSPARENT, Color.argb(235, 255, 255, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(sx - half, rect.bottom - 2f * d, sx + half, rect.bottom, shinePaint)
        }

        if (glowOn && accentBorder) {
            borderPaint.strokeWidth = 1.6f * d
            borderPaint.color = alpha(color, 0.7f)
        } else {
            borderPaint.strokeWidth = d
            borderPaint.color = if (whiteBase) Color.argb(18, 20, 40, 90) else Color.argb(22, 255, 255, 255)
        }
        c.drawPath(path, borderPaint)
        c.restore()
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        if (visible) start() else stop()
        return changed
    }

    override fun start() { if (!anim.isStarted) anim.start() }
    override fun stop() { anim.cancel() }
    override fun isRunning() = anim.isRunning

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT

    /** Outline used for the coloured shadow under the card. */
    override fun getOutline(outline: android.graphics.Outline) {
        outline.setRoundRect(bounds, min(radius, min(bounds.width(), bounds.height()) / 2f))
        outline.alpha = 1f
    }
}

/** Shared setup for every glowing view. */
internal object GlowSupport {
    fun init(v: View, attrs: AttributeSet?): GlowDrawable {
        val ctx = v.context
        val a = ctx.obtainStyledAttributes(attrs, R.styleable.Glow)
        val color = a.getColor(R.styleable.Glow_glowColor, GlowColors.BLUE)
        val soft = a.getBoolean(R.styleable.Glow_glowSoft, false)
        val radius = a.getDimension(R.styleable.Glow_glowRadius, 24 * ctx.resources.displayMetrics.density)
        val enabled = a.getBoolean(R.styleable.Glow_glowEnabled, true)
        val shadow = a.getBoolean(R.styleable.Glow_glowShadow, true)
        a.recycle()
        val g = GlowDrawable(ctx, color, soft, radius)
        g.glowOn = enabled
        v.background = g
        v.clipToOutline = false
        if (shadow) {
            v.elevation = 10 * ctx.resources.displayMetrics.density
            applyShadow(v, color, enabled)
        }
        return g
    }

    fun applyShadow(v: View, color: Int, on: Boolean) {
        if (Build.VERSION.SDK_INT >= 28) {
            val c = if (on) color else Color.BLACK
            v.outlineSpotShadowColor = c
            v.outlineAmbientShadowColor = c
        }
    }
}

interface Glowing {
    val glow: GlowDrawable
    fun setGlow(color: Int, on: Boolean = true) {
        glow.color = color
        glow.glowOn = on
        GlowSupport.applyShadow(this as View, color, on)
    }
}

class GlowLayout @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : LinearLayout(ctx, attrs), Glowing {
    override val glow: GlowDrawable = GlowSupport.init(this, attrs)
}

class GlowFrame @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs), Glowing {
    override val glow: GlowDrawable = GlowSupport.init(this, attrs)
}

class GlowText @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : AppCompatTextView(ctx, attrs), Glowing {
    override val glow: GlowDrawable = GlowSupport.init(this, attrs)
}

/** Connection ring: track, glowing gradient arc, rotating sheen; spins while connecting. */
class RingView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    companion object { const val OFF = 0; const val CONNECTING = 1; const val ON = 2 }

    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val oval = RectF()
    private var rot = 0f
    private var shown = 0f
    private var colorA = Color.rgb(91, 224, 255)
    private var colorB = Color.rgb(26, 125, 255)

    var state = OFF
        set(v) { if (field != v) { field = v; animateTo(if (v == ON) progress else if (v == CONNECTING) 0.28f else 0f); setColors(); invalidate() } }

    /** Fraction of the ring that is filled when ON (0..1). */
    var progress = 1f
        set(v) { field = v.coerceIn(0f, 1f); if (state == ON) animateTo(field) }

    private val spinner = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { rot = it.animatedValue as Float; if (state != OFF) invalidate() }
    }
    private var fill: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        track.color = if (GlowColors.night(ctx)) Color.argb(38, 120, 160, 230) else Color.argb(30, 40, 80, 160)
    }

    private fun setColors() {
        if (state == CONNECTING) { colorA = Color.rgb(255, 205, 110); colorB = GlowColors.AMBER }
        else { colorA = Color.rgb(91, 224, 255); colorB = Color.rgb(26, 125, 255) }
        updateShader()
    }

    private fun animateTo(target: Float) {
        fill?.cancel()
        fill = ValueAnimator.ofFloat(shown, target).apply {
            duration = 900
            interpolator = android.view.animation.DecelerateInterpolator(1.6f)
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun updateShader() {
        if (width == 0) return
        val cx = width / 2f; val cy = height / 2f
        arc.shader = SweepGradient(cx, cy, intArrayOf(colorA, colorB, colorA), floatArrayOf(0f, 0.5f, 1f))
        glowP.shader = arc.shader
        sheen.shader = SweepGradient(cx, cy,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(230, 220, 240, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 0.72f, 0.97f, 1f))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val sw = min(w, h) * 0.064f
        val pad = sw * 2.2f
        oval.set(pad, pad, w - pad, h - pad)
        track.strokeWidth = sw
        arc.strokeWidth = sw
        sheen.strokeWidth = sw * 0.7f
        glowP.strokeWidth = sw * 1.6f
        glowP.maskFilter = BlurMaskFilter(sw * 1.6f, BlurMaskFilter.Blur.NORMAL)
        updateShader()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); spinner.start() }
    override fun onDetachedFromWindow() { spinner.cancel(); fill?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        c.drawOval(oval, track)
        if (shown <= 0.001f) return
        val start = if (state == CONNECTING) rot - 90f else -90f
        val sweep = 360f * shown
        c.save()
        c.rotate(if (state == CONNECTING) rot else 0f, width / 2f, height / 2f)
        glowP.alpha = 150
        c.drawArc(oval, -90f, sweep, false, glowP)
        c.drawArc(oval, -90f, sweep, false, arc)
        c.restore()
        if (state == ON && shown > 0.98f) {
            c.save()
            c.rotate(rot * 1.4f, width / 2f, height / 2f)
            c.drawArc(oval, 0f, 360f, false, sheen)
            c.restore()
        }
        if (start < -1000f) invalidate()
    }
}

/** Small animated on/off switch. */
class ToggleView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val d = resources.displayMetrics.density
    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knobP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(2 * d, 0f, d, Color.argb(60, 0, 0, 0)) }
    private val r = RectF()
    private var pos = 0f
    private val offColor = androidx.core.content.ContextCompat.getColor(ctx, R.color.knob_off)

    var onChange: ((Boolean) -> Unit)? = null
    private var anim: ValueAnimator? = null
    private var instant = false
    var isChecked = false
        set(v) {
            if (field == v) return
            field = v
            anim?.cancel()
            if (instant) { pos = if (v) 1f else 0f; invalidate(); return }
            anim = ValueAnimator.ofFloat(pos, if (v) 1f else 0f).apply {
                duration = 220
                addUpdateListener { pos = it.animatedValue as Float; invalidate() }
                start()
            }
        }

    fun setCheckedNow(v: Boolean) {
        instant = true
        isChecked = v
        instant = false
        anim?.cancel()
        pos = if (v) 1f else 0f
        invalidate()
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        isFocusable = true
        setOnClickListener { isChecked = !isChecked; onChange?.invoke(isChecked) }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((50 * d).toInt(), (30 * d).toInt())

    private fun mix(a: Int, b: Int, f: Float) = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * f).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
    )

    override fun onDraw(c: Canvas) {
        r.set(d, d, width - d, height - d)
        trackP.color = mix(offColor, GlowColors.BLUE, pos)
        c.drawRoundRect(r, r.height() / 2, r.height() / 2, trackP)
        val kr = r.height() / 2 - 3 * d
        val cx = r.left + 3 * d + kr + (r.width() - 6 * d - 2 * kr) * pos
        c.drawCircle(cx, r.centerY(), kr, knobP)
    }
}

/** Continent groups for the location filter. */
object Regions {
    val names = listOf("All", "Asia", "Europe", "Americas", "Africa", "Oceania")
    private val asia = "AE AF AM AZ BD BH BN BT CN GE HK ID IL IN IQ IR JO JP KG KH KP KR KW KZ LA LB LK MM MN MO MV MY NP OM PH PK PS QA SA SG SY TH TJ TL TM TR TW UZ VN YE".split(" ").toSet()
    private val europe = "AD AL AT AX BA BE BG BY CH CY CZ DE DK EE ES FI FO FR GB GG GI GR HR HU IE IM IS IT JE LI LT LU LV MC MD ME MK MT NL NO PL PT RO RS RU SE SI SJ SK SM UA VA XK".split(" ").toSet()
    private val africa = "AO BF BI BJ BW CD CF CG CI CM CV DJ DZ EG EH ER ET GA GH GM GN GQ GW KE KM LR LS LY MA MG ML MR MU MW MZ NA NE NG RE RW SC SD SH SL SN SO SS ST SZ TD TG TN TZ UG YT ZA ZM ZW".split(" ").toSet()
    private val oceania = "AS AU CK FJ FM GU KI MH MP NC NF NR NU NZ PF PG PN PW SB TK TO TV UM VU WF WS".split(" ").toSet()
    private val americas = "AG AI AR AW BB BL BM BO BQ BR BS BZ CA CL CO CR CU CW DM DO EC FK GD GF GL GP GT GY HN HT JM KN KY LC MF MQ MS MX NI PA PE PM PR PY SR SV SX TC TT US UY VC VE VG VI".split(" ").toSet()

    fun of(region: String, cc: String): Boolean = when (region) {
        "Asia" -> cc in asia
        "Europe" -> cc in europe
        "Americas" -> cc in americas
        "Africa" -> cc in africa
        "Oceania" -> cc in oceania
        else -> true
    }
}
