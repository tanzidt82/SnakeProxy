package com.snake.proxy

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatTextView
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min

/** Accent colours used by glowing cards. */
object GlowColors {
    val BLUE = Color.rgb(60, 140, 255)
    val ORANGE = Color.rgb(255, 120, 40)
    val GREEN = Color.rgb(40, 220, 110)
    val PURPLE = Color.rgb(170, 80, 255)
    val RED = Color.rgb(255, 70, 100)
    val AMBER = Color.rgb(245, 165, 36)
    val CYCLE = listOf(ORANGE, BLUE, PURPLE, GREEN)

    fun night(ctx: Context) =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
}

/**
 * Raised card in the same "key" style as the home screen: a face sitting on a thicker edge.
 * When [glowOn] the card shows its state colour as a thin line along the bottom edge and a
 * soft tint at the bottom of the face (e.g. red = offline, blue = selected).
 */
class GlowDrawable(
    ctx: Context,
    color: Int,
    var soft: Boolean,
    private val radius: Float
) : Drawable(), Animatable {

    private val d = ctx.resources.displayMetrics.density
    private val night = GlowColors.night(ctx)
    val depth = 5f * d

    /** Thicker accent border (selected chips). */
    var accentBorder = false
        set(v) { field = v; invalidateSelf() }

    var color: Int = color
        set(v) { if (field != v) { field = v; lastH = -1f; invalidateSelf() } }

    /** When false the card is drawn plain (no state colour). */
    var glowOn = true
        set(v) { if (field != v) { field = v; lastH = -1f; invalidateSelf() } }

    private val face = RectF()
    private val tmp = RectF()
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val faceP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hlP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tintP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var lastH = -1f

    private fun alpha(c: Int, a: Float) = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun paints() {
        faceP.shader = LinearGradient(0f, face.top, 0f, face.bottom,
            if (night) Color.rgb(27, 39, 68) else Color.WHITE,
            if (night) Color.rgb(18, 27, 48) else Color.rgb(243, 246, 252), Shader.TileMode.CLAMP)
        edgeP.color = if (night) Color.rgb(10, 16, 32) else Color.rgb(213, 222, 238)
        // bottom rim: state colour when glowing; in dark mode a blue line by default (style C)
        rimP.color = when {
            glowOn -> alpha(color, if (night) 0.85f else 0.75f)
            night -> Color.argb(140, 91, 155, 255)
            else -> Color.rgb(213, 222, 238)
        }
        hlP.color = if (night) Color.argb(31, 255, 255, 255) else Color.WHITE
        tintP.shader = if (glowOn) LinearGradient(0f, face.bottom - face.height() * 0.45f, 0f, face.bottom,
            Color.TRANSPARENT, alpha(color, if (night) 0.16f else 0.10f), Shader.TileMode.CLAMP) else null
        borderP.strokeWidth = if (glowOn && accentBorder) 1.6f * d else d
        borderP.color = when {
            glowOn && accentBorder -> alpha(color, 0.7f)
            night -> Color.argb(18, 255, 255, 255)
            else -> Color.argb(16, 20, 40, 90)
        }
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val r = min(radius, (b.height() - depth) / 2f).coerceAtLeast(0f)
        face.set(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom - depth)
        if (face.height() + face.width() * 7f != lastH) { lastH = face.height() + face.width() * 7f; paints() }
        tmp.set(face.left, face.top + depth, face.right, b.bottom.toFloat())
        c.drawRoundRect(tmp, r, r, rimP)                       // coloured line under the edge
        tmp.bottom -= 1.4f * d
        c.drawRoundRect(tmp, r, r, edgeP)                      // the thickness
        c.drawRoundRect(face, r, r, hlP)                       // top highlight
        tmp.set(face.left, face.top + 1.4f * d, face.right, face.bottom)
        c.drawRoundRect(tmp, r, r, faceP)
        if (tintP.shader != null) c.drawRoundRect(tmp, r, r, tintP)
        tmp.set(face.left + d / 2, face.top + d / 2, face.right - d / 2, face.bottom - d / 2)
        c.drawRoundRect(tmp, r, r, borderP)
    }

    // Static now (no endless redraws = less battery); kept Animatable for existing callers.
    override fun start() {}
    override fun stop() {}
    override fun isRunning() = false

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT

    override fun getOutline(outline: android.graphics.Outline) {
        outline.setRoundRect(bounds.left, bounds.top + depth.toInt(), bounds.right, bounds.bottom, min(radius, bounds.height() / 2f))
        outline.alpha = 0.9f
    }
}

/** Shared setup for every glowing view. */
internal object GlowSupport {
    fun init(v: View, attrs: AttributeSet?): GlowDrawable {
        val ctx = v.context
        val a = ctx.obtainStyledAttributes(attrs, R.styleable.Glow)
        val color = a.getColor(R.styleable.Glow_glowColor, GlowColors.BLUE)
        val soft = a.getBoolean(R.styleable.Glow_glowSoft, false)
        val radius = a.getDimension(R.styleable.Glow_glowRadius, 24 * ctx.resources.displayMetrics.density)
        val enabled = a.getBoolean(R.styleable.Glow_glowEnabled, true)
        val shadow = a.getBoolean(R.styleable.Glow_glowShadow, true)
        a.recycle()
        val g = GlowDrawable(ctx, color, soft, radius)
        g.glowOn = enabled
        v.background = g
        v.clipToOutline = false
        v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, v.paddingBottom + g.depth.toInt())
        if (shadow) {
            v.elevation = 5 * ctx.resources.displayMetrics.density
            applyShadow(v, color, enabled)
        }
        return g
    }

    fun applyShadow(v: View, color: Int, on: Boolean) {
        if (Build.VERSION.SDK_INT >= 28) {
            val night = GlowColors.night(v.context)
            val c = if (on) color else if (night) Color.BLACK else Color.rgb(30, 60, 130)
            v.outlineSpotShadowColor = c
            v.outlineAmbientShadowColor = c
        }
    }
}

interface Glowing {
    val glow: GlowDrawable
    fun setGlow(color: Int, on: Boolean = true) {
        glow.color = color
        glow.glowOn = on
        GlowSupport.applyShadow(this as View, color, on)
    }
}

class GlowLayout @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : LinearLayout(ctx, attrs), Glowing {
    override val glow: GlowDrawable = GlowSupport.init(this, attrs)
}

class GlowFrame @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs), Glowing {
    override val glow: GlowDrawable = GlowSupport.init(this, attrs)
}

class GlowText @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : AppCompatTextView(ctx, attrs), Glowing {
    override val glow: GlowDrawable = GlowSupport.init(this, attrs)
}

/** Connection ring: track, glowing gradient arc, rotating sheen; spins while connecting. */
class RingView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    companion object { const val OFF = 0; const val CONNECTING = 1; const val ON = 2 }

    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val oval = RectF()
    private var rot = 0f
    private var shown = 0f
    private var colorA = Color.rgb(91, 224, 255)
    private var colorB = Color.rgb(26, 125, 255)

    var state = OFF
        set(v) { if (field != v) { field = v; animateTo(if (v == ON) progress else if (v == CONNECTING) 0.28f else 0f); setColors(); invalidate() } }

    /** Fraction of the ring that is filled when ON (0..1). */
    var progress = 1f
        set(v) { field = v.coerceIn(0f, 1f); if (state == ON) animateTo(field) }

    private val spinner = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { rot = it.animatedValue as Float; invalidate() }
    }
    private var fill: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        track.color = if (GlowColors.night(ctx)) Color.argb(38, 120, 160, 230) else Color.argb(30, 40, 80, 160)
    }

    private fun setColors() {
        if (state == CONNECTING) { colorA = Color.rgb(255, 205, 110); colorB = GlowColors.AMBER }
        else { colorA = Color.rgb(91, 224, 255); colorB = Color.rgb(26, 125, 255) }
        updateShader()
    }

    private fun animateTo(target: Float) {
        fill?.cancel()
        fill = ValueAnimator.ofFloat(shown, target).apply {
            duration = 900
            interpolator = android.view.animation.DecelerateInterpolator(1.6f)
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun updateShader() {
        if (width == 0) return
        val cx = width / 2f; val cy = height / 2f
        arc.shader = SweepGradient(cx, cy, intArrayOf(colorA, colorB, colorA), floatArrayOf(0f, 0.5f, 1f))
        glowP.shader = arc.shader
        sheen.shader = SweepGradient(cx, cy,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(230, 220, 240, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 0.72f, 0.97f, 1f))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val sw = min(w, h) * 0.064f
        val pad = sw * 2.2f
        oval.set(pad, pad, w - pad, h - pad)
        track.strokeWidth = sw
        arc.strokeWidth = sw
        sheen.strokeWidth = sw * 0.7f
        glowP.strokeWidth = sw * 1.6f
        glowP.maskFilter = BlurMaskFilter(sw * 1.6f, BlurMaskFilter.Blur.NORMAL)
        updateShader()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); spinner.start() }
    override fun onDetachedFromWindow() { spinner.cancel(); fill?.cancel(); super.onDetachedFromWindow() }
    // stop drawing while the app is in the background (saves battery, avoids work while hidden)
    override fun onWindowVisibilityChanged(v: Int) { super.onWindowVisibilityChanged(v); if (v == VISIBLE) { if (!spinner.isStarted) spinner.start() } else spinner.cancel() }

    private val scan = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.argb(190, 91, 155, 255) }

    override fun onDraw(c: Canvas) {
        c.drawOval(oval, track)
        if (state == OFF && shown <= 0.02f) {
            // idle: a short arc keeps circling the ring
            scan.strokeWidth = track.strokeWidth
            c.drawArc(oval, rot * 1.4f - 90f, 46f, false, scan)
            return
        }
        if (shown <= 0.001f) return
        val start = if (state == CONNECTING) rot - 90f else -90f
        val sweep = 360f * shown
        c.save()
        c.rotate(if (state == CONNECTING) rot else 0f, width / 2f, height / 2f)
        glowP.alpha = if (state == ON) (90 + 150 * ((1 - cos(rot / 180f * PI)) / 2)).toInt() else 150
        c.drawArc(oval, -90f, sweep, false, glowP)
        c.drawArc(oval, -90f, sweep, false, arc)
        c.restore()
        if (state == ON && shown > 0.98f) {
            c.save()
            c.rotate(rot * 1.4f, width / 2f, height / 2f)
            c.drawArc(oval, 0f, 360f, false, sheen)
            c.restore()
        }
        if (start < -1000f) invalidate()
    }
}

/** Small animated on/off switch. */
class ToggleView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val d = resources.displayMetrics.density
    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knobP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(2 * d, 0f, d, Color.argb(60, 0, 0, 0)) }
    private val r = RectF()
    private var pos = 0f
    private val offColor = androidx.core.content.ContextCompat.getColor(ctx, R.color.knob_off)

    var onChange: ((Boolean) -> Unit)? = null
    private var anim: ValueAnimator? = null
    private var instant = false
    var isChecked = false
        set(v) {
            if (field == v) return
            field = v
            anim?.cancel()
            if (instant) { pos = if (v) 1f else 0f; invalidate(); return }
            anim = ValueAnimator.ofFloat(pos, if (v) 1f else 0f).apply {
                duration = 220
                addUpdateListener { pos = it.animatedValue as Float; invalidate() }
                start()
            }
        }

    fun setCheckedNow(v: Boolean) {
        instant = true
        isChecked = v
        instant = false
        anim?.cancel()
        pos = if (v) 1f else 0f
        invalidate()
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        isFocusable = true
        setOnClickListener { isChecked = !isChecked; onChange?.invoke(isChecked) }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((50 * d).toInt(), (30 * d).toInt())

    private fun mix(a: Int, b: Int, f: Float) = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * f).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
    )

    override fun onDraw(c: Canvas) {
        r.set(d, d, width - d, height - d)
        trackP.color = mix(offColor, GlowColors.BLUE, pos)
        c.drawRoundRect(r, r.height() / 2, r.height() / 2, trackP)
        val kr = r.height() / 2 - 3 * d
        val cx = r.left + 3 * d + kr + (r.width() - 6 * d - 2 * kr) * pos
        c.drawCircle(cx, r.centerY(), kr, knobP)
    }
}

/** Continent groups for the location filter. */
object Regions {
    val names = listOf("All", "Asia", "Europe", "Americas", "Africa", "Oceania")
    private val asia = "AE AF AM AZ BD BH BN BT CN GE HK ID IL IN IQ IR JO JP KG KH KP KR KW KZ LA LB LK MM MN MO MV MY NP OM PH PK PS QA SA SG SY TH TJ TL TM TR TW UZ VN YE".split(" ").toSet()
    private val europe = "AD AL AT AX BA BE BG BY CH CY CZ DE DK EE ES FI FO FR GB GG GI GR HR HU IE IM IS IT JE LI LT LU LV MC MD ME MK MT NL NO PL PT RO RS RU SE SI SJ SK SM UA VA XK".split(" ").toSet()
    private val africa = "AO BF BI BJ BW CD CF CG CI CM CV DJ DZ EG EH ER ET GA GH GM GN GQ GW KE KM LR LS LY MA MG ML MR MU MW MZ NA NE NG RE RW SC SD SH SL SN SO SS ST SZ TD TG TN TZ UG YT ZA ZM ZW".split(" ").toSet()
    private val oceania = "AS AU CK FJ FM GU KI MH MP NC NF NR NU NZ PF PG PN PW SB TK TO TV UM VU WF WS".split(" ").toSet()
    private val americas = "AG AI AR AW BB BL BM BO BQ BR BS BZ CA CL CO CR CU CW DM DO EC FK GD GF GL GP GT GY HN HT JM KN KY LC MF MQ MS MX NI PA PE PM PR PY SR SV SX TC TT US UY VC VE VG VI".split(" ").toSet()

    fun of(region: String, cc: String): Boolean = when (region) {
        "Asia" -> cc in asia
        "Europe" -> cc in europe
        "Americas" -> cc in americas
        "Africa" -> cc in africa
        "Oceania" -> cc in oceania
        else -> true
    }
}

/**
 * Raised 3D "key" surface: a face with a darker edge underneath, like a physical button.
 * The face sinks into the edge while pressed. Optional light sweep across the face.
 */
class KeyDrawable(ctx: Context, blue: Boolean, private val radius: Float, private val shine: Boolean = false) : Drawable(), Animatable {
    private val d = ctx.resources.displayMetrics.density
    private val night = GlowColors.night(ctx)
    val maxDepth = 5f * d
    private val minDepth = 1.2f * d

    /** 0 = resting, 1 = fully pressed. */
    var press = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidateSelf() }

    var blue: Boolean = blue
        set(v) { if (field != v) { field = v; lastH = -1f; invalidateSelf() } }

    private val face = RectF()
    private val tmp = RectF()
    private val facePath = Path()
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val faceP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hlP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shineP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val litP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastH = -1f
    private var sweep = 0f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { sweep = it.animatedValue as Float; invalidateSelf() }
    }

    private fun shaders(top: Float, bottom: Float) {
        val (a, b) = when {
            blue -> Color.rgb(91, 155, 255) to Color.rgb(47, 107, 240)
            night -> Color.rgb(27, 39, 68) to Color.rgb(18, 27, 48)
            else -> Color.WHITE to Color.rgb(243, 246, 252)
        }
        faceP.shader = LinearGradient(0f, top, 0f, bottom, a, b, Shader.TileMode.CLAMP)
        edgeP.color = when { blue -> Color.rgb(28, 63, 158); night -> Color.rgb(10, 16, 32); else -> Color.rgb(213, 222, 238) }
        hlP.color = when { blue -> Color.argb(110, 255, 255, 255); night -> Color.argb(30, 255, 255, 255); else -> Color.WHITE }
        borderP.color = when { blue -> Color.TRANSPARENT; night -> Color.argb(28, 140, 175, 255); else -> Color.argb(16, 20, 40, 90) }
        borderP.strokeWidth = d
        rimP.color = if (night && !blue) Color.argb(140, 91, 155, 255) else Color.TRANSPARENT
        litP.shader = null
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val depth = maxDepth - (maxDepth - minDepth) * press
        val sink = maxDepth - depth
        val r = min(radius, (b.height() - maxDepth) / 2f)
        face.set(b.left.toFloat(), b.top + sink, b.right.toFloat(), b.bottom - depth)
        if (face.height() + face.top * 1000f != lastH) { lastH = face.height() + face.top * 1000f; shaders(face.top, face.bottom) }
        // edge (the visible "thickness")
        tmp.set(face.left, face.top + maxDepth, face.right, b.bottom.toFloat())
        if (rimP.color != Color.TRANSPARENT) {          // dark mode: thin blue line under each card
            c.drawRoundRect(tmp, r, r, rimP)
            tmp.bottom -= 1.4f * d
        }
        c.drawRoundRect(tmp, r, r, edgeP)
        // top highlight, then face slightly lower so a bright line shows on top
        c.drawRoundRect(face, r, r, hlP)
        tmp.set(face.left, face.top + 1.4f * d, face.right, face.bottom)
        c.drawRoundRect(tmp, r, r, faceP)
        if (litP.shader != null) c.drawRoundRect(tmp, r, r, litP)
        tmp.set(face.left + d / 2, face.top + d / 2, face.right - d / 2, face.bottom - d / 2)
        c.drawRoundRect(tmp, r, r, borderP)
        if (shine && sweep < 0.62f) {
            val t = sweep / 0.62f
            val w = face.width()
            val x = face.left - w * 0.6f + (w * 1.9f) * t
            val band = w * 0.22f
            shineP.shader = LinearGradient(x - band, face.top, x + band, face.bottom,
                intArrayOf(Color.TRANSPARENT, if (night || blue) Color.argb(30, 255, 255, 255) else Color.argb(170, 255, 255, 255), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP)
            facePath.reset()
            facePath.addRoundRect(face, r, r, Path.Direction.CW)
            c.save(); c.clipPath(facePath); c.drawRect(face, shineP); c.restore()
        }
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        if (visible) start() else stop()
        return changed
    }
    override fun start() { if (shine && !anim.isStarted) anim.start() }
    override fun stop() { anim.cancel() }
    override fun isRunning() = anim.isRunning
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
    override fun getOutline(outline: android.graphics.Outline) {
        val r = min(radius, bounds.height() / 2f)
        outline.setRoundRect(bounds.left, bounds.top + (maxDepth).toInt(), bounds.right, bounds.bottom, r)
        outline.alpha = 0.9f
    }
}

/** LinearLayout on a [KeyDrawable]; its content sinks with the face when pressed and can gently float. */
class KeyLayout @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : LinearLayout(ctx, attrs) {
    val key: KeyDrawable
    private val dp = resources.displayMetrics.density
    private var floatAmp = 0f
    private var floatY = 0f
    private var pressAnim: ValueAnimator? = null
    private var wasPressed = false
    private val floater = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        val off = Math.random().toFloat()
        addUpdateListener {
            val f = ((it.animatedValue as Float) + off) % 1f
            floatY = -floatAmp * ((1 - cos(2 * PI * f)) / 2).toFloat()
            translationY = floatY
        }
    }

    init {
        val a = ctx.obtainStyledAttributes(attrs, R.styleable.Key)
        val blue = a.getBoolean(R.styleable.Key_keyBlue, false)
        val radius = a.getDimension(R.styleable.Key_keyRadius, 22 * dp)
        val shine = a.getBoolean(R.styleable.Key_keyShine, false)
        floatAmp = if (a.getBoolean(R.styleable.Key_keyFloat, false)) 3 * dp else 0f
        a.recycle()
        key = KeyDrawable(ctx, blue, radius, shine)
        background = key
        setPadding(paddingLeft, paddingTop, paddingRight, paddingBottom + key.maxDepth.toInt())
        if (elevation == 0f) elevation = 5 * dp
        tint()
    }

    private fun tint() {
        if (Build.VERSION.SDK_INT >= 28) {
            val c = if (key.blue) GlowColors.BLUE else if (GlowColors.night(context)) Color.BLACK else Color.rgb(30, 60, 130)
            outlineSpotShadowColor = c; outlineAmbientShadowColor = c
        }
    }

    fun setBlue(on: Boolean) { key.blue = on; tint() }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        if (pressed == wasPressed) return
        wasPressed = pressed
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(key.press, if (pressed) 1f else 0f).apply {
            duration = if (pressed) 90 else 220
            addUpdateListener {
                val f = it.animatedValue as Float
                key.press = f
                val dy = (key.maxDepth - 1.2f * dp) * f
                for (i in 0 until childCount) getChildAt(i).translationY = dy
            }
            start()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (floatAmp > 0) floater.start() }
    override fun onDetachedFromWindow() { floater.cancel(); pressAnim?.cancel(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) { super.onWindowVisibilityChanged(v); if (floatAmp > 0) { if (v == VISIBLE) { if (!floater.isStarted) floater.start() } else floater.cancel() } }
}

/** Rings that spread out from the centre and fade, e.g. around the power button or the add tile. */
class WaveView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val dp = resources.displayMetrics.density
    private val inset: Float
    private val corner: Float
    private val count: Int
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * resources.displayMetrics.density }
    private val r = RectF()
    private var t = 0f
    var color: Int = GlowColors.BLUE
        set(v) { field = v; invalidate() }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    init {
        val a = ctx.obtainStyledAttributes(attrs, R.styleable.WaveView)
        inset = a.getDimension(R.styleable.WaveView_waveInset, 0f)
        corner = a.getDimension(R.styleable.WaveView_waveCorner, -1f)
        count = a.getInt(R.styleable.WaveView_waveCount, 2)
        color = a.getColor(R.styleable.WaveView_waveColor, GlowColors.BLUE)
        a.recycle()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) { super.onWindowVisibilityChanged(v); if (v == VISIBLE) { if (!anim.isStarted) anim.start() } else anim.cancel() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val bw = width / 2f - inset; val bh = height / 2f - inset
        if (bw <= 0 || bh <= 0) return
        val maxGrow = min(inset, min(bw, bh) * 0.6f)
        for (i in 0 until count) {
            val f = (t + i.toFloat() / count) % 1f
            val g = maxGrow * f
            r.set(cx - bw - g, cy - bh - g, cx + bw + g, cy + bh + g)
            p.color = Color.argb((200 * (1 - f) * (1 - f)).toInt(), Color.red(color), Color.green(color), Color.blue(color))
            if (corner < 0) c.drawOval(r, p) else c.drawRoundRect(r, corner + g, corner + g, p)
        }
    }
}

/** Small looping effects used across screens. */
object Fx {
    /** Gentle scale "heartbeat". */
    fun pulse(v: View, to: Float = 1.12f, ms: Long = 1000) {
        (v.getTag(R.id.fx_anim) as? android.animation.Animator)?.cancel()
        val a = android.animation.ObjectAnimator.ofPropertyValuesHolder(v,
            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, to),
            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, to)).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
        }
        v.setTag(R.id.fx_anim, a)
        a.start()
    }

    /** Up/down drift. */
    fun bob(v: View, dy: Float, ms: Long = 2000) {
        android.animation.ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, 0f, -dy).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            start()
        }
    }

    /** Fades between two alphas forever. */
    fun breathe(v: View, from: Float, to: Float, ms: Long = 1500) {
        android.animation.ObjectAnimator.ofFloat(v, View.ALPHA, from, to).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    /** Endless rotation; [reverse] spins the other way (used to keep orbiting items upright). */
    fun spin(v: View, ms: Long, reverse: Boolean = false) {
        android.animation.ObjectAnimator.ofFloat(v, View.ROTATION, 0f, if (reverse) -360f else 360f).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
    }

    /** Slowly shifts the hue/brightness of an image back and forth (wordmark colour flow). */
    fun hueFlow(iv: android.widget.ImageView, ms: Long = 3000) {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                iv.colorFilter = android.graphics.ColorMatrixColorFilter(hue(-25f * f, 1f + 0.15f * f))
            }
            start()
        }
    }

    private fun hue(deg: Float, bright: Float): android.graphics.ColorMatrix {
        val a = Math.toRadians(deg.toDouble())
        val c = cos(a).toFloat(); val s = kotlin.math.sin(a).toFloat()
        val lr = 0.213f; val lg = 0.715f; val lb = 0.072f
        val m = floatArrayOf(
            lr + c * (1 - lr) + s * (-lr), lg + c * (-lg) + s * (-lg), lb + c * (-lb) + s * (1 - lb), 0f, 0f,
            lr + c * (-lr) + s * 0.143f, lg + c * (1 - lg) + s * 0.140f, lb + c * (-lb) + s * (-0.283f), 0f, 0f,
            lr + c * (-lr) + s * (-(1 - lr)), lg + c * (-lg) + s * lg, lb + c * (1 - lb) + s * lb, 0f, 0f,
            0f, 0f, 0f, 1f, 0f)
        val cm = android.graphics.ColorMatrix(m)
        cm.postConcat(android.graphics.ColorMatrix().apply { setScale(bright, bright, bright, 1f) })
        return cm
    }
}
