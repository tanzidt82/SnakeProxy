package com.snake.proxy

import android.os.SystemClock
import android.util.Base64
import java.io.DataInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.Collections
import java.util.concurrent.Executors

/** Opens a TCP connection to host:port through the proxy (SOCKS5 or HTTP CONNECT). */
object ProxyDialer {
    private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

    fun open(p: ProxyProfile, host: String, port: Int, timeout: Int = 8000): Socket {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.soTimeout = timeout
            s.connect(InetSocketAddress(p.host, p.port), timeout)
            if (p.type == "HTTP") httpConnect(s, p, host, port) else socksConnect(s, p, host, port)
            s.soTimeout = 0
            return s
        } catch (e: Exception) {
            try { s.close() } catch (ignored: Exception) {}
            throw e
        }
    }

    private fun socksConnect(s: Socket, p: ProxyProfile, host: String, port: Int) {
        val o = s.getOutputStream()
        val i = DataInputStream(s.getInputStream())
        val auth = p.user.isNotEmpty()
        o.write(if (auth) byteArrayOf(5, 2, 0, 2) else byteArrayOf(5, 1, 0))
        o.flush()
        if (i.readUnsignedByte() != 5) throw Exception("Not a SOCKS5 proxy")
        when (i.readUnsignedByte()) {
            0 -> {}
            2 -> {
                val u = p.user.toByteArray()
                val pw = p.pass.toByteArray()
                val b = ByteArray(3 + u.size + pw.size)
                b[0] = 1; b[1] = u.size.toByte()
                System.arraycopy(u, 0, b, 2, u.size)
                b[2 + u.size] = pw.size.toByte()
                System.arraycopy(pw, 0, b, 3 + u.size, pw.size)
                o.write(b); o.flush()
                i.readUnsignedByte()
                if (i.readUnsignedByte() != 0) throw Exception("Wrong username or password")
            }
            else -> throw Exception(if (auth) "Proxy rejected the login" else "Proxy requires username and password")
        }
        val req = ArrayList<Byte>()
        req.addAll(listOf<Byte>(5, 1, 0))
        when {
            ipv4.matches(host) -> {
                req.add(1); InetAddress.getByName(host).address.forEach { req.add(it) }
            }
            host.contains(":") -> {
                req.add(4); InetAddress.getByName(host).address.forEach { req.add(it) }
            }
            else -> {
                val h = host.toByteArray()
                req.add(3); req.add(h.size.toByte()); h.forEach { req.add(it) }
            }
        }
        req.add((port shr 8).toByte()); req.add((port and 0xff).toByte())
        o.write(req.toByteArray()); o.flush()
        i.readUnsignedByte()
        val rep = i.readUnsignedByte()
        i.readUnsignedByte()
        when (i.readUnsignedByte()) {
            1 -> i.readFully(ByteArray(4))
            3 -> i.readFully(ByteArray(i.readUnsignedByte()))
            4 -> i.readFully(ByteArray(16))
        }
        i.readUnsignedShort()
        if (rep != 0) throw Exception("Proxy could not reach the target (code $rep)")
    }

    private fun httpConnect(s: Socket, p: ProxyProfile, host: String, port: Int) {
        val target = (if (host.contains(":")) "[$host]" else host) + ":" + port
        val sb = StringBuilder("CONNECT $target HTTP/1.1\r\nHost: $target\r\n")
        if (p.user.isNotEmpty()) {
            val token = Base64.encodeToString("${p.user}:${p.pass}".toByteArray(), Base64.NO_WRAP)
            sb.append("Proxy-Authorization: Basic $token\r\n")
        }
        sb.append("Proxy-Connection: Keep-Alive\r\n\r\n")
        s.getOutputStream().apply { write(sb.toString().toByteArray()); flush() }
        val head = readHeader(s.getInputStream())
        val code = head.lineSequence().firstOrNull()?.split(" ")?.getOrNull(1)?.toIntOrNull() ?: 0
        when {
            code == 200 -> {}
            code == 407 -> throw Exception("Wrong username or password (407)")
            code == 0 -> throw Exception("Not an HTTP proxy")
            else -> throw Exception("Proxy refused the request (code $code)")
        }
    }

    private fun readHeader(i: InputStream): String {
        val buf = StringBuilder()
        while (buf.length < 16384) {
            val c = i.read()
            if (c < 0) break
            buf.append(c.toChar())
            if (buf.endsWith("\r\n\r\n")) break
        }
        return buf.toString()
    }
}

/** Proxy test: login + latency + exit IP */
object ProxyTester {
    data class Result(val ok: Boolean, val ms: Long, val ip: String, val error: String)

    fun test(p: ProxyProfile): Result {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            ProxyDialer.open(p, "api.ipify.org", 80).use { s ->
                val ms = SystemClock.elapsedRealtime() - t0
                s.soTimeout = 10000
                s.getOutputStream().write(
                    "GET / HTTP/1.0\r\nHost: api.ipify.org\r\nUser-Agent: FleetProxy\r\nConnection: close\r\n\r\n".toByteArray()
                )
                val resp = s.getInputStream().readBytes().toString(Charsets.UTF_8)
                val ip = resp.substringAfter("\r\n\r\n", "").trim()
                Result(true, ms, ip, "")
            }
        } catch (e: Exception) {
            Result(false, 0, "", e.message ?: e.javaClass.simpleName)
        }
    }

    /** Real IP without proxy (this app itself stays outside the VPN) */
    fun directIp(): String = try {
        val c = URL("https://api.ipify.org").openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.inputStream.bufferedReader().use { it.readText().trim() }
    } catch (e: Exception) {
        "Unknown"
    }
}

/**
 * Local SOCKS5 server (127.0.0.1) used for HTTP proxies.
 * The engine talks SOCKS5 to it, and it forwards via HTTP CONNECT.
 * UDP is not supported, so UDP is blocked (no IP leak).
 */
class HttpBridge(private val p: ProxyProfile) {
    private val server = ServerSocket(0, 256, InetAddress.getByName("127.0.0.1"))
    private val pool = Executors.newCachedThreadPool()
    private val sockets: MutableSet<Socket> = Collections.synchronizedSet(HashSet())
    @Volatile private var alive = true
    val port: Int get() = server.localPort

    fun start(): HttpBridge {
        pool.execute {
            while (alive) {
                val c = try { server.accept() } catch (e: Exception) { break }
                pool.execute { handle(c) }
            }
        }
        return this
    }

    fun stop() {
        alive = false
        try { server.close() } catch (ignored: Exception) {}
        synchronized(sockets) { sockets.forEach { try { it.close() } catch (ignored: Exception) {} } }
        pool.shutdownNow()
    }

    private fun reply(code: Int) = byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0)

    private fun handle(c: Socket) {
        var up: Socket? = null
        sockets.add(c)
        try {
            c.tcpNoDelay = true
            c.soTimeout = 15000
            val i = DataInputStream(c.getInputStream())
            val o = c.getOutputStream()
            if (i.readUnsignedByte() != 5) return
            i.readFully(ByteArray(i.readUnsignedByte()))
            o.write(byteArrayOf(5, 0)); o.flush()
            i.readUnsignedByte()
            val cmd = i.readUnsignedByte()
            i.readUnsignedByte()
            val host = when (i.readUnsignedByte()) {
                1 -> ByteArray(4).also { i.readFully(it) }.let { InetAddress.getByAddress(it).hostAddress!! }
                3 -> ByteArray(i.readUnsignedByte()).also { i.readFully(it) }.let { String(it) }
                4 -> ByteArray(16).also { i.readFully(it) }.let { InetAddress.getByAddress(it).hostAddress!! }
                else -> return
            }
            val port = i.readUnsignedShort()
            if (cmd != 1) { o.write(reply(7)); return }
            val u: Socket = try {
                ProxyDialer.open(p, host, port)
            } catch (e: Exception) {
                o.write(reply(5)); return
            }
            up = u
            sockets.add(u)
            o.write(reply(0)); o.flush()
            c.soTimeout = 0
            pool.execute {
                pipe(c.getInputStream(), u.getOutputStream())
                try { u.shutdownOutput() } catch (ignored: Exception) {}
            }
            pipe(u.getInputStream(), o)
        } catch (ignored: Exception) {
        } finally {
            try { c.close() } catch (ignored: Exception) {}
            try { up?.close() } catch (ignored: Exception) {}
            sockets.remove(c); up?.let { sockets.remove(it) }
        }
    }

    private fun pipe(i: InputStream, o: OutputStream) {
        val buf = ByteArray(32 * 1024)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (ignored: Exception) {}
    }
}

/** Fetch proxy list from a subscription URL (your VPS / bot) */
object SubSync {
    @Volatile var lastSync = 0L

    private fun key(p: ProxyProfile) = "${p.type}|${p.host}|${p.port}|${p.user}"

    fun sync(): Result<Int> = runCatching {
        val url = Store.subUrl.trim()
        require(url.isNotEmpty()) { "No subscription URL set" }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "FleetProxy")
        val text = c.inputStream.bufferedReader().use { it.readText() }
        val parsed = ProxyParser.parseAll(text, "SOCKS5")
        require(parsed.isNotEmpty()) { "No proxies found at that URL" }
        val old = Store.profiles()
        val oldSub = old.filter { it.fromSub }.associateBy { key(it) }
        val newSub = parsed.map { np ->
            oldSub[key(np)]?.copy(pass = np.pass) ?: np.copy(fromSub = true)
        }
        Store.saveProfiles(old.filter { !it.fromSub } + newSub)
        lastSync = System.currentTimeMillis()
        AppLog.add("Synced ${newSub.size} proxies")
        newSub.size
    }.onFailure { AppLog.add("Sync failed: ${it.message}") }
}
