package com.snake.proxy

import android.os.SystemClock
import android.util.Base64
import java.io.Closeable
import java.io.DataInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketAddress
import java.net.URL
import java.util.Collections
import java.util.concurrent.Executors

/** Opens connections through the upstream proxy (SOCKS5 or HTTP CONNECT). */
object ProxyDialer {
    private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
    private val dns = java.util.concurrent.ConcurrentHashMap<String, Pair<InetAddress, Long>>()

    /** Proxy host lookups are cached (Android only caches DNS for ~2 s, which slowed every connection). */
    fun resolve(host: String): InetAddress {
        val now = SystemClock.elapsedRealtime()
        dns[host]?.let { if (now - it.second < 300_000) return it.first }
        val a = InetAddress.getByName(host)
        dns[host] = Pair(a, now)
        return a
    }

    private fun connectTo(s: Socket, p: ProxyProfile, timeout: Int) {
        try {
            s.connect(InetSocketAddress(resolve(p.host), p.port), timeout)
        } catch (e: Exception) {
            dns.remove(p.host)              // IP may have changed: look it up again next time
            throw e
        }
    }

    fun open(p: ProxyProfile, host: String, port: Int, timeout: Int = 8000): Socket {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.soTimeout = timeout
            connectTo(s, p, timeout)
            if (p.type == "HTTP") httpConnect(s, p, host, port) else socksConnect(s, p, host, port)
            s.soTimeout = 0
            return s
        } catch (e: Exception) {
            try { s.close() } catch (ignored: Exception) {}
            throw e
        }
    }

    /**
     * SOCKS5 UDP ASSOCIATE on the upstream proxy.
     * Returns the control socket (keep it open) and the proxy's UDP relay address.
     */
    fun udpAssociate(p: ProxyProfile, timeout: Int = 8000): Pair<Socket, InetSocketAddress> {
        val s = Socket()
        try {
            s.soTimeout = timeout
            connectTo(s, p, timeout)
            val i = DataInputStream(s.getInputStream())
            val o = s.getOutputStream()
            socksHello(i, o, p)
            o.write(byteArrayOf(5, 3, 0, 1, 0, 0, 0, 0, 0, 0)); o.flush()
            i.readUnsignedByte()
            val rep = i.readUnsignedByte()
            i.readUnsignedByte()
            val addr: InetAddress = when (i.readUnsignedByte()) {
                1 -> InetAddress.getByAddress(ByteArray(4).also { i.readFully(it) })
                4 -> InetAddress.getByAddress(ByteArray(16).also { i.readFully(it) })
                3 -> InetAddress.getByName(String(ByteArray(i.readUnsignedByte()).also { i.readFully(it) }))
                else -> throw Exception("Bad UDP reply")
            }
            val port = i.readUnsignedShort()
            if (rep != 0) throw Exception("Proxy does not support UDP (code $rep)")
            val relay = if (addr.isAnyLocalAddress) InetAddress.getByName(p.host) else addr
            s.soTimeout = 0
            return Pair(s, InetSocketAddress(relay, port))
        } catch (e: Exception) {
            try { s.close() } catch (ignored: Exception) {}
            throw e
        }
    }

    private fun socksHello(i: DataInputStream, o: OutputStream, p: ProxyProfile) {
        val auth = p.user.isNotEmpty()
        o.write(if (auth) byteArrayOf(5, 2, 0, 2) else byteArrayOf(5, 1, 0))
        o.flush()
        if (i.readUnsignedByte() != 5) throw Exception("Not a SOCKS5 proxy")
        when (i.readUnsignedByte()) {
            0 -> {}
            2 -> {
                val u = p.user.toByteArray()
                val pw = p.pass.toByteArray()
                val b = ByteArray(3 + u.size + pw.size)
                b[0] = 1; b[1] = u.size.toByte()
                System.arraycopy(u, 0, b, 2, u.size)
                b[2 + u.size] = pw.size.toByte()
                System.arraycopy(pw, 0, b, 3 + u.size, pw.size)
                o.write(b); o.flush()
                i.readUnsignedByte()
                if (i.readUnsignedByte() != 0) throw Exception("Wrong username or password")
            }
            else -> throw Exception(if (auth) "Proxy rejected the login" else "Proxy requires username and password")
        }
    }

    private fun socksConnect(s: Socket, p: ProxyProfile, host: String, port: Int) {
        val o = s.getOutputStream()
        val i = DataInputStream(s.getInputStream())
        socksHello(i, o, p)
        val req = ArrayList<Byte>()
        req.addAll(listOf<Byte>(5, 1, 0))
        when {
            ipv4.matches(host) -> {
                req.add(1); InetAddress.getByName(host).address.forEach { req.add(it) }
            }
            host.contains(":") -> {
                req.add(4); InetAddress.getByName(host).address.forEach { req.add(it) }
            }
            else -> {
                val h = host.toByteArray()
                req.add(3); req.add(h.size.toByte()); h.forEach { req.add(it) }
            }
        }
        req.add((port shr 8).toByte()); req.add((port and 0xff).toByte())
        o.write(req.toByteArray()); o.flush()
        i.readUnsignedByte()
        val rep = i.readUnsignedByte()
        i.readUnsignedByte()
        when (i.readUnsignedByte()) {
            1 -> i.readFully(ByteArray(4))
            3 -> i.readFully(ByteArray(i.readUnsignedByte()))
            4 -> i.readFully(ByteArray(16))
        }
        i.readUnsignedShort()
        if (rep != 0) throw Exception(socksError(rep))
    }

    private fun socksError(code: Int) = when (code) {
        1 -> "Proxy server error"
        2 -> "Blocked by proxy rules"
        3 -> "Network unreachable"
        4 -> "Host unreachable"
        5 -> "Connection refused"
        6 -> "Timed out"
        else -> "Proxy error (code $code)"
    }

    private fun httpConnect(s: Socket, p: ProxyProfile, host: String, port: Int) {
        val target = (if (host.contains(":")) "[$host]" else host) + ":" + port
        val sb = StringBuilder("CONNECT $target HTTP/1.1\r\nHost: $target\r\n")
        if (p.user.isNotEmpty()) {
            val token = Base64.encodeToString("${p.user}:${p.pass}".toByteArray(), Base64.NO_WRAP)
            sb.append("Proxy-Authorization: Basic $token\r\n")
        }
        sb.append("Proxy-Connection: Keep-Alive\r\n\r\n")
        s.getOutputStream().apply { write(sb.toString().toByteArray()); flush() }
        val head = readHeader(s.getInputStream())
        val code = head.lineSequence().firstOrNull()?.split(" ")?.getOrNull(1)?.toIntOrNull() ?: 0
        when {
            code == 200 -> {}
            code == 407 -> throw Exception("Wrong username or password (407)")
            code == 0 -> throw Exception("Not an HTTP proxy")
            else -> throw Exception("Proxy refused the request (code $code)")
        }
    }

    private fun readHeader(i: InputStream): String {
        val buf = StringBuilder()
        while (buf.length < 16384) {
            val c = i.read()
            if (c < 0) break
            buf.append(c.toChar())
            if (buf.endsWith("\r\n\r\n")) break
        }
        return buf.toString()
    }
}

/** Proxy test: login + latency + exit IP */
object ProxyTester {
    data class Result(val ok: Boolean, val ms: Long, val ip: String, val error: String)

    fun test(p: ProxyProfile): Result {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            ProxyDialer.open(p, "api.ipify.org", 80).use { s ->
                val ms = SystemClock.elapsedRealtime() - t0
                s.soTimeout = 10000
                s.getOutputStream().write(
                    "GET / HTTP/1.0\r\nHost: api.ipify.org\r\nUser-Agent: FleetProxy\r\nConnection: close\r\n\r\n".toByteArray()
                )
                val resp = s.getInputStream().readBytes().toString(Charsets.UTF_8)
                val ip = resp.substringAfter("\r\n\r\n", "").trim()
                Result(true, ms, ip, "")
            }
        } catch (e: Exception) {
            Result(false, 0, "", e.message ?: e.javaClass.simpleName)
        }
    }
}

/**
 * Local SOCKS5 server on 127.0.0.1 that the tunnel engine talks to.
 * Every connection is forwarded through the upstream proxy and reported
 * through [onConn] so the app can show per-app success / failure logs.
 * UDP is relayed for SOCKS5 upstreams; for HTTP upstreams UDP is blocked
 * (apps fall back to TCP, so the real IP never leaks).
 */
class LocalRelay(
    private val p: ProxyProfile,
    private val onConn: (host: String, port: Int, ok: Boolean, ms: Long, error: String) -> Unit
) {
    private val server = ServerSocket(0, 512, InetAddress.getByName("127.0.0.1"))
    private val pool = Executors.newCachedThreadPool()
    private val open: MutableSet<Closeable> = Collections.synchronizedSet(HashSet())
    @Volatile private var alive = true
    val port: Int get() = server.localPort

    fun start(): LocalRelay {
        pool.execute {
            while (alive) {
                val c = try { server.accept() } catch (e: Exception) { break }
                pool.execute { handle(c) }
            }
        }
        return this
    }

    fun stop() {
        alive = false
        try { server.close() } catch (ignored: Exception) {}
        synchronized(open) { open.forEach { try { it.close() } catch (ignored: Exception) {} } }
        open.clear()
        pool.shutdownNow()
    }

    private fun reply(code: Int) = byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0)

    companion object { private const val IDLE_MS = 15 * 60 * 1000 }

    private fun handle(c: Socket) {
        val owned = ArrayList<Closeable>()
        fun own(x: Closeable) { owned.add(x); open.add(x) }
        own(c)
        try {
            c.tcpNoDelay = true
            c.soTimeout = 15000
            val i = DataInputStream(c.getInputStream())
            val o = c.getOutputStream()
            if (i.readUnsignedByte() != 5) return
            i.readFully(ByteArray(i.readUnsignedByte()))
            o.write(byteArrayOf(5, 0)); o.flush()
            i.readUnsignedByte()
            val cmd = i.readUnsignedByte()
            i.readUnsignedByte()
            val host = when (i.readUnsignedByte()) {
                1 -> ByteArray(4).also { i.readFully(it) }.let { InetAddress.getByAddress(it).hostAddress ?: "" }
                3 -> ByteArray(i.readUnsignedByte()).also { i.readFully(it) }.let { String(it) }
                4 -> ByteArray(16).also { i.readFully(it) }.let { InetAddress.getByAddress(it).hostAddress ?: "" }
                else -> return
            }
            val port = i.readUnsignedShort()

            when (cmd) {
                1 -> {
                    val t0 = SystemClock.elapsedRealtime()
                    val u: Socket = try {
                        ProxyDialer.open(p, host, port)
                    } catch (e: Exception) {
                        onConn(host, port, false, 0, e.message ?: "Failed")
                        o.write(reply(5)); return
                    }
                    own(u)
                    onConn(host, port, true, SystemClock.elapsedRealtime() - t0, "")
                    o.write(reply(0)); o.flush()
                    // dead connections must not pile up for hours (each one holds 2 threads)
                    c.soTimeout = IDLE_MS; u.soTimeout = IDLE_MS
                    try { c.keepAlive = true; u.keepAlive = true } catch (ignored: Exception) {}
                    pool.execute {
                        pipe(c.getInputStream(), u.getOutputStream())
                        try { u.shutdownOutput() } catch (ignored: Exception) {}
                    }
                    pipe(u.getInputStream(), o)
                }
                3 -> {
                    if (p.type != "SOCKS5") { o.write(reply(7)); return }
                    val (ctrl, relayAddr) = try {
                        ProxyDialer.udpAssociate(p)
                    } catch (e: Exception) {
                        o.write(reply(1)); return
                    }
                    own(ctrl)
                    val local = DatagramSocket(0, InetAddress.getByName("127.0.0.1")).also { own(it) }
                    val up = DatagramSocket().also { own(it) }
                    val lp = local.localPort
                    o.write(byteArrayOf(5, 0, 0, 1, 127, 0, 0, 1, (lp shr 8).toByte(), (lp and 0xff).toByte()))
                    o.flush()
                    c.soTimeout = 0
                    var client: SocketAddress? = null
                    pool.execute {
                        val buf = ByteArray(65535)
                        try {
                            while (true) {
                                val pk = DatagramPacket(buf, buf.size)
                                local.receive(pk)
                                client = pk.socketAddress
                                up.send(DatagramPacket(pk.data, pk.offset, pk.length, relayAddr))
                            }
                        } catch (ignored: Exception) {}
                    }
                    pool.execute {
                        val buf = ByteArray(65535)
                        try {
                            while (true) {
                                val pk = DatagramPacket(buf, buf.size)
                                up.receive(pk)
                                val to = client ?: continue
                                local.send(DatagramPacket(pk.data, pk.offset, pk.length, to))
                            }
                        } catch (ignored: Exception) {}
                    }
                    pool.execute {
                        try { while (ctrl.getInputStream().read() >= 0) { } } catch (ignored: Exception) {}
                        try { c.close() } catch (ignored: Exception) {}
                    }
                    // association lives as long as the engine keeps this TCP connection open
                    try { while (c.getInputStream().read() >= 0) { } } catch (ignored: Exception) {}
                }
                else -> o.write(reply(7))
            }
        } catch (ignored: Exception) {
        } finally {
            owned.forEach { try { it.close() } catch (ignored: Exception) {} }
            owned.forEach { open.remove(it) }
        }
    }

    private fun pipe(i: InputStream, o: OutputStream) {
        val buf = ByteArray(32 * 1024)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (ignored: Exception) {}
    }
}

/** Fetch proxy list from a subscription URL (your VPS / bot) */
object SubSync {
    @Volatile var lastSync = 0L

    private fun key(p: ProxyProfile) = "${p.type}|${p.host}|${p.port}|${p.user}"

    fun sync(): Result<Int> = runCatching {
        val url = Store.subUrl.trim()
        require(url.isNotEmpty()) { "No subscription URL set" }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "FleetProxy")
        val text = c.inputStream.bufferedReader().use { it.readText() }
        val parsed = ProxyParser.parseAll(text, "SOCKS5")
        require(parsed.isNotEmpty()) { "No proxies found at that URL" }
        val old = Store.profiles()
        val oldSub = old.filter { it.fromSub }.associateBy { key(it) }
        val newSub = parsed.map { np ->
            oldSub[key(np)]?.copy(pass = np.pass) ?: np.copy(fromSub = true)
        }
        Store.saveProfiles(old.filter { !it.fromSub } + newSub)
        lastSync = System.currentTimeMillis()
        AppLog.add("Synced ${newSub.size} proxies")
        newSub.size
    }.onFailure { AppLog.add("Sync failed: ${it.message}") }
}
