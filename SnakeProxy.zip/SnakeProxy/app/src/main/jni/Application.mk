APP_OPTIM := release
APP_ABI := arm64-v8a armeabi-v7a
APP_CFLAGS := -O3 -DPKGNAME=com/snake/proxy/core -DCLSNAME=TProxyService
APP_CPPFLAGS := -O3 -std=c++11
NDK_TOOLCHAIN_VERSION := clang
