plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.snake.proxy"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.snake.proxy"
        minSdk = 26
        targetSdk = 33
        versionCode = 8
        versionName = "6.2"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    externalNativeBuild {
        ndkBuild {
            path = file("src/main/jni/Android.mk")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}

// Downloads world country outlines (Natural Earth, public domain) for the home map.
// If the download fails the build still succeeds and the app fetches the file on first launch.
val fetchWorldMap by tasks.registering {
    val out = file("src/main/assets/world.geojson")
    outputs.upToDateWhen { out.exists() && out.length() > 1000 }
    doLast {
        if (out.exists() && out.length() > 1000) return@doLast
        out.parentFile.mkdirs()
        val urls = listOf(
            "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson",
            "https://cdn.jsdelivr.net/gh/nvkelso/natural-earth-vector@master/geojson/ne_110m_admin_0_countries.geojson"
        )
        for (u in urls) {
            try {
                java.net.URL(u).openStream().use { input -> out.outputStream().use { input.copyTo(it) } }
                if (out.length() > 1000) { println("World map downloaded: ${out.length()} bytes"); break }
            } catch (e: Exception) {
                println("World map download failed ($u): ${e.message}")
                out.delete()
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(fetchWorldMap) }
