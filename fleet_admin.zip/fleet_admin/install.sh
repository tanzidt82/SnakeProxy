#!/bin/bash
# Fleet Proxy Admin Panel — one-time installer (Ubuntu / Debian VPS)
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
echo "==> Fleet Proxy Admin setup in $DIR"

export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null 2>&1 || true
apt-get install -y python3 python3-pip curl >/dev/null 2>&1 || true
apt-get install -y python3-flask gunicorn >/dev/null 2>&1 || true

if ! python3 -c "import flask" 2>/dev/null; then
  pip3 install -q flask gunicorn 2>/dev/null || pip3 install -q --break-system-packages flask gunicorn
fi
if ! python3 -c "import gunicorn" 2>/dev/null; then
  pip3 install -q gunicorn 2>/dev/null || pip3 install -q --break-system-packages gunicorn || true
fi

# free port (8090 or next)
PORT=8090
while ss -ltn 2>/dev/null | grep -q ":$PORT "; do PORT=$((PORT+1)); done

IP=$(curl -s4 --max-time 6 ifconfig.me || curl -s4 --max-time 6 api.ipify.org || hostname -I | awk '{print $1}')
PASS=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 12)
if [ -f fleet.db ]; then PASS="(age theke je password chilo seta-i)"; fi

if python3 -c "import gunicorn" 2>/dev/null; then
  RUN="/usr/bin/python3 -m gunicorn -w 2 --threads 4 -b 0.0.0.0:$PORT --timeout 120 app:app"
else
  RUN="/usr/bin/python3 $DIR/app.py"
fi

cat > /etc/systemd/system/fleet-admin.service <<EOF
[Unit]
Description=Fleet Proxy Admin Panel
After=network.target

[Service]
WorkingDirectory=$DIR
Environment=FLEET_PORT=$PORT
Environment=FLEET_PUBLIC_URL=http://$IP:$PORT
Environment=FLEET_ADMIN_USER=admin
Environment=FLEET_ADMIN_PASS=$PASS
ExecStart=$RUN
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable fleet-admin >/dev/null 2>&1
systemctl restart fleet-admin
command -v ufw >/dev/null && ufw allow $PORT/tcp >/dev/null 2>&1 || true
sleep 3

if curl -s --max-time 5 "http://127.0.0.1:$PORT/health" | grep -q ok; then
  echo ""
  echo "=============================================="
  echo "  DONE! Admin panel cholche"
  echo ""
  echo "  Panel link : http://$IP:$PORT/admin"
  echo "  Username   : admin"
  echo "  Password   : $PASS"
  echo ""
  echo "  App-er strings.xml e boshao:"
  echo "  http://$IP:$PORT"
  echo "=============================================="
else
  echo "!! Panel chalu hoyni. Ei command-er output pathao:"
  echo "   journalctl -u fleet-admin -n 30 --no-pager"
fi
