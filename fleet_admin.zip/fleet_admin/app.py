"""
Fleet Proxy — Admin Panel
Run on your VPS:  python3 app.py   (default port 8090)
The Android app reads its settings from  /api/config
"""
import json, os, secrets, sqlite3, time, uuid, hashlib, hmac
from datetime import datetime, timedelta
from functools import wraps
from flask import (Flask, request, session, redirect, url_for, jsonify,
                   render_template_string, send_from_directory, abort)
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "fleet.db")
UPLOADS = os.path.join(BASE, "uploads")
PORT = int(os.environ.get("FLEET_PORT", "8090"))
# Public address of this panel, used to build media links for the app (e.g. http://1.2.3.4:8090)
PUBLIC_URL = os.environ.get("FLEET_PUBLIC_URL", "").rstrip("/")

os.makedirs(UPLOADS, exist_ok=True)
app = Flask(__name__, static_folder=os.path.join(BASE, "static"))
app.config["MAX_CONTENT_LENGTH"] = 150 * 1024 * 1024          # 150 MB uploads (videos)
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=30)

IMG_EXT = {"png", "jpg", "jpeg", "webp", "gif"}
VID_EXT = {"mp4", "webm", "3gp", "mkv"}

# ─────────────────────────── storage ───────────────────────────

DEFAULT_CONFIG = {
    "maintenance": {"on": False, "title": "Under maintenance",
                    "message": "We are upgrading our servers. Please try again in a little while.",
                    "minutes": 30, "since": 0},
    "update": {"latest_code": 16, "latest_name": "7.7", "link": "", "notes": "",
               "force": False, "min_code": 0, "show": "every"},
    "ads": {"enabled": False, "mode": "both", "show_secs": 15, "skip_after": 5,
            "interval_min": 3, "daily_max": 12, "first_delay_sec": 20,
            "admob": {"banner": "", "interstitial": "", "rewarded": "", "app_open": ""},
            "place": {"app_open": True, "after_connect": True, "connect_every": 2, "home_banner": False}},
    "own_ads": [],
    "notice": {"on": False, "id": "", "title": "", "text": "", "image": "", "button": "", "link": ""},
    "links": {"support": "", "telegram": "", "privacy": ""},
}


def db():
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT)")
        c.execute("""CREATE TABLE IF NOT EXISTS devices (id TEXT PRIMARY KEY, version INTEGER, vname TEXT,
                     country TEXT, model TEXT, sdk INTEGER, first_seen INTEGER, last_seen INTEGER, blocked INTEGER DEFAULT 0)""")
        c.execute("CREATE TABLE IF NOT EXISTS events (ts INTEGER, device TEXT, kind TEXT, src TEXT, ad TEXT)")
        c.execute("CREATE INDEX IF NOT EXISTS ev_ts ON events(ts)")
        c.execute("CREATE INDEX IF NOT EXISTS dv_seen ON devices(last_seen)")
        if not c.execute("SELECT 1 FROM kv WHERE k='config'").fetchone():
            c.execute("INSERT INTO kv VALUES ('config', ?)", (json.dumps(DEFAULT_CONFIG),))
        if not c.execute("SELECT 1 FROM kv WHERE k='admin'").fetchone():
            user = os.environ.get("FLEET_ADMIN_USER", "admin")
            pw = os.environ.get("FLEET_ADMIN_PASS") or "admin12345"
            c.execute("INSERT INTO kv VALUES ('admin', ?)", (json.dumps({"user": user, "hash": hash_pw(pw)}),))
            print(f"\n  Admin login → user: {user}   password: {pw}\n  (change it from More → Password)\n")
        if not c.execute("SELECT 1 FROM kv WHERE k='secret'").fetchone():
            c.execute("INSERT INTO kv VALUES ('secret', ?)", (secrets.token_hex(32),))


def kv_get(k, default=None):
    with db() as c:
        r = c.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    return r["v"] if r else default


def kv_set(k, v):
    with db() as c:
        c.execute("INSERT INTO kv VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))


def deep_merge(base, extra):
    out = json.loads(json.dumps(base))
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def get_cfg():
    try:
        return deep_merge(DEFAULT_CONFIG, json.loads(kv_get("config", "{}")))
    except Exception:
        return json.loads(json.dumps(DEFAULT_CONFIG))


def save_cfg(cfg):
    kv_set("config", json.dumps(cfg))


def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 120_000).hex()
    return f"{salt}${h}"


def check_pw(pw, stored):
    try:
        salt, _ = stored.split("$", 1)
        return hmac.compare_digest(hash_pw(pw, salt), stored)
    except Exception:
        return False


init_db()
app.secret_key = kv_get("secret")

# ─────────────────────────── helpers ───────────────────────────

def now():
    return int(time.time())


def day_start(days_ago=0):
    d = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days_ago)
    return int(d.timestamp())


def as_int(v, default=0, lo=None, hi=None):
    try:
        x = int(float(str(v).strip()))
    except Exception:
        x = default
    if lo is not None: x = max(lo, x)
    if hi is not None: x = min(hi, x)
    return x


def chk(name):
    return request.form.get(name) in ("on", "1", "true", "yes")


def media_url(fname):
    if not fname:
        return ""
    if fname.startswith("http://") or fname.startswith("https://"):
        return fname
    base = PUBLIC_URL or request.host_url.rstrip("/")
    return f"{base}/media/{fname}"


def save_upload(fs, allowed):
    if not fs or not fs.filename:
        return None
    ext = fs.filename.rsplit(".", 1)[-1].lower() if "." in fs.filename else ""
    if ext not in allowed:
        return None
    name = f"{uuid.uuid4().hex[:12]}.{ext}"
    fs.save(os.path.join(UPLOADS, secure_filename(name)))
    return name


def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("ok"):
            return redirect(url_for("login", next=request.path))
        return f(*a, **k)
    return w


_fails = {}

# ─────────────────────────── public API (used by the app) ───────────────────────────

@app.route("/api/config", methods=["GET", "POST"])
def api_config():
    d = request.get_json(silent=True) or {}
    dev = str(d.get("id") or request.args.get("id") or "")[:64]
    ver = as_int(d.get("v") or request.args.get("v"), 0)
    blocked = False
    if dev:
        t = now()
        with db() as c:
            r = c.execute("SELECT blocked FROM devices WHERE id=?", (dev,)).fetchone()
            if r:
                blocked = bool(r["blocked"])
                c.execute("UPDATE devices SET version=?, vname=?, country=?, model=?, sdk=?, last_seen=? WHERE id=?",
                          (ver, str(d.get("vn", ""))[:16], str(d.get("cc", ""))[:4].upper(), str(d.get("model", ""))[:40],
                           as_int(d.get("sdk")), t, dev))
            else:
                c.execute("INSERT INTO devices (id, version, vname, country, model, sdk, first_seen, last_seen) VALUES (?,?,?,?,?,?,?,?)",
                          (dev, ver, str(d.get("vn", ""))[:16], str(d.get("cc", ""))[:4].upper(), str(d.get("model", ""))[:40],
                           as_int(d.get("sdk")), t, t))
    cfg = get_cfg()
    m = cfg["maintenance"]
    a = cfg["ads"]
    own = [{"id": x["id"], "type": x["type"], "url": media_url(x["file"]), "link": x.get("link", ""),
            "title": x.get("title", ""), "secs": as_int(x.get("secs"), a["show_secs"]),
            "skip": as_int(x.get("skip"), a["skip_after"]), "banner": bool(x.get("banner"))}
           for x in cfg["own_ads"] if x.get("on")]
    n = cfg["notice"]
    return jsonify({
        "ok": True, "ts": now(), "blocked": blocked,
        "maintenance": {"on": bool(m["on"]), "title": m["title"], "message": m["message"],
                        "until": (m["since"] + m["minutes"] * 60) if m["on"] and m["since"] else 0,
                        "since": m["since"]},
        "update": {**cfg["update"]},
        "ads": {"enabled": bool(a["enabled"]), "mode": a["mode"], "interval_min": a["interval_min"],
                "daily_max": a["daily_max"], "first_delay_sec": a["first_delay_sec"],
                "show_secs": a["show_secs"], "skip_after": a["skip_after"],
                "admob": a["admob"], "place": a["place"], "own": own},
        "notice": {**n, "image": media_url(n.get("image", ""))} if n.get("on") else {"on": False},
        "links": cfg["links"],
    })


@app.route("/api/ad_event", methods=["POST"])
def api_ad_event():
    d = request.get_json(silent=True) or {}
    kind = d.get("kind") if d.get("kind") in ("impression", "click") else None
    if kind:
        with db() as c:
            c.execute("INSERT INTO events VALUES (?,?,?,?,?)", (now(), str(d.get("id", ""))[:64], kind,
                      str(d.get("src", ""))[:10], str(d.get("ad", ""))[:40]))
    return jsonify({"ok": True})


@app.route("/media/<path:fname>")
def media(fname):
    return send_from_directory(UPLOADS, secure_filename(fname), max_age=86400)


@app.route("/health")
def health():
    return "ok"

# ─────────────────────────── admin UI ───────────────────────────

ICONS = {
 "dash": '<rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/>',
 "ads": '<path d="M3 11v2a2 2 0 0 0 2 2h1l4 4V5L6 9H5a2 2 0 0 0-2 2z"/><path d="M14 8a5 5 0 0 1 0 8"/><path d="M17.5 5a9 9 0 0 1 0 14"/>',
 "upd": '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/>',
 "wrench": '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
 "cog": '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
 "users": '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17" cy="9" r="2.6"/><path d="M16 14.2a5 5 0 0 1 5.5 5"/>',
 "bell": '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 20a2 2 0 0 0 4 0"/>',
 "img": '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
 "vid": '<rect x="2.5" y="5" width="14" height="14" rx="3"/><path d="m16.5 10 5-3v10l-5-3"/>',
 "link": '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
 "lock": '<rect x="4" y="11" width="16" height="10" rx="3"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
 "rocket": '<path d="M5 15c-1.5 1.5-2 5-2 5s3.5-.5 5-2"/><path d="M14 4c3-1 6-1 6-1s0 3-1 6l-7 7-5-5z"/><circle cx="15" cy="9" r="1.5"/>',
 "play": '<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>',
 "out": '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
 "trash": '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 14h10l1-14"/>',
 "chev": '<path d="m9 6 6 6-6 6"/>',
 "back": '<path d="m15 6-6 6 6 6"/>',
 "block": '<circle cx="12" cy="12" r="9"/><path d="m5.7 5.7 12.6 12.6"/>',
}


def ic(name, size=20, color="currentColor"):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.9" '
            f'stroke-linecap="round" stroke-linejoin="round">{ICONS[name]}</svg>')


app.jinja_env.globals["ic"] = ic

CSS = r"""
@font-face{font-family:P;src:url(/static/Poppins-Regular.ttf)}@font-face{font-family:PM;src:url(/static/Poppins-Medium.ttf)}@font-face{font-family:PB;src:url(/static/Poppins-Bold.ttf)}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
:root{--bg:#080D1A;--text:#EEF2FA;--t2:#8E9BBA;--k1:#172340;--k2:#0F182C;--edge:#050912;--line:rgba(140,175,255,.10)}
html,body{margin:0;overflow-x:hidden;background:var(--bg);color:var(--text);font-family:P,system-ui,sans-serif;font-size:15px}
body{background-image:radial-gradient(120% 50% at 50% -10%,rgba(60,110,255,.16),transparent 60%),linear-gradient(rgba(255,255,255,.022) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.022) 1px,transparent 1px);background-size:auto,39px 39px,39px 39px;min-height:100vh}
a{color:inherit;text-decoration:none}
.wrap{max-width:560px;margin:0 auto;padding:14px 16px 120px}
.ah{display:flex;align-items:center;gap:12px;margin:10px 0 16px}.ah .t{font-family:PB;font-size:24px}.ah .s{font-size:12.5px;color:var(--t2)}
.key{border:1px solid var(--line);border-radius:22px;background:radial-gradient(120% 90% at 0% 0%,rgba(80,140,255,.10),transparent 55%),linear-gradient(180deg,var(--k1),var(--k2));
 box-shadow:inset 0 1px 0 rgba(255,255,255,.10),0 5px 0 var(--edge),0 5px 0 1px rgba(110,150,255,.10),0 18px 30px -10px rgba(0,0,0,.75)}
.card{padding:15px 16px;margin-bottom:14px}
.av{width:42px;height:42px;border-radius:14px;display:flex;align-items:center;justify-content:center;color:#9FC0FF;flex:none}
.sec{font-family:PM;font-size:13px;color:var(--t2);margin:20px 2px 9px}
.lr{display:flex;align-items:center;gap:12px}.lr+.lr{margin-top:14px}
.tt{flex:1;min-width:0}.tt b{display:block;font-family:PM;font-weight:400;font-size:14.5px}.tt span{font-size:12px;color:var(--t2)}
.tile{width:40px;height:40px;border-radius:13px;display:flex;align-items:center;justify-content:center;flex:none}
.tb{background:rgba(60,130,255,.16);color:#6FA8FF}.tg{background:rgba(34,197,94,.15);color:#4ADE80}.to{background:rgba(251,146,60,.15);color:#FB923C}
.tp{background:rgba(168,85,247,.15);color:#C084FC}.tr{background:rgba(244,63,94,.15);color:#FB7185}.tc{background:rgba(34,211,238,.14);color:#22D3EE}
.sw{position:relative;width:48px;height:28px;flex:none}.sw input{opacity:0;width:0;height:0;position:absolute}
.sw i{position:absolute;inset:0;border-radius:99px;background:rgba(140,160,200,.25);transition:.2s;cursor:pointer}
.sw i::after{content:"";position:absolute;left:3px;top:3px;width:22px;height:22px;border-radius:50%;background:#fff;box-shadow:0 2px 4px rgba(0,0,0,.3);transition:.2s}
.sw input:checked+i{background:#3C8CFF}.sw.red input:checked+i{background:#F43F5E}.sw input:checked+i::after{left:23px}
.fld{margin-top:12px}.fld label{display:block;font-size:11.5px;color:var(--t2);margin:0 2px 6px;font-family:PM}
.in{width:100%;height:46px;border-radius:14px;padding:0 14px;font:inherit;font-size:14px;color:var(--text);background:rgba(5,9,18,.55);border:1px solid rgba(140,175,255,.13);outline:none}
.in:focus{border-color:#3C8CFF}textarea.in{height:90px;padding-top:11px;resize:vertical;line-height:1.5}
select.in{appearance:none}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:10px}.g2 .fld{margin-top:10px}
.u{position:relative}.u span{position:absolute;right:14px;top:50%;transform:translateY(-50%);font-size:12px;color:var(--t2);pointer-events:none}
.btn{width:100%;height:52px;border:0;border-radius:16px;display:flex;align-items:center;justify-content:center;gap:8px;font:inherit;font-family:PM;font-size:15px;color:#fff;cursor:pointer;margin-top:16px;
 background:linear-gradient(180deg,#5B9BFF,#2F6BF0);box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 4px 0 #1C3F9E,0 12px 22px -8px rgba(47,107,240,.6)}
.btn:active{transform:translateY(3px);box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 1px 0 #1C3F9E}
.btn.sm{height:42px;font-size:13.5px;margin-top:12px}.btn.red{background:linear-gradient(180deg,#FB7185,#E11D48);box-shadow:inset 0 1px 0 rgba(255,255,255,.3),0 4px 0 #9F1239}
.btn.ghost{background:rgba(255,255,255,.06);box-shadow:none;border:1px solid var(--line);color:var(--t2)}
.segs{display:flex;padding:4px;gap:4px;border-radius:16px;background:rgba(5,9,18,.55);border:1px solid var(--line)}
.segs label{flex:1;cursor:pointer}.segs input{display:none}
.segs span{height:38px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-family:PM;font-size:13px;color:var(--t2)}
.segs input:checked+span{background:linear-gradient(180deg,#5B9BFF,#2F6BF0);color:#fff;box-shadow:0 6px 14px -4px rgba(47,107,240,.6)}
.stat{padding:14px}.stat span{font-size:12px;color:var(--t2)}.stat b{display:block;font-family:PB;font-size:24px;margin-top:6px;letter-spacing:-.3px}.stat small{font-size:11.5px;font-family:PM}
.chart{display:flex;align-items:flex-end;gap:8px;height:96px;margin-top:12px}
.chart div{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%;justify-content:flex-end}
.chart i{display:block;width:100%;border-radius:7px 7px 3px 3px;background:linear-gradient(180deg,#5B9BFF,#2F6BF0);min-height:4px}
.chart small{font-size:10px;color:var(--t2)}
.media{display:flex;gap:12px;align-items:center}.media .tt{overflow:hidden}.media+.media{margin-top:14px;padding-top:14px;border-top:1px solid var(--line)}
.thumb{width:64px;height:64px;border-radius:14px;flex:none;overflow:hidden;display:flex;align-items:center;justify-content:center;color:#fff;background:linear-gradient(135deg,#7C3AED,#2F6BF0)}
.thumb img,.thumb video{width:100%;height:100%;object-fit:cover}
.chip{display:inline-flex;align-items:center;font-size:10.5px;font-family:PM;padding:3px 8px;border-radius:99px;background:rgba(60,130,255,.15);color:#7FB0FF;margin:6px 4px 0 0}
.chip.g{background:rgba(34,197,94,.14);color:#4ADE80}.chip.o{background:rgba(251,146,60,.15);color:#FB923C}.chip.r{background:rgba(244,63,94,.15);color:#FB7185}
.ib{width:36px;height:36px;border-radius:11px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.05);border:1px solid var(--line);color:var(--t2);cursor:pointer;flex:none}
.nav{position:fixed;left:50%;transform:translateX(-50%);bottom:14px;width:calc(100% - 28px);max-width:532px;height:68px;border-radius:26px;display:flex;align-items:center;justify-content:space-around;z-index:9;
 background:linear-gradient(180deg,#172340,#0F182C);border:1px solid var(--line);box-shadow:0 5px 0 #050912,0 18px 30px -10px rgba(0,0,0,.8)}
.nav a{display:flex;flex-direction:column;align-items:center;gap:3px;font-size:10.5px;color:var(--t2);font-family:PM;padding:8px 6px}
.nav a.on{color:#fff;background:linear-gradient(180deg,#5B9BFF,#2F6BF0);padding:9px 13px;border-radius:16px;flex-direction:row;gap:6px;font-size:12.5px;box-shadow:0 10px 20px -6px rgba(47,107,240,.6)}
.toast{position:fixed;top:14px;left:50%;transform:translateX(-50%);padding:11px 18px;border-radius:14px;background:#16A34A;color:#fff;font-family:PM;font-size:13.5px;z-index:20;box-shadow:0 12px 24px -8px rgba(0,0,0,.6)}
.toast.err{background:#E11D48}
table{width:100%;border-collapse:collapse;font-size:12.5px}td{padding:10px 4px;border-top:1px solid var(--line)}tr:first-child td{border-top:0}
.mut{color:var(--t2);font-size:12px}
.file{display:flex;align-items:center;justify-content:center;gap:8px;height:52px;border-radius:14px;border:1.5px dashed rgba(140,175,255,.3);color:#9FC0FF;font-family:PM;font-size:13.5px;cursor:pointer;margin-top:12px}
.file input{display:none}
"""

BASE_TPL = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="theme-color" content="#080D1A"><title>{{ title }} · Fleet Proxy Admin</title><link rel="icon" href="/static/logo.png"><style>{{ css|safe }}</style></head>
<body>{% if msg %}<div class="toast {{ 'err' if err else '' }}" id="toast">{{ msg }}</div><script>setTimeout(()=>{var t=document.getElementById('toast');if(t)t.remove()},2600)</script>{% endif %}
<div class="wrap">{{ body|safe }}</div>
{% if tab is not none %}<nav class="nav">
{% for i,(href,icon,label) in tabs %}<a href="{{ href }}" class="{{ 'on' if i==tab else '' }}">{{ ic(icon,19)|safe }}{{ label }}</a>{% endfor %}</nav>{% endif %}
</body></html>"""

TABS = list(enumerate([("/admin", "dash", "Home"), ("/admin/ads", "ads", "Ads"), ("/admin/update", "upd", "Update"),
                       ("/admin/control", "wrench", "Control"), ("/admin/more", "cog", "More")]))


def page(title, body_tpl, tab=None, **ctx):
    msg = session.pop("msg", None)
    err = session.pop("err", False)
    body = render_template_string(body_tpl, **ctx)
    return render_template_string(BASE_TPL, title=title, body=body, tab=tab, tabs=TABS, css=CSS, msg=msg, err=err)


def flash(msg, err=False):
    session["msg"] = msg
    session["err"] = err


def head(title, sub, icon):
    return (f'<div class="ah"><div style="flex:1"><div class="s">{sub}</div><div class="t">{title}</div></div>'
            f'<div class="av key">{ic(icon, 20)}</div></div>')


def sw(name, on, red=False, auto=False):
    a = ' onchange="this.form.submit()"' if auto else ""
    return f'<label class="sw {"red" if red else ""}"><input type="checkbox" name="{name}"{" checked" if on else ""}{a}><i></i></label>'


app.jinja_env.globals["sw"] = sw

# ── login ──

@app.route("/")
def root():
    return redirect("/admin")


@app.route("/admin/login", methods=["GET", "POST"])
def login():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "")
    if request.method == "POST":
        f = _fails.get(ip, [0, 0])
        if f[0] >= 8 and now() - f[1] < 600:
            flash("Too many tries. Wait 10 minutes.", True)
            return redirect(url_for("login"))
        a = json.loads(kv_get("admin"))
        if request.form.get("user", "").strip() == a["user"] and check_pw(request.form.get("pw", ""), a["hash"]):
            session.clear()
            session.permanent = True
            session["ok"] = True
            _fails.pop(ip, None)
            nxt = request.args.get("next", "/admin")
            return redirect(nxt if nxt.startswith("/admin") else "/admin")
        _fails[ip] = [f[0] + 1, now()]
        flash("Wrong username or password", True)
        return redirect(url_for("login"))
    return page("Login", """
<div style="margin-top:12vh;text-align:center"><img src="/static/logo.png" style="width:84px;height:84px;border-radius:22px;box-shadow:0 18px 40px -12px rgba(47,107,240,.7)"></div>
<div style="display:flex;justify-content:center;margin-top:22px"><img src="/static/wordmark.svg" style="height:28px"></div>
<div class="mut" style="text-align:center;margin-top:8px">Admin Panel</div>
<form method="post" class="key card" style="margin-top:34px;padding:18px">
 <div class="fld"><label>Username</label><input class="in" name="user" autocomplete="username" required></div>
 <div class="fld"><label>Password</label><input class="in" type="password" name="pw" autocomplete="current-password" required></div>
 <button class="btn">{{ ic('lock',18)|safe }} Login</button></form>""")


@app.route("/admin/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ── dashboard ──

@app.route("/admin")
@login_required
def dashboard():
    cfg = get_cfg()
    t = now()
    with db() as c:
        active = c.execute("SELECT COUNT(*) n FROM devices WHERE last_seen>=?", (day_start(),)).fetchone()["n"]
        active_y = c.execute("SELECT COUNT(*) n FROM devices WHERE last_seen>=? AND last_seen<?", (day_start(1), day_start())).fetchone()["n"]
        online = c.execute("SELECT COUNT(*) n FROM devices WHERE last_seen>=?", (t - 600,)).fetchone()["n"]
        imp = c.execute("SELECT COUNT(*) n FROM events WHERE kind='impression' AND ts>=?", (day_start(),)).fetchone()["n"]
        clk = c.execute("SELECT COUNT(*) n FROM events WHERE kind='click' AND ts>=?", (day_start(),)).fetchone()["n"]
        total = c.execute("SELECT COUNT(*) n FROM devices").fetchone()["n"]
        wk = c.execute("SELECT COUNT(*) n FROM devices WHERE last_seen>=?", (day_start(7),)).fetchone()["n"]
        upd = c.execute("SELECT COUNT(*) n FROM devices WHERE last_seen>=? AND version>=?", (day_start(7), cfg["update"]["latest_code"])).fetchone()["n"]
        days = []
        for i in range(6, -1, -1):
            n = c.execute("SELECT COUNT(*) n FROM devices WHERE first_seen>=? AND first_seen<?", (day_start(i), day_start(i - 1))).fetchone()["n"]
            days.append((datetime.fromtimestamp(day_start(i)).strftime("%a"), n))
    mx = max([n for _, n in days] + [1])
    trend = (f"▲ {round((active - active_y) / active_y * 100)}%" if active_y and active >= active_y
             else (f"▼ {round((active_y - active) / active_y * 100)}%" if active_y else ""))
    return page("Dashboard", head("Dashboard", "Fleet Proxy · Admin", "dash") + """
<div class="g2"><div class="key stat"><span>Active today</span><b>{{ active }}</b><small style="color:#4ADE80">{{ trend }}</small></div>
<div class="key stat"><span>Online now</span><b>{{ online }}</b><small style="color:#22D3EE">● last 10 min</small></div>
<div class="key stat"><span>Ads today</span><b>{{ imp }}</b><small style="color:#FB923C">{{ clk }} clicks</small></div>
<div class="key stat"><span>Latest version</span><b>{{ cfg["update"].latest_name }}</b><small style="color:#C084FC">{{ pct }}% updated</small></div></div>
<div class="key card" style="margin-top:14px"><div class="lr"><div class="tt"><b>New installs · 7 days</b><span>{{ total }} devices total</span></div><span class="chip g">+{{ week }}</span></div>
<div class="chart">{% for d,n in days %}<div><small>{{ n }}</small><i style="height:{{ (n/mx*80)|int + 4 }}%;opacity:{{ 1 if loop.last else 0.6 }}"></i><small>{{ d }}</small></div>{% endfor %}</div></div>
<div class="sec">Quick control</div>
<form method="post" action="/admin/quick" class="key card"><input type="hidden" name="what" value="maint">
 <div class="lr"><div class="tile tr">{{ ic('wrench')|safe }}</div><div class="tt"><b>Maintenance mode</b><span>{{ 'ON · app is closed for users' if cfg.maintenance.on else 'App bondho thakbe' }}</span></div>{{ sw('on', cfg.maintenance.on, True, True)|safe }}</div></form>
<form method="post" action="/admin/quick" class="key card"><input type="hidden" name="what" value="ads">
 <div class="lr"><div class="tile to">{{ ic('ads')|safe }}</div><div class="tt"><b>Ads</b><span>{{ {'admob':'AdMob only','own':'Own ads only','both':'AdMob + Own ads'}[cfg.ads.mode] }}</span></div>{{ sw('on', cfg.ads.enabled, False, True)|safe }}</div></form>
""", 0, cfg=cfg, active=active, online=online, imp=imp, clk=clk, total=total, days=days, mx=mx, trend=trend,
                week=sum(n for _, n in days), pct=round(upd / wk * 100) if wk else 0)


@app.route("/admin/quick", methods=["POST"])
@login_required
def quick():
    cfg = get_cfg()
    on = chk("on")
    if request.form.get("what") == "maint":
        cfg["maintenance"]["on"] = on
        if on: cfg["maintenance"]["since"] = now()
        flash("Maintenance " + ("ON" if on else "OFF"))
    elif request.form.get("what") == "ads":
        cfg["ads"]["enabled"] = on
        flash("Ads " + ("ON" if on else "OFF"))
    save_cfg(cfg)
    return redirect(request.referrer or "/admin")

# ── ads ──

@app.route("/admin/ads", methods=["GET", "POST"])
@login_required
def ads():
    cfg = get_cfg()
    a = cfg["ads"]
    if request.method == "POST":
        a["enabled"] = chk("enabled")
        a["mode"] = request.form.get("mode") if request.form.get("mode") in ("admob", "own", "both") else "both"
        a["show_secs"] = as_int(request.form.get("show_secs"), 15, 3, 120)
        a["skip_after"] = as_int(request.form.get("skip_after"), 5, 0, 120)
        a["interval_min"] = as_int(request.form.get("interval_min"), 3, 0, 1440)
        a["daily_max"] = as_int(request.form.get("daily_max"), 12, 0, 500)
        a["first_delay_sec"] = as_int(request.form.get("first_delay_sec"), 20, 0, 3600)
        save_cfg(cfg)
        flash("Ads saved")
        return redirect(url_for("ads"))
    return page("Ads", head("Ads", "Kon ad, kokhon, koto khon", "ads") + """
<form method="post">
<div class="key card"><div class="lr"><div class="tile to">{{ ic('ads')|safe }}</div><div class="tt"><b>Ads chalu</b><span>Bondho korle kono ad dekhabe na</span></div>{{ sw('enabled', a.enabled)|safe }}</div>
<div class="segs" style="margin-top:14px">{% for v,l in [('admob','AdMob'),('own','Own ads'),('both','Both')] %}<label><input type="radio" name="mode" value="{{ v }}" {{ 'checked' if a.mode==v else '' }}><span>{{ l }}</span></label>{% endfor %}</div></div>
<div class="sec">Timing</div>
<div class="key card"><div class="g2">
 <div class="fld"><label>Ad dekhabe (default)</label><div class="u"><input class="in" name="show_secs" inputmode="numeric" value="{{ a.show_secs }}"><span>sec</span></div></div>
 <div class="fld"><label>Skip button</label><div class="u"><input class="in" name="skip_after" inputmode="numeric" value="{{ a.skip_after }}"><span>sec por</span></div></div>
 <div class="fld"><label>Por por</label><div class="u"><input class="in" name="interval_min" inputmode="numeric" value="{{ a.interval_min }}"><span>min</span></div></div>
 <div class="fld"><label>Din-e max</label><div class="u"><input class="in" name="daily_max" inputmode="numeric" value="{{ a.daily_max }}"><span>ta</span></div></div></div>
 <div class="fld"><label>App khular koto por prothom ad</label><div class="u"><input class="in" name="first_delay_sec" inputmode="numeric" value="{{ a.first_delay_sec }}"><span>sec</span></div></div>
 <button class="btn sm">Save</button></div></form>
<div class="sec">Own ads · photo &amp; video</div>
<div class="key card">
{% for x in own %}<div class="media"><div class="thumb">{% if x.type=='image' %}<img src="/media/{{ x.file }}">{% else %}<video src="/media/{{ x.file }}" muted preload="metadata"></video>{% endif %}</div>
 <div class="tt"><b>{{ x.title or ('Video ad' if x.type=='video' else 'Photo ad') }}</b><span>{{ 'Video' if x.type=='video' else 'Photo' }} · {{ x.secs }}s · skip {{ x.skip }}s</span>
 <div><span class="chip">Full screen</span>{% if x.banner %}<span class="chip o">Banner</span>{% endif %}{% if x.link %}<span class="chip g">Link</span>{% endif %}<span class="chip">{{ stats.get(x.id,[0,0])[0] }} views · {{ stats.get(x.id,[0,0])[1] }} clicks</span></div></div>
 <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-end">
  <form method="post" action="/admin/own/{{ x.id }}/toggle">{{ sw('on', x.on, False, True)|safe }}</form>
  <form method="post" action="/admin/own/{{ x.id }}/delete" onsubmit="return confirm('Delete this ad?')"><button class="ib" style="border:0">{{ ic('trash',16)|safe }}</button></form></div></div>
{% else %}<div class="mut" style="text-align:center;padding:10px">Ekhono kono own ad nai</div>{% endfor %}
<form method="post" action="/admin/own/add" enctype="multipart/form-data" style="margin-top:16px;padding-top:6px;border-top:1px solid rgba(140,175,255,.1)">
 <label class="file">{{ ic('img',18)|safe }} <span id="fn">Photo ba video bachai koro</span><input type="file" name="file" accept="image/*,video/*" required onchange="document.getElementById('fn').textContent=this.files[0]?this.files[0].name:''"></label>
 <div class="fld"><label>Title (optional)</label><input class="in" name="title" placeholder="Summer promo"></div>
 <div class="fld"><label>Click korle kothay jabe (link)</label><input class="in" name="link" placeholder="https://t.me/yourchannel"></div>
 <div class="g2"><div class="fld"><label>Koto sec dekhabe</label><div class="u"><input class="in" name="secs" inputmode="numeric" value="{{ a.show_secs }}"><span>sec</span></div></div>
 <div class="fld"><label>Skip</label><div class="u"><input class="in" name="skip" inputmode="numeric" value="{{ a.skip_after }}"><span>sec por</span></div></div></div>
 <div class="lr" style="margin-top:14px"><div class="tt"><b>Home-e banner hisebe-o</b><span>Shudhu photo ad</span></div>{{ sw('banner', False)|safe }}</div>
 <button class="btn sm">+ Upload</button></form></div>
<a href="/admin/admob" class="key card lr" style="display:flex"><div class="tile tb">{{ ic('rocket')|safe }}</div><div class="tt"><b>AdMob units &amp; kothay dekhabe</b><span>Banner · Interstitial · Rewarded · App open</span></div>{{ ic('chev',18)|safe }}</a>
""", 1, a=a, own=cfg["own_ads"], stats=ad_stats())


def ad_stats():
    out = {}
    with db() as c:
        for r in c.execute("SELECT ad, kind, COUNT(*) n FROM events WHERE src='own' GROUP BY ad, kind"):
            v = out.setdefault(r["ad"], [0, 0])
            v[0 if r["kind"] == "impression" else 1] = r["n"]
    return out


@app.route("/admin/own/add", methods=["POST"])
@login_required
def own_add():
    cfg = get_cfg()
    fs = request.files.get("file")
    ext = (fs.filename.rsplit(".", 1)[-1].lower() if fs and "." in fs.filename else "")
    kind = "image" if ext in IMG_EXT else "video" if ext in VID_EXT else None
    name = save_upload(fs, IMG_EXT | VID_EXT) if kind else None
    if not name:
        flash("Shudhu photo (jpg/png/webp/gif) ba video (mp4/webm)", True)
        return redirect(url_for("ads"))
    cfg["own_ads"].append({"id": uuid.uuid4().hex[:8], "type": kind, "file": name,
                           "title": request.form.get("title", "").strip()[:60],
                           "link": request.form.get("link", "").strip()[:500],
                           "secs": as_int(request.form.get("secs"), cfg["ads"]["show_secs"], 3, 120),
                           "skip": as_int(request.form.get("skip"), cfg["ads"]["skip_after"], 0, 120),
                           "banner": chk("banner") and kind == "image", "on": True})
    save_cfg(cfg)
    flash("Ad uploaded")
    return redirect(url_for("ads"))


@app.route("/admin/own/<aid>/toggle", methods=["POST"])
@login_required
def own_toggle(aid):
    cfg = get_cfg()
    for x in cfg["own_ads"]:
        if x["id"] == aid:
            x["on"] = chk("on")
    save_cfg(cfg)
    return redirect(url_for("ads"))


@app.route("/admin/own/<aid>/delete", methods=["POST"])
@login_required
def own_delete(aid):
    cfg = get_cfg()
    keep = []
    for x in cfg["own_ads"]:
        if x["id"] == aid:
            try: os.remove(os.path.join(UPLOADS, secure_filename(x["file"])))
            except Exception: pass
        else:
            keep.append(x)
    cfg["own_ads"] = keep
    save_cfg(cfg)
    flash("Ad deleted")
    return redirect(url_for("ads"))


@app.route("/admin/admob", methods=["GET", "POST"])
@login_required
def admob():
    cfg = get_cfg()
    a = cfg["ads"]
    if request.method == "POST":
        for k in ("banner", "interstitial", "rewarded", "app_open"):
            a["admob"][k] = request.form.get(k, "").strip()[:80]
        a["place"]["app_open"] = chk("p_open")
        a["place"]["after_connect"] = chk("p_connect")
        a["place"]["connect_every"] = as_int(request.form.get("connect_every"), 2, 1, 50)
        a["place"]["home_banner"] = chk("p_banner")
        save_cfg(cfg)
        flash("AdMob saved")
        return redirect(url_for("admob"))
    return page("AdMob", """<div class="ah"><a href="/admin/ads" class="av key">{{ ic('back',20)|safe }}</a><div style="flex:1"><div class="s">Ad unit ID gula ekhane</div><div class="t">AdMob units</div></div></div>
<form method="post"><div class="key card">
{% for k,l in [('banner','Banner unit'),('interstitial','Interstitial unit'),('rewarded','Rewarded unit'),('app_open','App open unit')] %}
<div class="fld"><label>{{ l }}</label><input class="in" name="{{ k }}" value="{{ a.admob[k] }}" placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx"></div>{% endfor %}
<div class="mut" style="margin-top:12px">AdMob <b>App ID</b> app-er bhitore build-er shomoy boshano thake — oita ekhane bodlano jay na.</div></div>
<div class="sec">Kothay dekhabe</div>
<div class="key card">
 <div class="lr"><div class="tile tb">{{ ic('rocket')|safe }}</div><div class="tt"><b>App khular shomoy</b><span>App open ad (ba own ad)</span></div>{{ sw('p_open', a.place.app_open)|safe }}</div>
 <div class="lr"><div class="tile tg">{{ ic('upd')|safe }}</div><div class="tt"><b>Connect korar por</b><span>Full screen ad</span></div>{{ sw('p_connect', a.place.after_connect)|safe }}</div>
 <div class="fld"><label>Koto bar connect por por</label><div class="u"><input class="in" name="connect_every" inputmode="numeric" value="{{ a.place.connect_every }}"><span>bar</span></div></div>
 <div class="lr" style="margin-top:14px"><div class="tile tp">{{ ic('img')|safe }}</div><div class="tt"><b>Home-e banner</b><span>Niche, menu-r upore</span></div>{{ sw('p_banner', a.place.home_banner)|safe }}</div></div>
<button class="btn">Save</button></form>""", 1, a=a)

# ── update ──

@app.route("/admin/update", methods=["GET", "POST"])
@login_required
def update():
    cfg = get_cfg()
    u = cfg["update"]
    if request.method == "POST":
        u["latest_name"] = request.form.get("latest_name", "").strip()[:20]
        u["latest_code"] = as_int(request.form.get("latest_code"), u["latest_code"], 0)
        u["link"] = request.form.get("link", "").strip()[:500]
        u["notes"] = request.form.get("notes", "").strip()[:1000]
        u["force"] = chk("force")
        u["min_code"] = as_int(request.form.get("min_code"), 0, 0)
        u["show"] = "once" if request.form.get("show") == "once" else "every"
        save_cfg(cfg)
        flash("Update published")
        return redirect(url_for("update"))
    with db() as c:
        vers = c.execute("SELECT vname, version, COUNT(*) n FROM devices WHERE last_seen>=? GROUP BY version ORDER BY version DESC LIMIT 6", (day_start(7),)).fetchall()
    return page("Update", head("Update", "Notun version-er notice", "upd") + """
<form method="post"><div class="key card">
 <div class="g2"><div class="fld"><label>Latest version</label><input class="in" name="latest_name" value="{{ u.latest_name }}" placeholder="7.7"></div>
 <div class="fld"><label>Version code</label><input class="in" name="latest_code" inputmode="numeric" value="{{ u.latest_code }}"></div></div>
 <div class="fld"><label>Update link (button)</label><input class="in" name="link" value="{{ u.link }}" placeholder="https://play.google.com/store/apps/details?id=com.fleetproxy.app"></div>
 <div class="fld"><label>Ki notun (message)</label><textarea class="in" name="notes" placeholder="• Notun dark mode&#10;• Faster connect">{{ u.notes }}</textarea></div></div>
<div class="key card"><div class="lr"><div class="tile tr">{{ ic('lock')|safe }}</div><div class="tt"><b>Force update</b><span>Update na korle app cholbe na</span></div>{{ sw('force', u.force, True)|safe }}</div>
 <div class="g2"><div class="fld"><label>Minimum version code</label><input class="in" name="min_code" inputmode="numeric" value="{{ u.min_code }}"></div>
 <div class="fld"><label>Dekhabe</label><select class="in" name="show"><option value="every" {{ 'selected' if u.show=='every' else '' }}>Protibar</option><option value="once" {{ 'selected' if u.show=='once' else '' }}>Ekbar</option></select></div></div>
 <div class="mut" style="margin-top:10px">Version code tar cheye kom holei update notice jabe. Minimum code-er niche hole (ba Force on thakle) "Later" thakbe na.</div></div>
<button class="btn">{{ ic('upd',18)|safe }} Publish update</button></form>
{% if vers %}<div class="sec">Users-er version (7 din)</div><div class="key card"><table>{% for v in vers %}<tr><td>{{ v.vname or '?' }}</td><td class="mut">code {{ v.version }}</td><td style="text-align:right">{{ v.n }}</td></tr>{% endfor %}</table></div>{% endif %}
""", 2, u=u, vers=vers)

# ── control ──

@app.route("/admin/control", methods=["GET", "POST"])
@login_required
def control():
    cfg = get_cfg()
    if request.method == "POST":
        m = cfg["maintenance"]
        was = m["on"]
        m["on"] = chk("m_on")
        m["title"] = request.form.get("m_title", "").strip()[:60] or "Under maintenance"
        m["message"] = request.form.get("m_msg", "").strip()[:500]
        m["minutes"] = as_int(request.form.get("m_min"), 30, 0, 100000)
        if m["on"] and (not was or chk("m_restart")):
            m["since"] = now()
        save_cfg(cfg)
        flash("Saved")
        return redirect(url_for("control"))
    return page("Control", head("Control", "App-er shob kichu", "wrench") + """
<form method="post" class="key card">
 <div class="lr"><div class="tile tr">{{ ic('wrench')|safe }}</div><div class="tt"><b>Maintenance</b><span>On korle shobai notice dekhbe, app cholbe na</span></div>{{ sw('m_on', m.on, True)|safe }}</div>
 <div class="fld"><label>Title</label><input class="in" name="m_title" value="{{ m.title }}"></div>
 <div class="fld"><label>Message</label><textarea class="in" name="m_msg">{{ m.message }}</textarea></div>
 <div class="fld"><label>Kotokkhon</label><div class="u"><input class="in" name="m_min" inputmode="numeric" value="{{ m.minutes }}"><span>min</span></div></div>
 {% if m.on %}<div class="lr" style="margin-top:12px"><div class="tt"><b>Timer abar shuru</b><span>Ekhon theke gona shuru hobe</span></div>{{ sw('m_restart', False)|safe }}</div>{% endif %}
 <button class="btn sm">Save</button></form>
<a href="/admin/notice" class="key card lr" style="display:flex"><div class="tile tb">{{ ic('bell')|safe }}</div><div class="tt"><b>Notice / announcement</b><span>{{ 'ON · ' ~ (n.title or 'notice') if n.on else 'Photo + button shoho popup' }}</span></div>{{ ic('chev',18)|safe }}</a>
<a href="/admin/links" class="key card lr" style="display:flex"><div class="tile tc">{{ ic('link')|safe }}</div><div class="tt"><b>Links</b><span>Support · Telegram · Privacy</span></div>{{ ic('chev',18)|safe }}</a>
<a href="/admin/users" class="key card lr" style="display:flex"><div class="tile tg">{{ ic('users')|safe }}</div><div class="tt"><b>Users &amp; devices</b><span>Block · version · country</span></div>{{ ic('chev',18)|safe }}</a>
""", 3, m=cfg["maintenance"], n=cfg["notice"])


@app.route("/admin/notice", methods=["GET", "POST"])
@login_required
def notice():
    cfg = get_cfg()
    n = cfg["notice"]
    if request.method == "POST":
        changed = (request.form.get("title", "") != n.get("title") or request.form.get("text", "") != n.get("text"))
        n["on"] = chk("on")
        n["title"] = request.form.get("title", "").strip()[:80]
        n["text"] = request.form.get("text", "").strip()[:1000]
        n["button"] = request.form.get("button", "").strip()[:30]
        n["link"] = request.form.get("link", "").strip()[:500]
        img = save_upload(request.files.get("image"), IMG_EXT)
        if img:
            n["image"] = img; changed = True
        if chk("rm_image"):
            n["image"] = ""
        if changed or chk("again") or not n.get("id"):
            n["id"] = uuid.uuid4().hex[:8]          # new id → users see it again
        save_cfg(cfg)
        flash("Notice saved")
        return redirect(url_for("notice"))
    return page("Notice", """<div class="ah"><a href="/admin/control" class="av key">{{ ic('back',20)|safe }}</a><div style="flex:1"><div class="s">App khulle popup</div><div class="t">Notice</div></div></div>
<form method="post" enctype="multipart/form-data" class="key card">
 <div class="lr"><div class="tile tb">{{ ic('bell')|safe }}</div><div class="tt"><b>Notice chalu</b><span>Protiti user ekbar dekhbe</span></div>{{ sw('on', n.on)|safe }}</div>
 <div class="fld"><label>Title</label><input class="in" name="title" value="{{ n.title }}"></div>
 <div class="fld"><label>Lekha</label><textarea class="in" name="text">{{ n.text }}</textarea></div>
 {% if n.image %}<img src="/media/{{ n.image }}" style="width:100%;border-radius:14px;margin-top:12px"><div class="lr" style="margin-top:10px"><div class="tt"><b>Photo soriye dao</b></div>{{ sw('rm_image', False)|safe }}</div>{% endif %}
 <label class="file">{{ ic('img',18)|safe }} <span id="fn">{{ 'Photo bodlao' if n.image else 'Photo add koro (optional)' }}</span><input type="file" name="image" accept="image/*" onchange="document.getElementById('fn').textContent=this.files[0]?this.files[0].name:''"></label>
 <div class="g2"><div class="fld"><label>Button lekha</label><input class="in" name="button" value="{{ n.button }}" placeholder="Join now"></div>
 <div class="fld"><label>Button link</label><input class="in" name="link" value="{{ n.link }}" placeholder="https://"></div></div>
 <div class="lr" style="margin-top:14px"><div class="tt"><b>Shobaike abar dekhao</b><span>Jara age dekheche tarao</span></div>{{ sw('again', False)|safe }}</div>
 <button class="btn sm">Save</button></form>""", 3, n=n)


@app.route("/admin/links", methods=["GET", "POST"])
@login_required
def links():
    cfg = get_cfg()
    if request.method == "POST":
        for k in ("support", "telegram", "privacy"):
            cfg["links"][k] = request.form.get(k, "").strip()[:500]
        save_cfg(cfg)
        flash("Links saved")
        return redirect(url_for("links"))
    return page("Links", """<div class="ah"><a href="/admin/control" class="av key">{{ ic('back',20)|safe }}</a><div style="flex:1"><div class="s">App-er bhitorer link</div><div class="t">Links</div></div></div>
<form method="post" class="key card">
 <div class="fld"><label>Support (Telegram/WhatsApp/email link)</label><input class="in" name="support" value="{{ l.support }}" placeholder="https://t.me/yoursupport"></div>
 <div class="fld"><label>Telegram channel</label><input class="in" name="telegram" value="{{ l.telegram }}" placeholder="https://t.me/yourchannel"></div>
 <div class="fld"><label>Privacy policy</label><input class="in" name="privacy" value="{{ l.privacy }}" placeholder="https://yoursite.com/privacy"></div>
 <button class="btn sm">Save</button></form>""", 3, l=cfg["links"])


@app.route("/admin/users")
@login_required
def users():
    q = request.args.get("q", "").strip()
    with db() as c:
        if q:
            rows = c.execute("SELECT * FROM devices WHERE id LIKE ? OR country LIKE ? OR model LIKE ? ORDER BY last_seen DESC LIMIT 100",
                             (f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
        else:
            rows = c.execute("SELECT * FROM devices ORDER BY last_seen DESC LIMIT 100").fetchall()
        countries = c.execute("SELECT country, COUNT(*) n FROM devices WHERE last_seen>=? GROUP BY country ORDER BY n DESC LIMIT 8", (day_start(7),)).fetchall()
    t = now()

    def ago(ts):
        d = t - (ts or 0)
        return "now" if d < 600 else f"{d // 60}m" if d < 3600 else f"{d // 3600}h" if d < 86400 else f"{d // 86400}d"
    return page("Users", """<div class="ah"><a href="/admin/control" class="av key">{{ ic('back',20)|safe }}</a><div style="flex:1"><div class="s">Shesh 100 device</div><div class="t">Users &amp; devices</div></div></div>
<form><input class="in" name="q" value="{{ q }}" placeholder="Search id / country / model"></form>
{% if countries %}<div style="margin-top:12px">{% for c in countries %}<span class="chip">{{ c.country or '??' }} · {{ c.n }}</span>{% endfor %}</div>{% endif %}
<div class="key card" style="margin-top:12px"><table>
{% for r in rows %}<tr><td><b style="font-family:PM;font-weight:400">{{ r.id[:8] }}</b><div class="mut">{{ r.model or '' }} · {{ r.country or '??' }} · v{{ r.vname or r.version }}</div></td>
<td class="mut" style="text-align:right">{{ ago(r.last_seen) }}</td>
<td style="width:44px;text-align:right"><form method="post" action="/admin/users/{{ r.id }}/block"><button class="ib" style="{{ 'color:#FB7185;border-color:rgba(244,63,94,.4)' if r.blocked else '' }}" title="{{ 'Unblock' if r.blocked else 'Block' }}">{{ ic('block',16)|safe }}</button></form></td></tr>
{% else %}<tr><td class="mut" style="text-align:center;padding:18px">Ekhono kono device nai</td></tr>{% endfor %}</table></div>""", 3, rows=rows, q=q, ago=ago, countries=countries)


@app.route("/admin/users/<dev>/block", methods=["POST"])
@login_required
def block(dev):
    with db() as c:
        c.execute("UPDATE devices SET blocked = 1 - blocked WHERE id=?", (dev,))
    flash("Updated")
    return redirect(request.referrer or url_for("users"))

# ── more ──

@app.route("/admin/more", methods=["GET", "POST"])
@login_required
def more():
    if request.method == "POST":
        a = json.loads(kv_get("admin"))
        if not check_pw(request.form.get("old", ""), a["hash"]):
            flash("Old password wrong", True)
        elif len(request.form.get("new", "")) < 6:
            flash("New password min 6 characters", True)
        else:
            a["hash"] = hash_pw(request.form["new"])
            if request.form.get("user", "").strip():
                a["user"] = request.form["user"].strip()
            kv_set("admin", json.dumps(a))
            flash("Password changed")
        return redirect(url_for("more"))
    a = json.loads(kv_get("admin"))
    return page("More", head("More", "Account &amp; app", "cog") + """
<a href="/admin/users" class="key card lr" style="display:flex"><div class="tile tg">{{ ic('users')|safe }}</div><div class="tt"><b>Users &amp; devices</b><span>Block · version · country</span></div>{{ ic('chev',18)|safe }}</a>
<a href="/admin/links" class="key card lr" style="display:flex"><div class="tile tc">{{ ic('link')|safe }}</div><div class="tt"><b>Links</b><span>Support · Telegram · Privacy</span></div>{{ ic('chev',18)|safe }}</a>
<div class="sec">Login bodlao</div>
<form method="post" class="key card">
 <div class="fld"><label>Username</label><input class="in" name="user" value="{{ user }}"></div>
 <div class="fld"><label>Old password</label><input class="in" type="password" name="old" required></div>
 <div class="fld"><label>New password</label><input class="in" type="password" name="new" required></div>
 <button class="btn sm">{{ ic('lock',16)|safe }} Change password</button></form>
<a href="/admin/logout" class="btn red" style="text-decoration:none">{{ ic('out',18)|safe }} Logout</a>
<div class="mut" style="text-align:center;margin-top:16px">App config URL: <b>{{ base }}/api/config</b></div>""", 4, user=a["user"], base=PUBLIC_URL or request.host_url.rstrip("/"))


if __name__ == "__main__":
    print(f"Fleet Proxy admin → http://0.0.0.0:{PORT}/admin")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
