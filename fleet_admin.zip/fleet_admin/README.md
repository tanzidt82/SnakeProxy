# Fleet Proxy — Admin Panel

ফোন থেকে Fleet Proxy অ্যাপ পুরোটা কন্ট্রোল করার প্যানেল: Ads (নিজের ছবি/ভিডিও + AdMob), Update notice, Maintenance, Notice popup, Links, Users block.

## VPS-এ চালানো (একবারই)

```bash
# ১) ফোল্ডারটা VPS-এ /root/fleet_admin এ রাখো (zip আপলোড করে unzip)
cd /root && unzip fleet_admin.zip && cd fleet_admin

# ২) দরকারি জিনিস ইনস্টল
pip3 install -r requirements.txt        # error দিলে: pip3 install --break-system-packages -r requirements.txt

# ৩) service ফাইলে তিনটা জিনিস বদলাও: YOUR_VPS_IP, admin নাম, পাসওয়ার্ড
nano fleet-admin.service

# ৪) চালু করো
cp fleet-admin.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now fleet-admin
systemctl status fleet-admin            # active (running) দেখাবে

# ৫) পোর্ট খোলা (ufw থাকলে)
ufw allow 8090
```

ব্রাউজারে খোলো: `http://YOUR_VPS_IP:8090/admin`

> পাসওয়ার্ড শুধু **প্রথমবার** service ফাইল থেকে নেয়। পরে বদলাতে চাইলে প্যানেলের **More → Change password**।

## অ্যাপের সাথে জোড়া
অ্যাপের `app/src/main/res/values/strings.xml` এ:
```xml
<string name="admin_url">http://YOUR_VPS_IP:8090</string>
```
এটা বসিয়ে অ্যাপ বিল্ড করো। অ্যাপ প্রতিবার খুললে `/api/config` থেকে সব সেটিং নেয়।

## কাজের জিনিস
- লগ দেখা: `journalctl -u fleet-admin -f`
- রিস্টার্ট: `systemctl restart fleet-admin`
- সব ডাটা থাকে `fleet.db` আর `uploads/` ফোল্ডারে — ব্যাকআপ রাখো।
- ডোমেইন + HTTPS থাকলে ভালো (Nginx/Caddy দিয়ে)। তখন `FLEET_PUBLIC_URL` আর অ্যাপের `admin_url` দুটোই `https://...` করো।
